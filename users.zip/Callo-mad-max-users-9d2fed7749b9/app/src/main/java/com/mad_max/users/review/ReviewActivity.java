package com.mad_max.users.review;

import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mad_max.users.R;
import com.mad_max.users.communication.RequestStatusListener;
import com.mad_max.users.communication.SCM;
import com.mad_max.users.model.Review;
import com.mad_max.users.navigation.AbstractNavigatorActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class ReviewActivity extends AbstractNavigatorActivity implements RequestStatusListener {

    private static final int GET_REVIEWS = 379;

    private List<Review> mReviewList;

    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_review);

        Toolbar toolbar = (Toolbar) findViewById(R.id.review_toolbar);
        setSupportActionBar(toolbar);

        setUpUI(toolbar);

        mReviewList = new ArrayList<>();

        mRecyclerView = (RecyclerView) findViewById(R.id.rv);
        assert mRecyclerView != null;
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(new RVAdapter(mReviewList));

        mRecyclerView.addOnItemTouchListener(new RecyclerItemClickListener(this, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                TextView textView = (TextView) view.findViewById(R.id.textView9);
                TextView textView2 = (TextView) view.findViewById(R.id.tReply);

                if (textView.getVisibility() == View.VISIBLE) {
                    textView.setVisibility(View.GONE);
                    textView2.setVisibility(View.GONE);
                } else {
                    textView.setVisibility(View.VISIBLE);
                    textView2.setVisibility(View.VISIBLE);
                }

            }
        }));

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            SCM.getReviewListFromUser(user.getUid(), ReviewActivity.this, GET_REVIEWS);
        } else {
            Snackbar.make(findViewById(R.id.app_bar), "You have not confirmed your data, we " +
                    "cannot retrieve your reviews", Snackbar.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case GET_REVIEWS:
                mReviewList = (List<Review>) response;

                if (mReviewList.size() == 0) {
                    Snackbar.make(findViewById(R.id.app_bar), "No reviews has been found",
                            Snackbar.LENGTH_LONG).show();
                } else {
                    mRecyclerView.swapAdapter(new RVAdapter(mReviewList), false);
                }
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }

    public class RVAdapter extends RecyclerView.Adapter<RVAdapter.PersonViewHolder> {

        private final SimpleDateFormat mTimeFormat = new SimpleDateFormat("HH:mm");
        List<Review> reviews;

        RVAdapter(List<Review> reviews) {
            this.reviews = reviews;
        }

        @Override
        public int getItemCount() {
            return reviews.size();
        }

        @Override
        public PersonViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.review_item, viewGroup, false);
            return new PersonViewHolder(v);
        }

        @Override
        public void onBindViewHolder(PersonViewHolder personViewHolder, int i) {
            Review r = reviews.get(i);

            personViewHolder.name.setText((reviews.get(i).getRestaurantId()));
            personViewHolder.general.setRating(reviews.get(i).getGeneralRating());
            personViewHolder.service.setRating(reviews.get(i).getServiceRating());
            personViewHolder.price.setRating(reviews.get(i).getCostRating());
            personViewHolder.time.setText(mTimeFormat.format(reviews.get(i).getInsertionDate()));
            personViewHolder.comment.setText(reviews.get(i).getComment());
            personViewHolder.reply.setText("\n Answer from Manager:\n " + reviews.get(i).getReply());
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }


        public class PersonViewHolder extends RecyclerView.ViewHolder {
            CardView cv;
            TextView name;
            TextView time;
            TextView comment;
            TextView reply;
            RatingBar general;
            RatingBar price;
            RatingBar service;

            PersonViewHolder(View itemView) {
                super(itemView);
                cv = (CardView) itemView.findViewById(R.id.cv);
                name = (TextView) itemView.findViewById(R.id.textViewName);
                general = (RatingBar) itemView.findViewById(R.id.ratingBar4);
                price = (RatingBar) itemView.findViewById(R.id.ratingBar6);
                service = (RatingBar) itemView.findViewById(R.id.ratingBar5);
                time = (TextView) itemView.findViewById(R.id.timeView);
                comment = (TextView) itemView.findViewById(R.id.textView9);
                reply = (TextView) itemView.findViewById(R.id.tReply);
            }
        }

    }

}
