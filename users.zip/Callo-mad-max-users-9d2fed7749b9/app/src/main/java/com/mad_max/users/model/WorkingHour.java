package com.mad_max.users.model;

import android.os.Parcel;
import android.os.Parcelable;

public class WorkingHour implements Parcelable {
    @SuppressWarnings("unused")
    public static final Parcelable.Creator<WorkingHour> CREATOR = new Parcelable.Creator<WorkingHour>() {
        @Override
        public WorkingHour createFromParcel(Parcel in) {
            return new WorkingHour(in);
        }

        @Override
        public WorkingHour[] newArray(int size) {
            return new WorkingHour[size];
        }
    };
    private int mDayOfWeek;
    private String mOpeningHour;
    private String mClosingHour;

    private WorkingHour() {
    }

    public WorkingHour(int dayOfWeek, String openingHour, String closingHour) {
        mDayOfWeek = dayOfWeek;
        mOpeningHour = openingHour;
        mClosingHour = closingHour;
    }

    protected WorkingHour(Parcel in) {
        mDayOfWeek = in.readInt();
        mOpeningHour = in.readString();
        mClosingHour = in.readString();
    }

    public int getDayOfWeek() {
        return mDayOfWeek;
    }

    public void setDayOfWeek(int dayOfWeek) {
        mDayOfWeek = dayOfWeek;
    }

    public String getOpeningHour() {
        return mOpeningHour;
    }

    public void setOpeningHour(String openingHour) {
        mOpeningHour = openingHour;
    }

    public String getClosingHour() {
        return mClosingHour;
    }

    public void setClosingHour(String closingHour) {
        mClosingHour = closingHour;
    }

    @Override
    public String toString() {
        return "WorkingHour{" +
                "mDayOfWeek='" + mDayOfWeek + '\'' +
                ", mOpeningHour='" + mOpeningHour + '\'' +
                ", mClosingHour='" + mClosingHour + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(mDayOfWeek);
        dest.writeString(mOpeningHour);
        dest.writeString(mClosingHour);
    }
}