package com.mad_max.users.miscellaneous;

import android.app.Activity;
import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.NumberPicker;

import com.mad_max.users.R;


/**
 * Created by Yu on 4/6/2016.
 */
public class QuantityDialog extends DialogFragment implements View.OnClickListener {

    private Button update;
    private  NumberPicker np;
    private int pos,quantity;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.dish_selector_item_dialog, null);

        pos=getArguments().getInt("pos");
        quantity=getArguments().getInt("quantity");

        update=(Button)view.findViewById(R.id.button_update);
        np=(NumberPicker)view.findViewById(R.id.numberPicker);

        np.setMinValue(0);
        np.setMaxValue(10);
        np.setValue(quantity);


        update.setOnClickListener(this);
        setCancelable(true);

        return view;
    }

    @Override
    public void onClick(View view){
        if(view.getId()==R.id.button_update){
            ((DishSelectorActivity) getActivity()).SetItem(pos,np.getValue());
            dismiss();
        }
    }


}
