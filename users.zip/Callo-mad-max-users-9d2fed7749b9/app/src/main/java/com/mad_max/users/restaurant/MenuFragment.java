package com.mad_max.users.restaurant;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mad_max.users.R;
import com.mad_max.users.communication.DownloadImageTask;
import com.mad_max.users.miscellaneous.SimpleDividerItemDecoration;
import com.mad_max.users.model.Dish;

import java.util.ArrayList;
import java.util.List;

public class MenuFragment extends Fragment {

    private RecyclerView mRecyclerView;

    public MenuFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        List<Dish> menu = new ArrayList<>();

        View rootView = inflater.inflate(R.layout.restaurant_menu_fragment, container, false);

        RecyclerView rv = (RecyclerView) rootView.findViewById(R.id.menu_list);

        LinearLayoutManager llm = new LinearLayoutManager(this.getContext());
        DishRecyclerAdapter adapter = new DishRecyclerAdapter(menu);
        rv.setLayoutManager(llm);
        rv.setAdapter(adapter);
        rv.addItemDecoration(new SimpleDividerItemDecoration(this.getContext()));

        return rootView;
    }

    public void setDishList(List<Dish> dishList) {
        mRecyclerView.swapAdapter(new DishRecyclerAdapter(dishList), false);
    }


    public class DishRecyclerAdapter extends RecyclerView.Adapter<DishRecyclerAdapter.ViewHolder> {

        private List<Dish> mValues;

        public DishRecyclerAdapter(List<Dish> values) {
            mValues = values;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.restaurant_menu_item, parent, false);
            view.setClickable(true);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder viewHolder, int position) {
            Dish d = mValues.get(position);

            viewHolder.name.setText(d.getName());
            viewHolder.category.setText(d.getCategory());
            new DownloadImageTask(viewHolder.pic).execute(d.getImage());
            viewHolder.price.setText(String.format("%.2f€", d.getPrice()));

            // Dishes must be ordered by category
            if (position == 0 || !mValues.get(position - 1).getCategory().matches(d.getCategory())) {
                viewHolder.category.setVisibility(View.VISIBLE);
            }

            // Add 10 px spacing top on the first item, reset to 0 for others
            // This could not have been done in other ways
            if(position == 0) {
                viewHolder.itemView.setPadding(0, 10, 0, 0);
            } else {
                viewHolder.itemView.setPadding(0, 0, 0, 0);
            }
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public TextView name;
            public TextView category;
            public ImageView pic;
            public TextView price;

            public ViewHolder(View itemView) {
                super(itemView);
                name = (TextView) itemView.findViewById(R.id.dishname);
                category = (TextView) itemView.findViewById(R.id.dishcat);
                pic = (ImageView) itemView.findViewById(R.id.dishpic);
                price = (TextView) itemView.findViewById(R.id.dishprice);
            }

        }
    }
}