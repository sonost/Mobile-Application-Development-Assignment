package com.mad_max.users.recap;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mad_max.users.R;
import com.mad_max.users.communication.RequestStatusListener;
import com.mad_max.users.communication.SCM;
import com.mad_max.users.miscellaneous.SimpleDividerItemDecoration;
import com.mad_max.users.model.Dish;
import com.mad_max.users.model.Reservation;
import com.mad_max.users.model.TakeAway;
import com.mad_max.users.myorders.MyOrdersActivity;
import com.mad_max.users.navigation.AbstractNavigatorActivity;

import java.util.List;

/*This activity shows the comfirmation of the reservation and order
* it receives the intent include only a reservation or a takeaway...and present
* */


public class RecapActivity extends AbstractNavigatorActivity implements View.OnClickListener, RequestStatusListener {

    public static final String PARAM_RESERVATION = "reservation";
    public static final String PARAM_TAKEAWAY = "takwaway";
    public static final String PARAM_CONFIRMED = "check_history_order";
    private static final int PUT_RESERVATION = 678;
    private static final int PUT_TAKEAWAY = 876;
    private Reservation mReservation;
    private TakeAway mTakeAway;
    private int req;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recap_activity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.recap_toolbar);
        setSupportActionBar(toolbar);


        if ((mReservation = getIntent().getExtras().getParcelable(PARAM_RESERVATION)) != null) {
            RecyclerView recyclerView = (RecyclerView) findViewById(R.id.order_list);
            if (recyclerView != null) {
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                recyclerView.setAdapter(new DishListRecyclerViewAdapter(mReservation.getOrder()));
                recyclerView.addItemDecoration(new SimpleDividerItemDecoration(this));
            }
            CollapsingToolbarLayout appBarLayout = (CollapsingToolbarLayout) findViewById(R.id.recap_collapsing_toolbar);
            if (appBarLayout != null) {
                appBarLayout.setTitle(mReservation.getRestaurantName());
            }

            double totCost = 0.0;

            for (Dish dish : mReservation.getOrder()) {
                totCost += dish.getPrice() * dish.getQuantity();
            }

            ((TextView) findViewById(R.id.recap_seats)).setText(String.format("%s Seat(s)", mReservation.getSeats()));
            ((TextView) findViewById(R.id.recap_timeschedule)).setText(String.format("%s %s - %s",
                    mReservation.getDate(), mReservation.getStartTime(), mReservation.getEndTime()));
            ((TextView) findViewById(R.id.recap_comment)).setText(mReservation.getComment());
            ((TextView) findViewById(R.id.recap_total_cost)).setText(totCost + "€");
            boolean a = getIntent().getBooleanExtra(PARAM_CONFIRMED, false);
            if (!a) {//check the unconfirmed order
                FloatingActionButton fabSave = (FloatingActionButton) findViewById(R.id.fabSaveR);
                assert fabSave != null;
                fabSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        SCM.addReservation(mReservation, RecapActivity.this, PUT_RESERVATION);
                        Intent intent = new Intent(view.getContext(), MyOrdersActivity.class);
                        startActivity(intent);
                    }
                });
            } else {
                findViewById(R.id.fabSaveR).setVisibility(View.GONE);
            }

        } else if ((mTakeAway = getIntent().getExtras().getParcelable(PARAM_TAKEAWAY)) != null) {

            RecyclerView recyclerView = (RecyclerView) findViewById(R.id.order_list);
            if (recyclerView != null) {
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                recyclerView.setAdapter(new DishListRecyclerViewAdapter(mTakeAway.getOrder()));
                recyclerView.addItemDecoration(new SimpleDividerItemDecoration(this));
            }
            CollapsingToolbarLayout appBarLayout = (CollapsingToolbarLayout) findViewById(R.id.recap_collapsing_toolbar);
            if (appBarLayout != null) {
                appBarLayout.setTitle(mTakeAway.getRestaurantName());
            }
            ((TextView) findViewById(R.id.recap_seats)).setCursorVisible(false);
            ((TextView) findViewById(R.id.recap_comment)).setText(mTakeAway.getComment());
            ((TextView) findViewById(R.id.recap_timeschedule)).setText(String.format("%s", mTakeAway.getDate()));

            double totCost = 0.0;

            for (Dish dish : mTakeAway.getOrder()) {
                totCost += dish.getPrice() * dish.getQuantity();
            }

            ((TextView) findViewById(R.id.recap_total_cost)).setText(totCost + "€");

            boolean a = getIntent().getBooleanExtra(PARAM_CONFIRMED, false);
            if (!a) {//check the unconfirmed order
                FloatingActionButton fabSave = (FloatingActionButton) findViewById(R.id.fabSaveR);
                assert fabSave != null;
                fabSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        SCM.addTakeaway(mTakeAway, RecapActivity.this, PUT_TAKEAWAY);
                        Intent intent = new Intent(view.getContext(), MyOrdersActivity.class);
                        startActivity(intent);
                    }
                });
            } else {
                findViewById(R.id.fabSaveR).setVisibility(View.GONE);
            }
        }


        // Show the Up button in the action bar.

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case PUT_RESERVATION:
                Intent toReservation = new Intent(RecapActivity.this, RecapActivity.class);
                toReservation.putExtra(RecapActivity.PARAM_RESERVATION, mReservation);
                toReservation.putExtra(RecapActivity.PARAM_CONFIRMED, true);
                startActivity(toReservation);
                finish();
                break;
            case PUT_TAKEAWAY:
                Intent toTakeAway = new Intent(RecapActivity.this, RecapActivity.class);
                toTakeAway.putExtra(RecapActivity.PARAM_TAKEAWAY, mTakeAway);
                toTakeAway.putExtra(RecapActivity.PARAM_CONFIRMED, true);
                startActivity(toTakeAway);
                finish();
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }

    public class DishListRecyclerViewAdapter extends RecyclerView.Adapter<DishListRecyclerViewAdapter.ViewHolder> {

        private final List<Dish> mValues;

        public DishListRecyclerViewAdapter(List<Dish> items) {
            mValues = items;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.order_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, int position) {
            holder.mItem = mValues.get(position);
            holder.mQuantityView.setText(mValues.get(position).getQuantity() + "x");
            holder.mDishView.setText(mValues.get(position).getName());
            holder.mPriceView.setText(mValues.get(position).getPrice() + "€");
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public final View mView;
            public final TextView mQuantityView;
            public final TextView mDishView;
            public final TextView mPriceView;
            public Dish mItem;

            public ViewHolder(View view) {
                super(view);
                mView = view;
                mQuantityView = (TextView) view.findViewById(R.id.order_quantity);
                mDishView = (TextView) view.findViewById(R.id.order_dish);
                mPriceView = (TextView) view.findViewById(R.id.order_price);
            }

            @Override
            public String toString() {
                return super.toString() + " Name: " + mDishView.getText() + " Quantity: " +
                        mQuantityView.getText() + " Price: " + mPriceView.getText();
            }
        }
    }
}




