package com.mad_max.users.communication;

public interface RequestStatusListener {
    void onRequestComplete(int requestCode, Object response);
    void onRequestFail(int requestCode, Exception exception);
}
