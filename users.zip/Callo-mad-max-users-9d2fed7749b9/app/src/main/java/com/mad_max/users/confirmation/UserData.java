package com.mad_max.users.confirmation;

/**
 * Created by matbr on 07/06/2016.
 */
public class UserData {


    public String phoneNumber;
    public String surname;
    public String name;
    public String email;


    public UserData() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public UserData(String name,String surname, String phoneNumber,  String email) {
        this.name = name;
        this.surname= surname;
        this.phoneNumber=phoneNumber;
        this.email = email;
    }

}
