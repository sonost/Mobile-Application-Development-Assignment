package com.mad_max.users.miscellaneous;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;

import com.mad_max.users.R;
import com.mad_max.users.communication.DownloadImageTask;
import com.mad_max.users.model.Dish;
import com.mad_max.users.takeaway.TakeAwayActivity;

import java.util.ArrayList;
import java.util.List;


/* Activity receives the List<Dish>
  User selects dishes from the ListView.
  Send the list<Dish> selected dish with quantity.
* */


public class DishSelectorActivity extends AppCompatActivity implements NumberPicker.OnValueChangeListener {
    public static final String PARAM_ORDER = "order";
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<Dish> mDish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dish_selector_activity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.dish_selector_toolbar);
        setSupportActionBar(toolbar);
        mDish = getIntent().getParcelableArrayListExtra(PARAM_ORDER);

        mRecyclerView=(RecyclerView)findViewById(R.id.my_dishlist_view);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new DishSelectorRecyclerAdapter(mDish);
        mRecyclerView.setAdapter(mAdapter);



        FloatingActionButton fabdish = (FloatingActionButton) findViewById(R.id.fab_dishselectorsave);
        assert fabdish != null;
        fabdish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<Dish> selectedDish = new ArrayList<>();
                TextView numDish;
                int num;

                for (int i = 0; i < mDish.size(); i++) {
                /*    View viewDish = mRecyclerView.getChildAt(i);
                    numDish = (TextView) viewDish.findViewById(R.id.item_sdishquantity);
                    if (numDish != null && !(numDish.getText().toString()).isEmpty()) {
                        num = Integer.parseInt(numDish.getText().toString());
                    } else {
                        num = 0;
                    }*/
                    Dish d = mDish.get(i);
                    if (d.getQuantity() > 0) {
                        selectedDish.add(d);
                    }
                }
                Intent intent = new Intent(DishSelectorActivity.this, TakeAwayActivity.class);
                Bundle b = new Bundle();
                b.putParcelableArrayList(PARAM_ORDER, selectedDish);
                intent.putExtras(b);
                setResult(RESULT_OK, intent);
                finish();
                startActivity(intent);
            }
        });

    }


    @Override
    public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
        picker.setValue(newVal);
    }


    public class DishSelectorRecyclerAdapter extends RecyclerView.Adapter<DishSelectorRecyclerAdapter.ViewHolder> {

        private List<Dish> mValues;

        public DishSelectorRecyclerAdapter(List<Dish> values) {
            mValues = values;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dish_selector_item, parent, false);
            view.setClickable(true);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder viewHolder, final int position) {
            final Dish d = mValues.get(position);

            viewHolder.name.setText(d.getName());
            viewHolder.category.setText(d.getCategory());
            new DownloadImageTask(viewHolder.pic).execute(d.getImage());
            viewHolder.price.setText(String.format("%.2f€", d.getPrice()));
            viewHolder.quantity.setText(String.format("%d",d.getQuantity()));
            viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    android.app.FragmentManager manager=getFragmentManager();
                    QuantityDialog myDialog=new QuantityDialog();
                    myDialog.show(manager, "QuantityDialog");
                    Bundle bundle=new Bundle();
                    bundle.putInt("pos",position);
                    bundle.putInt("quantity",d.getQuantity());
                    myDialog.setArguments(bundle);
                }
            });


            // Dishes must be ordered by category
            if (position == 0 || !mValues.get(position - 1).getCategory().matches(d.getCategory())) {
                viewHolder.category.setVisibility(View.VISIBLE);
            }

            // Add 10 px spacing top on the first item, reset to 0 for others
            // This could not have been done in other ways
            if(position == 0) {
                viewHolder.itemView.setPadding(0, 10, 0, 0);
            } else {
                viewHolder.itemView.setPadding(0, 0, 0, 0);
            }
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public TextView name;
            public TextView category;
            public ImageView pic;
            public TextView price;
            public TextView quantity;
            public View mView;

            public ViewHolder(View itemView) {
                super(itemView);
                mView=itemView;
                name = (TextView) itemView.findViewById(R.id.item_sdishname);
                category = (TextView) itemView.findViewById(R.id.item_sdishcat);
                pic = (ImageView) itemView.findViewById(R.id.item_sdishpic);
                price = (TextView) itemView.findViewById(R.id.item_sdishprice);
                quantity = (TextView) itemView.findViewById(R.id.item_sdishquantity);
            }
        }
    }
    public void SetItem(int p,int q) {

        runOnUiThread(new Setter(p,q));

    }

    public class Setter implements Runnable {
        int pos,quantity;
        public Setter(int p,int q) {
            pos=p;
            quantity=q;
        }

        @Override
        public void run() {
            Dish d=mDish.get(pos);
            d.setQuantity(quantity);
            mDish.set(pos, d);
            mAdapter.notifyItemChanged(pos);
            mAdapter.notifyDataSetChanged();
        }
    }


}
