package com.mad_max.users.navigation;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mad_max.users.R;
import com.mad_max.users.communication.DownloadImageTask;
import com.mad_max.users.favorite.FavoriteActivity;
import com.mad_max.users.home.HomeActivity;
import com.mad_max.users.login.UserResponse;
import com.mad_max.users.myorders.MyOrdersActivity;
import com.mad_max.users.review.ReviewActivity;
import com.mad_max.users.settings.SettingsActivity;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public abstract class AbstractNavigatorActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    public RequestQueue mQueue;
    public String mEmail;
    public String mPassword;
    public Context mContext;
    public TextView mTextView1;
    public TextView mTextView2;
    public ImageView mImageView;
    private String mToken;
    private UserResponse mUserResponse;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth = FirebaseAuth.getInstance();
        mContext = this;
        mQueue = Volley.newRequestQueue(this);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in

                } else {
                    // User is signed out
                    Intent intent = new Intent(mContext, HomeActivity.class);
                    startActivity(intent);
                    finish();
                }
                // ...
            }
        };
        // userInformationGetter(mEmail, mPassword);


        //set username and password
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer == null) super.onBackPressed();
        else if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        setUpDrawerMenu();
        return true;
    }

    private void setUpDrawerMenu() {
        mTextView1 = (TextView) findViewById(R.id.nav_user_name1);
        mTextView2 = (TextView) findViewById(R.id.nav_user_email1);
        mImageView = (ImageView) findViewById(R.id.imageView);
        Update();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent i = new Intent(mContext, SettingsActivity.class);

            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home && this.getClass() != HomeActivity.class) {
            Intent i = new Intent(mContext, HomeActivity.class);
            startActivity(i);
            finish();
        } else if (id == R.id.nav_myorders && this.getClass() != MyOrdersActivity.class) {
            Intent i = new Intent(mContext, MyOrdersActivity.class);
            startActivity(i);
            finish();
        } else if (id == R.id.nav_favorites && this.getClass() != FavoriteActivity.class) {
            Intent i = new Intent(mContext, FavoriteActivity.class);
            startActivity(i);
            finish();
        } else if (id == R.id.nav_reviews && this.getClass() != ReviewActivity.class) {
            Intent i = new Intent(mContext, ReviewActivity.class);
            startActivity(i);
            finish();

        } else if (id == R.id.nav_settings) {
            Intent i = new Intent(mContext, SettingsActivity.class);
            startActivity(i);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        assert drawer != null;
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void Update() {

        mUserResponse = null;
        if (mUserResponse == null) {
            final SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.PREF_FILE), MODE_PRIVATE);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mTextView1 != null) {
                        mTextView1.setText("Pallo");
                    }
                    if (mTextView2 != null) {
                        mTextView2.setText(sharedPreferences.getString("email", "paolo.caleffi@studenti.polito.it"));
                    }
                    if (mImageView != null) {
                        new DownloadImageTask(mImageView).execute("https://robohash.org/test");


                    }
                }
            });

            return;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TextView textView1 = (TextView) findViewById(R.id.nav_user_name1);
                TextView textView2 = (TextView) findViewById(R.id.nav_user_email1);
                textView1.setText(mUserResponse.getData().getName());
                textView2.setText(mUserResponse.getData().getEmail());

                ImageView imageView = (ImageView) findViewById(R.id.imageView);

                try {
                    URL url = new URL(mUserResponse.getData().getProfileImage());
                    Bitmap bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                    imageView.setImageBitmap(bmp);
                } catch (MalformedURLException e) {
                    return;
                } catch (IOException e) {
                    return;
                }
            }
        });

    }

    public void setUpUI(Toolbar toolbar) {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        mTextView1 = (TextView) findViewById(R.id.nav_user_name1);
        mTextView2 = (TextView) findViewById(R.id.nav_user_email1);

        Update();

    }

}