package com.mad_max.users.confirmation;

import android.accounts.AccountManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.common.AccountPicker;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mad_max.users.R;
import com.mad_max.users.model.Reservation;
import com.mad_max.users.model.TakeAway;
import com.mad_max.users.recap.RecapActivity;
import com.mad_max.users.settings.SettingsActivity;

public class ConfirmDataActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String PARAM_RESERVATION = "reservation";
    public static final String PARAM_TAKEAWAY = "takwaway";
    public static final String PARAM_CONFIRMED = "check_history_order";
    private static final int REQUEST_CODE_EMAIL = 1;
    private static final int REQUEST_CODE_ASK_PERMISSIONS = 123;
    private EditText mEmail;
    private EditText mName;
    private EditText mSurname;
    private EditText mNum;
    private Button mConfirm;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private Context mContext;
    private FirebaseAuth mAuth;
    private UserData mUserData;
    private Intent mIntent;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mUserData=null;
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mIntent=getIntent();
        mContext=this;
        mAuth = FirebaseAuth.getInstance();



        doStuff();
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                doStuff();
            }
        };
       // isLogged();
        setContentView(R.layout.confim_data_activity);

        //not always available the cellphone number
        //ActivityCompat.requestPermissions(this, new String[]{"android.permission.READ_SMS"}, REQUEST_CODE_ASK_PERMISSIONS);

        mEmail = (EditText) findViewById(R.id.email_field);
        mName = (EditText) findViewById(R.id.user_name);
        mNum = (EditText) findViewById(R.id.phone_num_field);
        mSurname = (EditText) findViewById(R.id.user_surname);

        mConfirm = (Button) findViewById(R.id.confirm);
        assert mConfirm != null;
        mConfirm.setOnClickListener(this);

        if(mAuth.getCurrentUser()!=null)
        try {
            Intent intent = AccountPicker.newChooseAccountIntent(null, null,
                    new String[]{GoogleAuthUtil.GOOGLE_ACCOUNT_TYPE}, false, null, null, null, null);
            startActivityForResult(intent, REQUEST_CODE_EMAIL);
        } catch (ActivityNotFoundException e) {
            // TODO
        }
        Button mSkip=(Button)findViewById(R.id.skip);
        mSkip.setVisibility(View.INVISIBLE);

    }

    private void isLogged() {
        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.PREF_FILE), MODE_PRIVATE);
        if (sharedPreferences.getString("email",null)!=null) {
            Intent newIntent=getIntent();
            newIntent.setClass(this,RecapActivity.class);
            Reservation reservation = getIntent().getExtras().getParcelable(PARAM_RESERVATION);
            if (reservation != null) {
                reservation.setCellphone(sharedPreferences.getString("phone", null));
                reservation.setName(sharedPreferences.getString("name", null));
                reservation.setSurname(sharedPreferences.getString("surname", null));
                newIntent.putExtra(RecapActivity.PARAM_RESERVATION, reservation);

            }
            TakeAway takeAway= getIntent().getExtras().getParcelable(PARAM_TAKEAWAY);
            if(takeAway!=null){
                takeAway.setCellphone(sharedPreferences.getString("phone", null));
                takeAway.setName(sharedPreferences.getString("name", null));
                takeAway.setSurname(sharedPreferences.getString("surname", null));
                newIntent.putExtra(RecapActivity.PARAM_TAKEAWAY, takeAway);

            }
            startActivity(newIntent);
            finish();


        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_EMAIL && resultCode == RESULT_OK) {
            String accountName = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
            mEmail.setText(accountName);
        }
    }

    @Override
    public void onClick(View v) {
        mNum.setError(null);
        mName.setError(null);
        mSurname.setError(null);
        mEmail.setError(null);


        String email = mEmail.getText().toString();
        String num = mNum.getText().toString();
        String name = mName.getText().toString();
        String surname = mSurname.getText().toString();

        Boolean cancel = false;
        View focusView = null;


        // Check for a valid email address.
        if (TextUtils.isEmpty(num)) {
            mNum.setError(getString(R.string.error_field_required));
            focusView = mNum;
            cancel = true;
        } else if (!checkPhoneNumber(num)) {
            mNum.setError(getString(R.string.error_invalid_number));
            focusView = mNum;
            cancel = true;
        }


        if (TextUtils.isEmpty(email)) {
            mEmail.setError(getString(R.string.error_field_required));
            focusView = mEmail;
            cancel = true;
        } else if (!checkEmail(email)) {
            mEmail.setError(getString(R.string.error_invalid_email));
            focusView = mEmail;
            cancel = true;
        }

        if (TextUtils.isEmpty(name)) {
            mName.setError(getString(R.string.error_field_required));
            focusView = mName;
            cancel = true;
        } else if (!checkName(name)) {
            mName.setError(getString(R.string.error_invalid_name));
            focusView = mName;
            cancel = true;
        }

        if (TextUtils.isEmpty(surname)) {
            mSurname.setError(getString(R.string.error_field_required));
            focusView = mSurname;
            cancel = true;
        } else if (!checkName(surname)) {
            mSurname.setError(getString(R.string.error_invalid_name));
            focusView = mSurname;
            cancel = true;
        }
        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        }

        //TODO: save user data to db
//        SharedPreferences sharedPreferences= getSharedPreferences(getString(R.string.PREF_FILE), MODE_PRIVATE);
//        SharedPreferences.Editor editor=sharedPreferences.edit();
//        editor.putString("name",name);
//        editor.putString("surname", surname);
//        editor.putString("email", email);
//        editor.putString("phone", num);
//        editor.commit();


// ...
        mUserData=new UserData(name,surname, num,email);

        mAuth.createUserWithEmailAndPassword(email, "vivapolito")
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        // If sign in fails, display a message to the user. If sign in succeeds
                        // the auth state listener will be notified and logic to handle the
                        // signed in user can be handled in the listener.
                        if (!task.isSuccessful()) {
                            Toast.makeText(ConfirmDataActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        doStuff();
                    }
                });



    //    isLogged();
    }

    public boolean checkName(String t) {
        return t.length() > 1;
    }

    public boolean checkPhoneNumber(String t) {
        return t.length() > 8;
    }

    public boolean checkEmail(String t) {
        return t.contains("@");
    }

    public void doStuff() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            // User is signed in

            if (mUserData != null) {
                mDatabase.child("users").child(user.getUid()).setValue(mUserData);
            }
            mDatabase.child("users").child(user.getUid()).addListenerForSingleValueEvent(
                    new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            // Get user value
                            UserData user = dataSnapshot.getValue(UserData.class);

                            Intent newIntent = mIntent;
                            newIntent.setClass(mContext, RecapActivity.class);
try {
    Reservation reservation = mIntent.getExtras().getParcelable(PARAM_RESERVATION);
    if (reservation != null) {

        reservation.setCellphone(user.phoneNumber);
        reservation.setName(user.name);
        reservation.setSurname(user.surname);
        newIntent.putExtra(RecapActivity.PARAM_RESERVATION, reservation);

    }
    TakeAway takeAway = mIntent.getExtras().getParcelable(PARAM_TAKEAWAY);
    if (takeAway != null) {
        takeAway.setCellphone(user.phoneNumber);
        takeAway.setName(user.name);
        takeAway.setSurname(user.surname);
        newIntent.putExtra(RecapActivity.PARAM_TAKEAWAY, takeAway);

    }
}catch (Exception e){

    newIntent.setClass(mContext, SettingsActivity.class);

    startActivity(newIntent);
    finish();
}



                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                        }
                    });

        } else {
            // User is signed out
        }
    }

}
