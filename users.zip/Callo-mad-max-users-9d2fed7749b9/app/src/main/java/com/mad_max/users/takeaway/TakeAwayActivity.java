package com.mad_max.users.takeaway;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.mad_max.users.R;
import com.mad_max.users.confirmation.ConfirmDataActivity;
import com.mad_max.users.miscellaneous.DishSelectorActivity;
import com.mad_max.users.miscellaneous.SimpleDividerItemDecoration;
import com.mad_max.users.model.Dish;
import com.mad_max.users.model.Promotion;
import com.mad_max.users.model.Restaurant;
import com.mad_max.users.model.TakeAway;
import com.mad_max.users.navigation.AbstractNavigatorActivity;
import com.mad_max.users.promotion.PromotionActivity;
import com.mad_max.users.recap.RecapActivity;
import com.mad_max.users.restaurant.RestaurantActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class TakeAwayActivity extends AbstractNavigatorActivity implements
        View.OnClickListener, TimePickerDialog.OnTimeSetListener {
    private static final int PICK_DISHES = 1;
    private static final int AVERAGE_WAIT_TIME = 30;

    private Restaurant mRestaurant;
    private ArrayList<Dish> mMenu;
    private Promotion mPromotion;

    private Button mTimeButton;
    private RecyclerView mOrderRecycler;
    private TextView mTotalCostTextView;

    private Calendar mSelectedTime;
    private ArrayList<Dish> mSelectedOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.takeaway_activity);

        Toolbar toolbar = (Toolbar) findViewById(R.id.takeaway_toolbar);
        setSupportActionBar(toolbar);

        // Show the Up button in the action bar.
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.takeaway_fab);
        assert fab != null;
        fab.setOnClickListener(this);

        // Get restaurant and menu from intent of previous activity
        mRestaurant = getIntent().getParcelableExtra(RestaurantActivity.PARAM_RESTAURANT);
        mMenu = getIntent().getParcelableArrayListExtra(RestaurantActivity.PARAM_MENU);

        if(getIntent().hasExtra(PromotionActivity.PARAM_PROMOTION)) {
            mSelectedOrder = mMenu;
            mPromotion = getIntent().getParcelableExtra(PromotionActivity.PARAM_PROMOTION);
        }
        else {
            mSelectedOrder = new ArrayList<>();
            mPromotion = null;
        }

        mSelectedTime = Calendar.getInstance();
        mSelectedTime.add(Calendar.MINUTE, AVERAGE_WAIT_TIME);

        mTimeButton = (Button) findViewById(R.id.takeaway_time);
        assert mTimeButton != null;
        mTimeButton.setOnClickListener(this);
        mTimeButton.setText(String.format("%02d:%02d", mSelectedTime.get(Calendar.HOUR_OF_DAY), mSelectedTime.get(Calendar.MINUTE)));

        mOrderRecycler = (RecyclerView) findViewById(R.id.order_list);
        assert mOrderRecycler != null;
        mOrderRecycler.setLayoutManager(new LinearLayoutManager(this));
        mOrderRecycler.addItemDecoration(new SimpleDividerItemDecoration(this));
        mOrderRecycler.setAdapter(new DishListRecyclerViewAdapter(mSelectedOrder));

        Button orderButton = (Button) findViewById(R.id.takeaway_select_menu);
        assert orderButton != null;
        orderButton.setOnClickListener(this);

        mTotalCostTextView = (TextView) findViewById(R.id.order_total_cost);
        assert mTotalCostTextView != null;
        mTotalCostTextView.setText(R.string.example_order_cost);

        if(mPromotion != null) {
            orderButton.setVisibility(View.GONE);
            mTotalCostTextView.setText(String.format("%.2f€", mPromotion.getPrice()));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            // This ID represents the Home or Up button. In the case of this
            // activity, the Up button is shown. Use NavUtils to allow users
            // to navigate up one level in the application structure. For
            // more details, see the Navigation pattern on Android Design:
            //
            // http://developer.android.com/design/patterns/navigation.html#up-vs-back
            //
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.takeaway_fab:
                Intent doRecap = new Intent(TakeAwayActivity.this, ConfirmDataActivity.class);
                TakeAway takeAway = new TakeAway(null, mRestaurant.getId(), mRestaurant.getName(), "", "", "", mSelectedTime.getTime(),
                        ((EditText) findViewById(R.id.takeaway_comment)).getText().toString(), mSelectedOrder);

                // Load data in the intent extras
                doRecap.putExtra(RecapActivity.PARAM_TAKEAWAY, takeAway);
                doRecap.putExtra(PromotionActivity.PARAM_PROMOTION, mPromotion);

                startActivity(doRecap);
                break;
            case R.id.takeaway_select_menu:
                Intent getOrder = new Intent(TakeAwayActivity.this, DishSelectorActivity.class);
                getOrder.putExtra(DishSelectorActivity.PARAM_ORDER, mMenu);

                startActivityForResult(getOrder, PICK_DISHES);
                break;
            case R.id.takeaway_time:
                Calendar calendar = Calendar.getInstance();
                calendar.add(Calendar.MINUTE, AVERAGE_WAIT_TIME);
                new TimePickerDialog(this, this, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case PICK_DISHES:
                    mMenu = data.getParcelableArrayListExtra(DishSelectorActivity.PARAM_ORDER);
                    mSelectedOrder = new ArrayList<>();

                    double totCost = 0.0;

                    for(Dish d : mMenu) {
                        if(d.getQuantity() != 0) {
                            mSelectedOrder.add(d);
                            totCost += d.getPrice()*d.getQuantity();
                        }
                    }

                    mOrderRecycler.swapAdapter(new DishListRecyclerViewAdapter(mSelectedOrder), false);
                    mTotalCostTextView.setText(String.format("%.2f€", totCost));
                    break;
            }
        }
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MINUTE, AVERAGE_WAIT_TIME);

        Calendar clone = (Calendar) calendar.clone();
        clone.set(Calendar.HOUR_OF_DAY, hourOfDay);
        clone.set(Calendar.MINUTE, minute);

        if (clone.before(calendar)) {
            LinearLayout viewgroup = (LinearLayout) findViewById(R.id.takeaway_container_layout);
            assert viewgroup != null;
            Snackbar.make(viewgroup, getString(R.string.takeaway_invalid_time), Snackbar.LENGTH_LONG).show();
        } else {
            mSelectedTime = clone;
            mTimeButton.setText(String.format("%02d:%02d", mSelectedTime.get(Calendar.HOUR_OF_DAY), mSelectedTime.get(Calendar.MINUTE)));
        }
    }

    public class DishListRecyclerViewAdapter extends RecyclerView.Adapter<DishListRecyclerViewAdapter.ViewHolder> {

        private final List<Dish> mValues;

        public DishListRecyclerViewAdapter(List<Dish> items) {
            mValues = items;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.order_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, int position) {
            holder.mItem = mValues.get(position);
            holder.mQuantityView.setText(String.format("%sx", mValues.get(position).getQuantity()));
            holder.mDishView.setText(mValues.get(position).getName());
            holder.mPriceView.setText(String.format("%s€", mValues.get(position).getPrice()));
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public final View mView;
            public final TextView mQuantityView;
            public final TextView mDishView;
            public final TextView mPriceView;
            public Dish mItem;

            public ViewHolder(View view) {
                super(view);
                mView = view;
                mQuantityView = (TextView) view.findViewById(R.id.order_quantity);
                mDishView = (TextView) view.findViewById(R.id.order_dish);
                mPriceView = (TextView) view.findViewById(R.id.order_price);
            }

            @Override
            public String toString() {
                return super.toString() + " Name: " + mDishView.getText() + " Quantity: " +
                        mQuantityView.getText() + " Price: " + mPriceView.getText();
            }
        }
    }
}
