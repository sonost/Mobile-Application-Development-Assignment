package com.mad_max.users.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TakeAway implements Parcelable {

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<TakeAway> CREATOR = new Parcelable.Creator<TakeAway>() {
        @Override
        public TakeAway createFromParcel(Parcel in) {
            return new TakeAway(in);
        }

        @Override
        public TakeAway[] newArray(int size) {
            return new TakeAway[size];
        }
    };
    private String mId;
    private String mRestaurantId;
    private String mRestaurantName;
    private String mName;
    private String mSurname;
    private String mCellphone;
    private Date mDate;
    private String mComment;
    private List<Dish> mOrder;

    public TakeAway() {
    }

    public TakeAway(String id, String restaurantId, String restaurantName, String name, String surname, String cellphone, Date date) {
        this(id, restaurantId, restaurantName, name, surname, cellphone, date, "", new ArrayList<Dish>());
    }

    public TakeAway(String id, String restaurantId, String restaurantName, String name, String surname, String cellphone, Date date, List<Dish> order) {
        this(id, restaurantId, restaurantName, name, surname, cellphone, date, "", order);
    }

    public TakeAway(String id, String restaurantId, String restaurantName, String name, String surname, String cellphone, Date date, String comment, List<Dish> order) {
        mId = id;
        mRestaurantId = restaurantId;
        mRestaurantName = restaurantName;
        mName = name;
        mSurname = surname;
        mCellphone = cellphone;
        mDate = date;
        mComment = comment;
        mOrder = order;
    }

    protected TakeAway(Parcel in) {
        mId = in.readString();
        mName = in.readString();
        mRestaurantId = in.readString();
        mRestaurantName = in.readString();
        mSurname = in.readString();
        mCellphone = in.readString();
        long tmpMTime = in.readLong();
        mDate = tmpMTime != -1 ? new Date(tmpMTime) : null;
        mComment = in.readString();
        if (in.readByte() == 0x01) {
            mOrder = new ArrayList<>();
            in.readList(mOrder, Dish.class.getClassLoader());
        } else {
            mOrder = null;
        }
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getRestaurantId() {
        return mRestaurantId;
    }

    public void setRestaurantId(String restaurantId) {
        mRestaurantId = restaurantId;
    }

    public String getRestaurantName() {
        return mRestaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        mRestaurantName = restaurantName;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getSurname() {
        return mSurname;
    }

    public void setSurname(String surname) {
        mSurname = surname;
    }

    public String getCellphone() {
        return mCellphone;
    }

    public void setCellphone(String cellphone) {
        mCellphone = cellphone;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        mDate = date;
    }

    public String getComment() {
        return mComment;
    }

    public void setComment(String comment) {
        mComment = comment;
    }

    public List<Dish> getOrder() {
        return mOrder;
    }

    public void setOrder(List<Dish> order) {
        mOrder = order;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "mId='" + mId + '\'' +
                ",mName='" + mName + '\'' +
                ", mSurname='" + mSurname + '\'' +
                ", mCellphone='" + mCellphone + '\'' +
                ", mComment='" + mComment + '\'' +
                ", mOrder=" + mOrder +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mId);
        dest.writeString(mName);
        dest.writeString(mRestaurantId);
        dest.writeString(mRestaurantName);
        dest.writeString(mSurname);
        dest.writeString(mCellphone);
        dest.writeLong(mDate != null ? mDate.getTime() : -1L);
        dest.writeString(mComment);
        if (mOrder == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(mOrder);
        }
    }
}