package com.mad_max.users.reservation;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mad_max.users.R;
import com.mad_max.users.confirmation.ConfirmDataActivity;
import com.mad_max.users.miscellaneous.DishSelectorActivity;
import com.mad_max.users.miscellaneous.SimpleDividerItemDecoration;
import com.mad_max.users.model.Dish;
import com.mad_max.users.model.Promotion;
import com.mad_max.users.model.Reservation;
import com.mad_max.users.model.Restaurant;
import com.mad_max.users.model.TimeSlot;
import com.mad_max.users.navigation.AbstractNavigatorActivity;
import com.mad_max.users.promotion.PromotionActivity;
import com.mad_max.users.recap.RecapActivity;
import com.mad_max.users.restaurant.RestaurantActivity;
import com.satsuware.usefulviews.LabelledSpinner;

import java.util.ArrayList;
import java.util.List;

public class ReservationActivity extends AbstractNavigatorActivity implements LabelledSpinner.OnItemChosenListener, View.OnClickListener {
    private static final int PICK_DISHES = 1;

    private Restaurant mRestaurant;
    private ArrayList<Dish> mMenu;
    private Promotion mPromotion;

    private LabelledSpinner mTimeSlotSpinner;
    private LabelledSpinner mSeatsSpinner;
    private RecyclerView mOrderRecycler;
    private TextView mTotalCostTextView;

    private int mSelectedTimeslot, mSelectedSeats;
    private ArrayList<Dish> mSelectedOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_activity);

        Toolbar toolbar = (Toolbar) findViewById(R.id.reservation_toolbar);
        setSupportActionBar(toolbar);

        // Show the Up button in the action bar.
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.reservation_fab);
        assert fab != null;
        fab.setOnClickListener(this);

        mRestaurant = getIntent().getParcelableExtra(RestaurantActivity.PARAM_RESTAURANT);
        mMenu = getIntent().getParcelableArrayListExtra(RestaurantActivity.PARAM_MENU);

        if(getIntent().hasExtra(PromotionActivity.PARAM_PROMOTION)) {
            mSelectedOrder = mMenu;
            mPromotion = getIntent().getParcelableExtra(PromotionActivity.PARAM_PROMOTION);
        }
        else {
            mSelectedOrder = new ArrayList<>();
            mPromotion = null;
        }

        List<String> timeSlotHours = new ArrayList<>();
        for (TimeSlot ts : mRestaurant.getTimeSlots()) {
            timeSlotHours.add(ts.getStartTime() + " - " + ts.getEndTime());
        }

        mTimeSlotSpinner = (LabelledSpinner) findViewById(R.id.reservation_timeslot_spinner);
        assert mTimeSlotSpinner != null;
        mTimeSlotSpinner.setItemsArray(timeSlotHours);
        mTimeSlotSpinner.setOnItemChosenListener(this);
        mSelectedTimeslot = 0;


        TimeSlot firstSlot = mRestaurant.getTimeSlots().get(0);
        List<Integer> seatsNumbers = new ArrayList<>();
        for (int i = 1, seats = firstSlot.getAvailableSeats() - firstSlot.getOccupiedSeats(); i <= seats; i++) {
            seatsNumbers.add(i);
        }

        mSeatsSpinner = (LabelledSpinner) findViewById(R.id.reservation_seats_spinner);
        assert mSeatsSpinner != null;
        mSeatsSpinner.setItemsArray(seatsNumbers);
        mSeatsSpinner.setOnItemChosenListener(this);
        mSelectedSeats = 0;

        mOrderRecycler = (RecyclerView) findViewById(R.id.order_list);
        assert mOrderRecycler != null;
        mOrderRecycler.setLayoutManager(new LinearLayoutManager(this));
        mOrderRecycler.addItemDecoration(new SimpleDividerItemDecoration(this));
        mOrderRecycler.setAdapter(new DishListRecyclerViewAdapter(mSelectedOrder));

        Button orderButton = (Button) findViewById(R.id.reservation_select_menu);
        assert orderButton != null;
        orderButton.setOnClickListener(this);

        mTotalCostTextView = (TextView) findViewById(R.id.order_total_cost);
        assert mTotalCostTextView != null;
        mTotalCostTextView.setText(R.string.example_order_cost);

        if(mPromotion != null) {
            orderButton.setVisibility(View.GONE);
            mTotalCostTextView.setText(String.format("%.2f€", mPromotion.getPrice()));
        } else if(!mRestaurant.getSettings().getBoolean("reservation_order", false)) {
            mOrderRecycler.setVisibility(View.GONE);
            orderButton.setVisibility(View.GONE);
            mTotalCostTextView.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            // This ID represents the Home or Up button. In the case of this
            // activity, the Up button is shown. Use NavUtils to allow users
            // to navigate up one level in the application structure. For
            // more details, see the Navigation pattern on Android Design:
            //
            // http://developer.android.com/design/patterns/navigation.html#up-vs-back
            //
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemChosen(View labelledSpinner, AdapterView<?> adapterView, View itemView, int position, long id) {
        switch (labelledSpinner.getId()) {
            case R.id.reservation_timeslot_spinner:
                if (id != mSelectedTimeslot) {
                    TimeSlot selectedSlot = mRestaurant.getTimeSlots().get(position);
                    List<Integer> seatsNumbers = new ArrayList<>();
                    for (int i = 1, seats = selectedSlot.getAvailableSeats() - selectedSlot.getOccupiedSeats(); i <= seats; i++) {
                        seatsNumbers.add(i);
                    }

                    mSeatsSpinner.setItemsArray(seatsNumbers);
                    mSelectedSeats = 0;
                    mSelectedTimeslot = position;
                }
                break;

            case R.id.reservation_seats_spinner:
                mSelectedSeats = position;
                break;
        }
    }

    @Override
    public void onNothingChosen(View labelledSpinner, AdapterView<?> adapterView) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.reservation_fab:
                Intent doRecap = new Intent(ReservationActivity.this, ConfirmDataActivity.class);
                Reservation reservation = new Reservation(null, mRestaurant.getId(), mRestaurant.getName(), "", "", "",
                        mRestaurant.getTimeSlots().get(mSelectedTimeslot).getStartTime(),
                        mRestaurant.getTimeSlots().get(mSelectedTimeslot).getStartTime(), "", mSelectedSeats + 1,
                        ((EditText) findViewById(R.id.reservation_comment)).getText().toString(), mSelectedOrder);

                // Load data in the intent extras
                doRecap.putExtra(RecapActivity.PARAM_RESERVATION, reservation);
                doRecap.putExtra(PromotionActivity.PARAM_PROMOTION, mPromotion);

                startActivity(doRecap);
                break;
            case R.id.reservation_select_menu:
                Intent getOrder = new Intent(ReservationActivity.this, DishSelectorActivity.class);
                getOrder.putExtra(DishSelectorActivity.PARAM_ORDER, mMenu);

                startActivityForResult(getOrder, PICK_DISHES);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case PICK_DISHES:
                    mMenu = data.getParcelableArrayListExtra(DishSelectorActivity.PARAM_ORDER);
                    mSelectedOrder = new ArrayList<>();

                    double totCost = 0.0;

                    for(Dish d : mMenu) {
                        if(d.getQuantity() != 0) {
                            mSelectedOrder.add(d);
                            totCost += d.getPrice();
                        }
                    }

                    mOrderRecycler.swapAdapter(new DishListRecyclerViewAdapter(mSelectedOrder), false);
                    mTotalCostTextView.setText(String.format("%.2f€", totCost));
                    break;
            }
        }
    }

    public class DishListRecyclerViewAdapter extends RecyclerView.Adapter<DishListRecyclerViewAdapter.ViewHolder> {

        private final List<Dish> mValues;

        public DishListRecyclerViewAdapter(List<Dish> items) {
            mValues = items;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.order_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, int position) {
            holder.mItem = mValues.get(position);
            holder.mQuantityView.setText(String.format("%sx", mValues.get(position).getQuantity()));
            holder.mDishView.setText(mValues.get(position).getName());
            holder.mPriceView.setText(String.format("%s€", mValues.get(position).getPrice()));
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public final View mView;
            public final TextView mQuantityView;
            public final TextView mDishView;
            public final TextView mPriceView;
            public Dish mItem;

            public ViewHolder(View view) {
                super(view);
                mView = view;
                mQuantityView = (TextView) view.findViewById(R.id.order_quantity);
                mDishView = (TextView) view.findViewById(R.id.order_dish);
                mPriceView = (TextView) view.findViewById(R.id.order_price);
            }

            @Override
            public String toString() {
                return super.toString() + " Name: " + mDishView.getText() + " Quantity: " +
                        mQuantityView.getText() + " Price: " + mPriceView.getText();
            }
        }
    }
}
