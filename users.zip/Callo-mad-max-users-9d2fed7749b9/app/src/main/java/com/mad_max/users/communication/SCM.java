package com.mad_max.users.communication;

import android.location.Location;
import android.os.Bundle;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mad_max.users.model.Dish;
import com.mad_max.users.model.Promotion;
import com.mad_max.users.model.Reservation;
import com.mad_max.users.model.Restaurant;
import com.mad_max.users.model.Review;
import com.mad_max.users.model.TakeAway;
import com.mad_max.users.model.TimeSlot;
import com.mad_max.users.model.WorkingHour;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SCM {
    static public void getUser(String userId, final RequestStatusListener listener, final int requestCode) {
        FirebaseDatabase.getInstance().getReference("user/client/" + userId)
                .addListenerForSingleValueEvent(
                        new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    Map<String, String> result = new HashMap<>();
                                    result.put("name", dataSnapshot.child("name").getValue(String.class));
                                    result.put("surname", dataSnapshot.child("surname").getValue(String.class));
                                    listener.onRequestComplete(requestCode, result);
                                } else {
                                    listener.onRequestComplete(requestCode, null);
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError error) {
                                listener.onRequestFail(requestCode, error.toException());
                            }
                        }
                );
    }

    static public void getReservationList(String userId, final RequestStatusListener listener, final int requestCode) {
        FirebaseDatabase.getInstance().getReference("reservation").orderByChild("user")
                .equalTo(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ArrayList<Reservation> result = new ArrayList<>();

                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    result.add(getReservation(ds));
                }
                listener.onRequestComplete(requestCode, result);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                //TODO do something
                listener.onRequestFail(requestCode, error.toException());
            }
        });
    }

    static public void getTakeAwayList(String userId, final RequestStatusListener listener, final int requestCode) {
        FirebaseDatabase.getInstance().getReference("takeaway").orderByChild("user")
                .equalTo(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ArrayList<TakeAway> result = new ArrayList<>();

                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    result.add(getTakeAway(ds));
                }
                listener.onRequestComplete(requestCode, result);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                //TODO do something
                listener.onRequestFail(requestCode, error.toException());
            }
        });
    }

    static public void getDishList(String restaurantId, final RequestStatusListener listener, final int requestCode) {
        FirebaseDatabase.getInstance().getReference("dish").child(restaurantId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        ArrayList<Dish> result = new ArrayList<>();

                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            result.add(ds.getValue(Dish.class));
                        }
                        listener.onRequestComplete(requestCode, result);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        //TODO do something
                        listener.onRequestFail(requestCode, error.toException());
                    }
                });
    }

    static public void getPromotionList(String restaurantId, final RequestStatusListener listener, final int requestCode) {
        FirebaseDatabase.getInstance().getReference("promotion").child(restaurantId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        ArrayList<Promotion> result = new ArrayList<>();

                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            result.add(getPromotion(ds));
                        }
                        listener.onRequestComplete(requestCode, result);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        //TODO do something
                        listener.onRequestFail(requestCode, error.toException());
                    }
                });
    }

    static public void getReviewListFromRestaurant(final String restaurantId, final RequestStatusListener listener, final int requestCode) {
        FirebaseDatabase.getInstance().getReference("review").orderByChild("restaurant")
                .equalTo(restaurantId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ArrayList<Review> result = new ArrayList<>();
                for (DataSnapshot dsRw : dataSnapshot.getChildren()) {
                    result.add(dsRw.getValue(Review.class));
                }
                listener.onRequestComplete(requestCode, result);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                //TODO do something
                listener.onRequestFail(requestCode, error.toException());
            }
        });
    }

    static public void getReviewListFromUser(String userId, final RequestStatusListener listener, final int requestCode) {
        FirebaseDatabase.getInstance().getReference("review").orderByChild("user")
                .equalTo(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ArrayList<Review> result = new ArrayList<>();
                for (DataSnapshot dsRw : dataSnapshot.getChildren()) {
                    result.add(dsRw.getValue(Review.class));
                }
                listener.onRequestComplete(requestCode, result);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                //TODO do something
                listener.onRequestFail(requestCode, error.toException());
            }
        });
    }

    static public void getFavoriteList(String userId, final RequestStatusListener listener, final int requestCode) {
        FirebaseDatabase.getInstance().getReference("restaurant").orderByChild("favorite")
                .equalTo(true, userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<Restaurant> result = new ArrayList<>();

                if (dataSnapshot.getChildrenCount() != 0) {
                    for (DataSnapshot dn : dataSnapshot.getChildren()) {
                        result.add(getRestaurant(dn));
                    }
                }
                listener.onRequestComplete(requestCode, result);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                //TODO do something
                listener.onRequestFail(requestCode, error.toException());
            }
        });
    }

    static public List<Restaurant> getRestaurantListFromSearch(final Bundle searchOptions, final RequestStatusListener listener, final int requestCode) {
        //downloads all the restaurants, filter them for all search options
        FirebaseDatabase.getInstance().getReference("restaurant")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        List<Restaurant> result = new ArrayList<>();

                        if (dataSnapshot.getChildrenCount() != 0) {
                            for (DataSnapshot dn : dataSnapshot.getChildren()) {
                                result.add(getRestaurant(dn));
                            }
                        }

                        //get lat / long delta values
                        final int CONVERSION_CONSTANT = 111111;
                        Location location = null;
                        double deltaLat = 0.0;
                        double deltaLong = 0.0;

                        if (searchOptions.containsKey("location") && searchOptions.containsKey("distance")) {
                            int distance = searchOptions.getInt("distance");
                            location = searchOptions.getParcelable("location");
                            deltaLat = distance / CONVERSION_CONSTANT;
                            deltaLong = distance / CONVERSION_CONSTANT * Math.cos(location.getLatitude());
                        }

                        //filter
                        for (Restaurant r : result) {
                            //filter location
                            if (location != null &&
                                    (r.getLocation().getLatitude() > location.getLatitude() + deltaLat ||
                                            r.getLocation().getLatitude() < location.getLatitude() - deltaLat ||
                                            r.getLocation().getLongitude() > location.getLongitude() + deltaLong ||
                                            r.getLocation().getLongitude() < location.getLongitude() - deltaLong)) {
                                result.remove(r);
                                break;
                            }

                            //filter cost
                            if (searchOptions.containsKey("cost") && r.getCost() > searchOptions.getInt("cost")) {
                                result.remove(r);
                                break;
                            }

                            //filter time
                            if (searchOptions.containsKey("time")) {
                                boolean isOpen = false;

                                for (WorkingHour workingHour : r.getWorkingHours()) {
                                    if (workingHour.getDayOfWeek() == Calendar.getInstance().get(Calendar.DAY_OF_WEEK)) {
                                        // TODO not really sure the string comparison will work.
                                        // TODO Still, the given time should not be a string
                                        if (workingHour.getOpeningHour().compareTo(searchOptions.getString("time")) > 0 &&
                                                workingHour.getClosingHour().compareTo(searchOptions.getString("time")) < 0) {
                                            isOpen = true;
                                            break;
                                        }
                                    }
                                }

                                if (!isOpen) {
                                    result.remove(r);
                                    break;
                                }
                            }

                            if (searchOptions.containsKey("tag")) {
                                String tag = searchOptions.getString("tag");
                                boolean isRelated = false;

                                for (String s : r.getTag()) {
                                    if (tag.contentEquals(s)) {
                                        isRelated = true;
                                    }
                                }

                                if (!isRelated) {
                                    result.remove(r);
                                    break;
                                }
                            }

                            // TODO search into dishes names
                            /*if (searchOptions.containsKey("search")) {
                                String search = searchOptions.getString("search");
                                boolean isRelated = false;

                                for (String s : r.getTag()) {
                                    if(search.contains(s)) {
                                        isRelated = true;
                                    }
                                }

                                if (!isRelated) {
                                    result.remove(r);
                                    break;
                                }
                            }*/
                        }

                        listener.onRequestComplete(requestCode, result);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        //TODO do something
                        listener.onRequestFail(requestCode, error.toException());
                    }
                });
        return null;
    }

    static public void addReservation(Reservation reservation, final RequestStatusListener listener, final int requestCode) {
        reservation.setId(FirebaseDatabase.getInstance().getReference("reservation").push().getKey());
        FirebaseDatabase.getInstance().getReference("reservation/" + reservation.getId()).setValue(reservation)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        listener.onRequestComplete(requestCode, null);
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception e) {
                listener.onRequestFail(requestCode, e);
            }
        });
    }


    static public void addTakeaway(TakeAway takeaway, final RequestStatusListener listener, final int requestCode) {
        takeaway.setId(FirebaseDatabase.getInstance().getReference("takeaway").push().getKey());
        FirebaseDatabase.getInstance().getReference("takeaway/" + takeaway.getId()).setValue(takeaway)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        listener.onRequestComplete(requestCode, null);
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception e) {
                listener.onRequestFail(requestCode, e);
            }
        });
    }

    static public void addReview(Review review, final RequestStatusListener listener, final int requestCode) {
        review.setId(FirebaseDatabase.getInstance().getReference("review").push().getKey());
        FirebaseDatabase.getInstance().getReference("review/" + review.getId()).setValue(review)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        listener.onRequestComplete(requestCode, null);
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception e) {
                listener.onRequestFail(requestCode, e);
            }
        });
    }

    static public void addFavorite(String restaurantId, String userId, final RequestStatusListener listener, final int requestCode) {
        FirebaseDatabase.getInstance().getReference("restaurant/" + restaurantId + "/favorite/" + userId).setValue(true)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        listener.onRequestComplete(requestCode, null);
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception e) {
                listener.onRequestFail(requestCode, e);
            }
        });
    }

    static public void removeFavorite(String restaurantId, String userId, final RequestStatusListener listener, final int requestCode) {
        FirebaseDatabase.getInstance().getReference("restaurant/" + restaurantId + "/favorite/" + userId).removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        listener.onRequestComplete(requestCode, null);
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception e) {
                listener.onRequestFail(requestCode, e);
            }
        });
    }

    private static Restaurant getRestaurant(DataSnapshot dataSnapshot) {
        Restaurant r = new Restaurant();

        r.setId(dataSnapshot.child("id").getValue(String.class));
        r.setName(dataSnapshot.child("name").getValue(String.class));
        r.setPhone(dataSnapshot.child("phone").getValue(String.class));
        r.setAddress(dataSnapshot.child("address").getValue(String.class));
        r.setCapacity(dataSnapshot.child("capacity").getValue(int.class));

        Location l = new Location("");
        l.setLatitude(dataSnapshot.child("location/latitude").getValue(double.class));
        l.setLongitude(dataSnapshot.child("location/longitude").getValue(double.class));
        r.setLocation(l);

        r.setLogo(dataSnapshot.child("logo").getValue(String.class));
        r.setRating(dataSnapshot.child("rating").getValue(float.class));
        r.setCost(dataSnapshot.child("cost").getValue(int.class));
        r.setSettings(dataSnapshot.child("settings").getValue(Bundle.class));

        ArrayList<TimeSlot> timeSlots = new ArrayList<>();
        for (DataSnapshot dnTs : dataSnapshot.child("timeSlots").getChildren()) {
            timeSlots.add(dnTs.getValue(TimeSlot.class));
        }
        r.setTimeSlots(timeSlots);

        ArrayList<WorkingHour> workingHours = new ArrayList<>();
        for (DataSnapshot dnWh : dataSnapshot.child("workingHours").getChildren()) {
            workingHours.add(dnWh.getValue(WorkingHour.class));
        }
        r.setWorkingHours(workingHours);

        ArrayList<String> gallery = new ArrayList<>();
        for (DataSnapshot dnGl : dataSnapshot.child("gallery").getChildren()) {
            gallery.add(dnGl.getValue(String.class));
        }
        r.setGallery(gallery);

        ArrayList<String> tag = new ArrayList<>();
        for (DataSnapshot dnTg : dataSnapshot.child("tag").getChildren()) {
            tag.add(dnTg.getValue(String.class));
        }
        r.setTag(tag);

        return r;
    }

    private static Reservation getReservation(DataSnapshot dataSnapshot) {
        Reservation r = new Reservation();

        r.setId(dataSnapshot.child("id").getValue(String.class));
        r.setRestaurantId(dataSnapshot.child("restaurantId").getValue(String.class));
        r.setRestaurantName(dataSnapshot.child("restaurantName").getValue(String.class));
        r.setName(dataSnapshot.child("name").getValue(String.class));
        r.setSurname(dataSnapshot.child("surname").getValue(String.class));
        r.setCellphone(dataSnapshot.child("cellphone").getValue(String.class));
        r.setStartTime(dataSnapshot.child("startTime").getValue(String.class));
        r.setEndTime(dataSnapshot.child("endTime").getValue(String.class));
        r.setDate(dataSnapshot.child("date").getValue(String.class));
        r.setSeats(dataSnapshot.child("seats").getValue(int.class));
        r.setComment(dataSnapshot.child("comment").getValue(String.class));

        ArrayList<Dish> dishes = new ArrayList<>();
        for (DataSnapshot dsDs : dataSnapshot.getChildren()) {
            dishes.add(dsDs.getValue(Dish.class));
        }
        r.setOrder(dishes);

        return r;
    }

    private static TakeAway getTakeAway(DataSnapshot dataSnapshot) {
        TakeAway t = new TakeAway();

        t.setId(dataSnapshot.child("id").getValue(String.class));
        t.setRestaurantId(dataSnapshot.child("restaurantId").getValue(String.class));
        t.setRestaurantName(dataSnapshot.child("restaurantName").getValue(String.class));
        t.setName(dataSnapshot.child("name").getValue(String.class));
        t.setSurname(dataSnapshot.child("surname").getValue(String.class));
        t.setCellphone(dataSnapshot.child("cellphone").getValue(String.class));
        t.setDate(dataSnapshot.child("date").getValue(Date.class));
        t.setComment(dataSnapshot.child("comment").getValue(String.class));

        ArrayList<Dish> dishes = new ArrayList<>();
        for (DataSnapshot dsDs : dataSnapshot.getChildren()) {
            dishes.add(dsDs.getValue(Dish.class));
        }
        t.setOrder(dishes);

        return t;
    }

    private static Promotion getPromotion(DataSnapshot dataSnapshot) {
        Promotion p = new Promotion();

        p.setId(dataSnapshot.child("id").getValue(String.class));
        p.setImage(dataSnapshot.child("image").getValue(String.class));
        p.setName(dataSnapshot.child("name").getValue(String.class));
        p.setOccupiedSeats(dataSnapshot.child("occupiedSeats").getValue(int.class));
        p.setTotalSeats(dataSnapshot.child("totalSeats").getValue(int.class));
        p.setPrice(dataSnapshot.child("price").getValue(double.class));
        p.setDescription(dataSnapshot.child("description").getValue(String.class));
        p.setDate(dataSnapshot.child("date").getValue(Date.class));

        ArrayList<Dish> dishes = new ArrayList<>();
        for (DataSnapshot dsDs : dataSnapshot.getChildren()) {
            dishes.add(dsDs.getValue(Dish.class));
        }
        p.setMenu(dishes);

        return p;
    }
}




