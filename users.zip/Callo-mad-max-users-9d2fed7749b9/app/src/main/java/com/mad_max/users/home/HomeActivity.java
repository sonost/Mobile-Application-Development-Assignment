package com.mad_max.users.home;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mad_max.users.R;
import com.mad_max.users.communication.DownloadImageTask;
import com.mad_max.users.communication.RequestStatusListener;
import com.mad_max.users.communication.SCM;
import com.mad_max.users.map.SetRangeMapActivity;
import com.mad_max.users.model.Restaurant;
import com.mad_max.users.model.WorkingHour;
import com.mad_max.users.navigation.AbstractNavigatorActivity;
import com.mad_max.users.restaurant.RestaurantActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class HomeActivity extends AbstractNavigatorActivity implements CategoryDialog.EditDialogListener, RequestStatusListener {

    public static final String RANGE = "RANGE";

    private static final int GET_FAVORITES = 125;
    private static final int ASK_RANGE = 125;
    private static final int SEARCH_REST = 345;

    public static boolean[] isSelectedCat = {false, false, false, false, false};
    public static ArrayList<String> list = new ArrayList<>();
    public TextView cate, dist;
    public int day, hour, minute;
    public Button mButton;
    public double lat;
    public double lng;
    public int range;
    String result = " ";
    private List<Restaurant> mFavoriteList;
    private List<Restaurant> mRestaurantList;
    private RecyclerView mRecyclerView;
    private Button mFilter, mSearch;
    private EditText eSearch;
    private SeekBar seekLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.home_toolbar);
        setSupportActionBar(toolbar);

        setUpUI(toolbar);

        Calendar calendar = Calendar.getInstance();
        day = calendar.get(Calendar.DAY_OF_WEEK);
        hour = calendar.get(Calendar.HOUR_OF_DAY);
        minute = calendar.get(Calendar.MINUTE);

        mRestaurantList = null;
        mFavoriteList = new ArrayList<>();

        mRecyclerView = (RecyclerView) findViewById(R.id.rv);
        assert mRecyclerView != null;
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(new RVAdapter(mFavoriteList));

        cate = (TextView) findViewById(R.id.eCategory);
        dist = (TextView) findViewById(R.id.tDistance);

        seekLocation = (SeekBar) findViewById(R.id.seekbar_distance);
        seekLocation.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                dist.setText("Distance: " + progress + "m");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        Spinner spinner = (Spinner) findViewById(R.id.cost_spinner);
        ArrayAdapter<CharSequence> adaptCost = ArrayAdapter.createFromResource(this, R.array.cost_list, android.R.layout.simple_spinner_item);
        adaptCost.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        assert spinner != null;
        spinner.setAdapter(adaptCost);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(getBaseContext(), parent.getItemIdAtPosition(position) + " selected", Toast.LENGTH_LONG).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Spinner spinTime = (Spinner) findViewById(R.id.time_spinner);
        ArrayAdapter<CharSequence> adapTime = ArrayAdapter.createFromResource(this, R.array.time_list, android.R.layout.simple_spinner_item);
        adaptCost.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        assert spinTime != null;
        spinTime.setAdapter(adapTime);
        spinTime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(getBaseContext(), parent.getItemIdAtPosition(position) + " selected", Toast.LENGTH_LONG).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        mFilter = (Button) findViewById(R.id.bFilter);
        mFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LinearLayout one = (LinearLayout) findViewById(R.id.Main_lay_filter);
                assert one != null;
                if (one.getVisibility() == View.VISIBLE) {
                    one.setVisibility(View.GONE);
                } else {
                    one.setVisibility(View.VISIBLE);
                }

            }
        });

        mButton =(Button)findViewById(R.id.bLocation);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(mContext,
                        SetRangeMapActivity.class)
                        .putExtra("RANGE",seekLocation.getProgress())
                        .putExtra(RestaurantActivity.LAT,lat)
                        .putExtra(RestaurantActivity.LNG,lng),
                        ASK_RANGE );
            }
        });
        eSearch = (EditText) findViewById(R.id.eSearch);
        mSearch = (Button) findViewById(R.id.bSearch);
        assert mSearch != null;

        mSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchData = eSearch.getText().toString();
                if (TextUtils.isEmpty(searchData)) {
                    eSearch.setError(getString(R.string.error_field_required));
                } else {
                    //TODO build up the bundle
                    Bundle b = new Bundle();
                    b.putString("search", searchData);
                    mRestaurantList = SCM.getRestaurantListFromSearch(b, HomeActivity.this, SEARCH_REST);
                }
            }
        });

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            SCM.getFavoriteList(user.getUid(), HomeActivity.this, GET_FAVORITES);
        }
    }


    public void showDialog(View view) {
        CategoryDialog categoryDialog = new CategoryDialog();
        categoryDialog.show(getSupportFragmentManager(), "my alert");
    }

    public void updateResult(String inputText) {
        result = inputText;
        cate.setText(result);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == ASK_RANGE) {
            if(resultCode == Activity.RESULT_OK){
                range=data.getIntExtra(RANGE,0);
                lat=data.getDoubleExtra(RestaurantActivity.LAT, 0);
                lng=data.getDoubleExtra(RestaurantActivity.LNG,0);
                seekLocation.setProgress(range);


            }
            if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
            }
        }
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case GET_FAVORITES:
                mFavoriteList = (List<Restaurant>) response;

                if (mRestaurantList == null && mFavoriteList.size() != 0) {
                    mRecyclerView.swapAdapter(new RVAdapter(mFavoriteList), false);
                }
                break;
            case SEARCH_REST:
                mRestaurantList = (List<Restaurant>) response;

                if (mRestaurantList.size() != 0) {
                    mRecyclerView.swapAdapter(new RVAdapter(mRestaurantList), false);
                } else {
                    Snackbar.make(findViewById(R.id.app_bar), "No restaurants matches the given data",
                            Snackbar.LENGTH_LONG).show();
                }
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }

    public class RVAdapter extends RecyclerView.Adapter<RVAdapter.PersonViewHolder> {

        private final SimpleDateFormat mTimeFormat = new SimpleDateFormat("HH:mm");
        private List<Restaurant> mValues;

        public RVAdapter(List<Restaurant> favorites) {
            this.mValues = favorites;
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        @Override
        public PersonViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.favorite_item_layout, viewGroup, false);
            return new PersonViewHolder(v);
        }

        @Override
        public void onBindViewHolder(PersonViewHolder personViewHolder, int position) {

            final Restaurant r = mValues.get(position);

            boolean open = false;

            for (WorkingHour workingHour : r.getWorkingHours()) {
                if (workingHour.getDayOfWeek() == day) {
                    if (Integer.parseInt(workingHour.getOpeningHour().substring(0, 2)) < hour &&
                            Integer.parseInt(workingHour.getClosingHour().substring(0, 2)) > hour) {
                        open = true;
                        break;
                    }
                }
            }

            new DownloadImageTask(personViewHolder.pic).execute(r.getLogo());
            personViewHolder.name.setText(r.getName());
            personViewHolder.address.setText(r.getAddress());
            personViewHolder.telephone.setText(r.getPhone());
            personViewHolder.rateBar.setRating(r.getRating());

            if (open) {
                Spannable WordToSpan = new SpannableString("Open");
                WordToSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#0ec621")), 0, WordToSpan.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                personViewHolder.holiday.setText(WordToSpan);
            } else {
                Spannable WordToSpan = new SpannableString("Close");
                WordToSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#c2262d")), 0, WordToSpan.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                personViewHolder.holiday.setText(WordToSpan);
            }

            personViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent toRest = new Intent(HomeActivity.this, RestaurantActivity.class);
                    toRest.putExtra(RestaurantActivity.PARAM_RESTAURANT, r);
                    startActivity(toRest);
                }
            });

        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }


        public class PersonViewHolder extends RecyclerView.ViewHolder {
            CardView cv;
            ImageView pic;
            TextView name;
            TextView address;
            TextView time, timeHol;
            TextView status, holiday;
            TextView telephone;
            RatingBar rateBar;

            PersonViewHolder(View itemView) {
                super(itemView);
                cv = (CardView) itemView.findViewById(R.id.cv);
                pic = (ImageView) itemView.findViewById(R.id.Pic);
                name = (TextView) itemView.findViewById(R.id.textViewName);
                address = (TextView) itemView.findViewById(R.id.textViewAddress);
                status = (TextView) itemView.findViewById(R.id.textViewStatus);
                holiday = (TextView) itemView.findViewById(R.id.textViewHol);
                telephone = (TextView) itemView.findViewById(R.id.textViewTel);
                rateBar = (RatingBar) itemView.findViewById(R.id.rateBarFav);

            }

        }

    }
}
