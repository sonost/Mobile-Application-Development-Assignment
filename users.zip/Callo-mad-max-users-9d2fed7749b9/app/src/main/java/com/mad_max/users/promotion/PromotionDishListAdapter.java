package com.mad_max.users.promotion;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.mad_max.users.R;
import com.mad_max.users.communication.DownloadImageTask;
import com.mad_max.users.model.Dish;

import java.util.List;

public class PromotionDishListAdapter extends BaseAdapter {
    private List<Dish> mDish;
    private Context context;
    private LayoutInflater inflater = null;

    class ViewHolder {
        TextView dishSName, dishSPrice;
        ImageView dishPic;
    }

    public PromotionDishListAdapter(List<Dish> list, Context context) {
        this.context = context;
        this.mDish = list;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return mDish.size();
    }

    @Override
    public Object getItem(int position) {
        return mDish.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        Dish d = mDish.get(position);
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.promotion_item, null);
            holder.dishPic = (ImageView) convertView.findViewById(R.id.item_showdishPic);
            holder.dishSName = (TextView) convertView.findViewById(R.id.item_showdishname);
            holder.dishSPrice = (TextView) convertView.findViewById(R.id.item_showdishprice);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        new DownloadImageTask(holder.dishPic).execute(d.getImage());
        holder.dishSName.setText(d.getName());
        holder.dishSPrice.setText(String.format("%.1f €", d.getPrice()));
        return convertView;
    }


}