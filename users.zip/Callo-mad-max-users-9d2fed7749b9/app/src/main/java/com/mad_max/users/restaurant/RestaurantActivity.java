package com.mad_max.users.restaurant;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.NavUtils;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mad_max.users.R;
import com.mad_max.users.communication.DownloadImageTask;
import com.mad_max.users.communication.RequestStatusListener;
import com.mad_max.users.communication.SCM;
import com.mad_max.users.map.MapsActivity;
import com.mad_max.users.model.Dish;
import com.mad_max.users.model.Promotion;
import com.mad_max.users.model.Restaurant;
import com.mad_max.users.model.Review;
import com.mad_max.users.model.WorkingHour;
import com.mad_max.users.navigation.AbstractNavigatorActivity;
import com.mad_max.users.reservation.ReservationActivity;
import com.mad_max.users.review.ReviewAddActivity;
import com.mad_max.users.takeaway.TakeAwayActivity;

import net.i2p.android.ext.floatingactionbutton.FloatingActionButton;
import net.i2p.android.ext.floatingactionbutton.FloatingActionsMenu;

import java.util.ArrayList;
import java.util.List;

public class RestaurantActivity extends AbstractNavigatorActivity implements View.OnClickListener, RequestStatusListener {

    public static final int PUT_FAVORITE = 258;
    public static final int GET_DISHES = 898;
    public static final int GET_REVIEWS = 698;
    public static final int GET_PROMOTIONS = 798;

    public static final String PARAM_RESTAURANT = "restaurant";
    public static final String PARAM_MENU = "menu";
    public static final String LNG = "LNG";
    public static final String LAT = "LAT";
    public static final String REST_NAME = "REST_NAME";

    private Restaurant mRestaurant;
    private ArrayList<Dish> mMenu;
    private List<Promotion> mPromotionList;
    private List<Review> mReviewList;

    private boolean mCollapsedInfo;
    private ImageButton mCollapserButton;
    private AppBarLayout mHeaderLayout;
    private ValueAnimator mHeaderAnimator;

    private SectionsPagerAdapter mAdapter;

    private FloatingActionsMenu mFam;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.restaurant_activity);

        mRestaurant = getIntent().getParcelableExtra(PARAM_RESTAURANT);
        mPromotionList = new ArrayList<>();
        mReviewList = new ArrayList<>();
        mMenu = new ArrayList<>();

        mCollapsedInfo = true;
        mCollapserButton = (ImageButton) findViewById(R.id.restaurant_info_collapser);
        assert mCollapserButton != null;
        mCollapserButton.setOnClickListener(this);

        mHeaderLayout = (AppBarLayout) findViewById(R.id.restaurant_header);

        final CoordinatorLayout coordinatorLayout = (CoordinatorLayout) findViewById(R.id.restaurant_container);
        assert coordinatorLayout != null;

        // We create the animator when the layout measures has already been calculated, otherwise we
        // won't know coordinatorLayout height (using .measure() did not took in account the empty space in this case)
        coordinatorLayout.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                mHeaderAnimator = ValueAnimator.ofInt((int) getResources().getDimension(R.dimen.restaurant_info_collapsed),
                        coordinatorLayout.getMeasuredHeight() - mCollapserButton.getMeasuredHeight());
                mHeaderAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator animator) {
                        mHeaderLayout.getLayoutParams().height = (int) animator.getAnimatedValue();
                        mHeaderLayout.requestLayout();
                    }
                });
                mHeaderAnimator.setDuration(1000);

                return true;
            }
        });

        mFam = (FloatingActionsMenu) findViewById(R.id.fab_container);

        Toolbar toolbar = (Toolbar) findViewById(R.id.restaurant_toolbar);
        setSupportActionBar(toolbar);

        // Show the Up button and tabs in the action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle(mRestaurant.getName());
        }

        ImageView logoView = (ImageView) findViewById(R.id.restaurant_logo);
        new DownloadImageTask(logoView).execute(mRestaurant.getLogo());

        TextView phoneView = (TextView) findViewById(R.id.restaurant_cellphone);
        assert phoneView != null;
        phoneView.setText(mRestaurant.getPhone());
        phoneView.setOnClickListener(this);

        TextView addressView = (TextView) findViewById(R.id.restaurant_address);
        assert addressView != null;
        addressView.setText(mRestaurant.getAddress());
        addressView.setOnClickListener(this);

        StringBuilder tagString = new StringBuilder();
        for (String tag : mRestaurant.getTag()) {
            tagString.append(tag);
            tagString.append(", ");
        }

        TextView tagView = (TextView) findViewById(R.id.restaurant_tag);
        assert tagView != null;
        // Remove last comma and space
        tagView.setText(tagString.substring(0, tagString.length() - 2));

        TextView capacityView = (TextView) findViewById(R.id.restaurant_capacity);
        assert capacityView != null;
        capacityView.setText(String.format("%d seats", mRestaurant.getCapacity()));

        //TODO payment methods
        //TODO: extract strings for italian localization

        LinearLayout workingHoursLayout = (LinearLayout) findViewById(R.id.restaurant_workinghours);
        assert workingHoursLayout != null;
        for (WorkingHour wh : mRestaurant.getWorkingHours()) {
            TextView tv = new TextView(this);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            tv.setTextColor(Color.WHITE);
            tv.setText(String.format("%s: %s-%s", getResources().getStringArray(R.array.week_days)[wh.getDayOfWeek()], wh.getOpeningHour(), wh.getClosingHour()));
            workingHoursLayout.addView(tv);
        }

        LinearLayout galleryLayout = (LinearLayout) findViewById(R.id.restaurant_gallery);
        assert galleryLayout != null;
        for (String imagePath : mRestaurant.getGallery()) {
            ImageView iv = new ImageView(this);
            iv.setImageResource(android.R.drawable.ic_menu_gallery);
            iv.setAdjustViewBounds(true);
            iv.setMinimumHeight(200);
            iv.setMaxHeight(200);
            iv.setMinimumWidth(200);
            iv.setMaxWidth(200);
            galleryLayout.addView(iv);

            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) iv.getLayoutParams();
            params.setMargins(0, 0, 10, 0);

            new DownloadImageTask(iv).execute(imagePath);
        }

        // Set up the ViewPager with the sections adapter.
        /*
          The {@link ViewPager} that will host the section contents.
         */
        ViewPager viewPager = (ViewPager) findViewById(R.id.myorders_container);
        setupViewPager(viewPager);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.myorders_tabs);
        assert tabLayout != null;
        tabLayout.setupWithViewPager(viewPager);

        FloatingActionButton fabReservation = (FloatingActionButton) findViewById(R.id.fab_reservation);
        assert fabReservation != null;
        fabReservation.setOnClickListener(this);

        FloatingActionButton fabTakeAway = (FloatingActionButton) findViewById(R.id.fab_takeaway);
        assert fabTakeAway != null;
        fabTakeAway.setOnClickListener(this);

        FloatingActionButton fabReview = (FloatingActionButton) findViewById(R.id.fab_review);
        assert fabReview != null;
        fabReview.setOnClickListener(this);

        FloatingActionButton fabFavorite = (FloatingActionButton) findViewById(R.id.fab_favorite);
        assert fabFavorite != null;
        fabFavorite.setOnClickListener(this);

        SCM.getPromotionList(mRestaurant.getId(), RestaurantActivity.this, GET_PROMOTIONS);
        SCM.getReviewListFromRestaurant(mRestaurant.getId(), RestaurantActivity.this, GET_REVIEWS);
        SCM.getDishList(mRestaurant.getId(), RestaurantActivity.this, GET_DISHES);
    }

    private void setupViewPager(ViewPager viewPager) {
        /*
          The {@link android.support.v4.view.PagerAdapter} that will provide
          fragments for each of the sections. We use a
          {@link FragmentPagerAdapter} derivative, which will keep every
          loaded fragment in memory. If this becomes too memory intensive, it
          may be best to switch to a
          {@link android.support.v4.app.FragmentStatePagerAdapter}.
        */
        mAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        mAdapter.addFragment(new PromotionFragment(), getString(R.string.promotion_title));
        mAdapter.addFragment(new ReviewFragment(), getString(R.string.review_title));
        mAdapter.addFragment(new MenuFragment(), getString(R.string.menu_title));
        viewPager.setAdapter(mAdapter);
    }

    protected Restaurant getRestaurant() {
        return mRestaurant;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            // If the head is collapsed, we close it instead of going back to home activity
            if (!mCollapsedInfo) {
                mCollapserButton.callOnClick();
                return true;
            }

            // This ID represents the Home or Up button. In the case of this
            // activity, the Up button is shown. Use NavUtils to allow users
            // to navigate up one level in the application structure. For
            // more details, see the Navigation pattern on Android Design:
            //
            // http://developer.android.com/design/patterns/navigation.html#up-vs-back
            //
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (!mCollapsedInfo) {
            mCollapserButton.callOnClick();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.restaurant_cellphone:
                Intent phoneIntent = new Intent(Intent.ACTION_DIAL);
                phoneIntent.setData(Uri.parse("tel:" + mRestaurant.getPhone()));
                startActivity(phoneIntent);
                break;
            case R.id.restaurant_address:
                Intent intent = new Intent(mContext, MapsActivity.class);
                intent.putExtra(LAT, mRestaurant.getLocation().getLatitude());
                intent.putExtra(LNG, mRestaurant.getLocation().getLongitude());
                intent.putExtra(REST_NAME, mRestaurant.getName());
                startActivity(intent);
                break;
            case R.id.fab_reservation:
                if (!mMenu.isEmpty()) {
                    Intent doReservation = new Intent(RestaurantActivity.this, ReservationActivity.class);
                    doReservation.putExtra(PARAM_RESTAURANT, mRestaurant);
                    doReservation.putExtra(PARAM_MENU, mMenu);

                    startActivity(doReservation);
                    mFam.collapse();
                }
                break;
            case R.id.fab_takeaway:
                if (!mMenu.isEmpty()) {
                    Intent doTakeAway = new Intent(RestaurantActivity.this, TakeAwayActivity.class);
                    doTakeAway.putExtra(PARAM_RESTAURANT, mRestaurant);
                    doTakeAway.putExtra(PARAM_MENU, mMenu);

                    startActivity(doTakeAway);
                    mFam.collapse();
                }
                break;
            case R.id.fab_review:
                if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                    Intent doReview = new Intent(RestaurantActivity.this, ReviewAddActivity.class);
                    doReview.putExtra(PARAM_RESTAURANT, mRestaurant);

                    startActivity(doReview);
                } else {
                    Snackbar.make(findViewById(R.id.restaurant_container), "You have not confirmed your data, we " +
                            "cannot save your review", Snackbar.LENGTH_LONG).show();
                }
                break;
            case R.id.fab_favorite:
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if (user != null) {
                    SCM.addFavorite(mRestaurant.getId(), user.getUid(), RestaurantActivity.this, PUT_FAVORITE);
                } else {
                    Snackbar.make(findViewById(R.id.restaurant_container), "You have not confirmed your data, we " +
                            "cannot save your favourites restaurants", Snackbar.LENGTH_LONG).show();
                }
                mFam.collapse();
                break;
            case R.id.restaurant_info_collapser:
                if (mCollapsedInfo) {
                    mHeaderAnimator.start();

                    mCollapsedInfo = false;
                    mFam.setVisibility(View.GONE);
                } else {
                    mHeaderAnimator.reverse();

                    mCollapsedInfo = true;
                    mFam.setVisibility(View.VISIBLE);
                }
                break;
        }
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case GET_PROMOTIONS:
                mPromotionList = (List<Promotion>) response;
                if (mPromotionList.size() == 0) {
                    Snackbar.make(findViewById(R.id.restaurant_container), "No promotions has been found",
                            Snackbar.LENGTH_LONG).show();
                } else {
                    ((PromotionFragment) mAdapter.getItem(0)).setPromotionList(mPromotionList);
                }
                break;
            case GET_REVIEWS:
                mReviewList = (List<Review>) response;
                if (mReviewList.size() == 0) {
                    Snackbar.make(findViewById(R.id.restaurant_container), "No review has been found",
                            Snackbar.LENGTH_LONG).show();
                } else {
                    ((ReviewFragment) mAdapter.getItem(1)).setReviewList(mReviewList);
                }
                break;
            case GET_DISHES:
                mMenu = new ArrayList<>((List<Dish>) response);
                if (mMenu.size() == 0) {
                    Snackbar.make(findViewById(R.id.restaurant_container), "No dishes has been found",
                            Snackbar.LENGTH_LONG).show();
                } else {
                    ((MenuFragment) mAdapter.getItem(2)).setDishList(mMenu);
                }
                break;
            case PUT_FAVORITE:
                Snackbar.make(findViewById(R.id.restaurant_container), "The restaurant has been added to your favorites",
                        Snackbar.LENGTH_LONG).show();
                break;

        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }


    }

}
