package com.mad_max.users.review;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;

import com.google.firebase.auth.FirebaseAuth;
import com.mad_max.users.R;
import com.mad_max.users.communication.RequestStatusListener;
import com.mad_max.users.communication.SCM;
import com.mad_max.users.model.Restaurant;
import com.mad_max.users.model.Review;
import com.mad_max.users.restaurant.RestaurantActivity;

import java.util.Date;
import java.util.Map;

public class ReviewAddActivity extends AppCompatActivity implements RequestStatusListener {

    private static final int GET_USER = 273;
    private static final int PUT_REVIEW = 462;

    private Restaurant mRestaurant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.review_add_activity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mRestaurant = getIntent().getParcelableExtra(RestaurantActivity.PARAM_RESTAURANT);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_reviewadd);
        assert fab != null;
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SCM.getUser(FirebaseAuth.getInstance().getCurrentUser().getUid(), ReviewAddActivity.this, GET_USER);
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case GET_USER:
                Map<String, String> user = (Map<String, String>) response;
                if (user != null) {
                    Review review = new Review(null, user.get("name"), user.get("surname"),
                            mRestaurant.getId(), mRestaurant.getName(),
                            ((RatingBar) findViewById(R.id.ratingBar_General)).getRating(),
                            ((RatingBar) findViewById(R.id.ratingBar_Service)).getRating(),
                            Math.round(((RatingBar) findViewById(R.id.ratingBar_Cost)).getRating()),
                            ((EditText) findViewById(R.id.review_text)).getText().toString(), "", new Date());

                    SCM.addReview(review, ReviewAddActivity.this, PUT_REVIEW);
                } else {
                    Snackbar.make(findViewById(R.id.app_bar), "An error occurred while getting your user data",
                            Snackbar.LENGTH_LONG).show();
                }
                break;
            case PUT_REVIEW:
                Intent intent = new Intent(ReviewAddActivity.this, RestaurantActivity.class);
                intent.putExtra(RestaurantActivity.PARAM_RESTAURANT, mRestaurant);
                startActivity(intent);
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }
}
