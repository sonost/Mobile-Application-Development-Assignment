package com.mad_max.users.model;

import android.os.Parcel;
import android.os.Parcelable;

public class TimeSlot implements Parcelable {

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<TimeSlot> CREATOR = new Parcelable.Creator<TimeSlot>() {
        @Override
        public TimeSlot createFromParcel(Parcel in) {
            return new TimeSlot(in);
        }

        @Override
        public TimeSlot[] newArray(int size) {
            return new TimeSlot[size];
        }
    };
    private String mId;
    private String mStartTime;
    private String mEndTime;
    private int mAvailableSeats;
    private int mOccupiedSeats;

    private TimeSlot() {
    }

    public TimeSlot(String id, String startTime, String endTime) {
        this(id, startTime, endTime, 0, 0);
    }

    public TimeSlot(String id, String startTime, String endTime, int availableSeats) {
        this(id, startTime, endTime, availableSeats, 0);
    }

    public TimeSlot(String id, String startTime, String endTime, int availableSeats, int occupiedSeats) {
        mId = id;
        mStartTime = startTime;
        mEndTime = endTime;
        mAvailableSeats = availableSeats;
        mOccupiedSeats = occupiedSeats;
    }

    protected TimeSlot(Parcel in) {
        mId = in.readString();
        mStartTime = in.readString();
        mEndTime = in.readString();
        mAvailableSeats = in.readInt();
        mOccupiedSeats = in.readInt();
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getStartTime() {
        return mStartTime;
    }

    public void setStartTime(String startTime) {
        mStartTime = startTime;
    }

    public String getEndTime() {
        return mEndTime;
    }

    public void setEndTime(String endTime) {
        mEndTime = endTime;
    }

    public int getAvailableSeats() {
        return mAvailableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        mAvailableSeats = availableSeats;
    }

    public int getOccupiedSeats() {
        return mOccupiedSeats;
    }

    public void setOccupiedSeats(int occupiedSeats) {
        mOccupiedSeats = occupiedSeats;
    }

    @Override
    public String toString() {
        return "TimeSlot{" +
                "mId='" + mId + '\'' +
                ",mStartTime='" + mStartTime + '\'' +
                ", mEndTime='" + mEndTime + '\'' +
                ", mAvailableSeats=" + mAvailableSeats +
                ", mOccupiedSeats=" + mOccupiedSeats +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mId);
        dest.writeString(mStartTime);
        dest.writeString(mEndTime);
        dest.writeInt(mAvailableSeats);
        dest.writeInt(mOccupiedSeats);
    }
}