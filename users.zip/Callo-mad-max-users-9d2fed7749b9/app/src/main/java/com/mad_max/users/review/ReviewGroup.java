package com.mad_max.users.review;

import java.util.ArrayList;
import java.util.List;

public class ReviewGroup {


    public final List<String> children = new ArrayList<>();
    public String string;

    public ReviewGroup(String string) {
        this.string = string;
    }
}
