package com.mad_max.users.myorders;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.NavUtils;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mad_max.users.R;
import com.mad_max.users.communication.RequestStatusListener;
import com.mad_max.users.communication.SCM;
import com.mad_max.users.model.Dish;
import com.mad_max.users.model.Reservation;
import com.mad_max.users.model.TakeAway;
import com.mad_max.users.navigation.AbstractNavigatorActivity;
import com.mad_max.users.recap.RecapActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

public class MyOrdersActivity extends AbstractNavigatorActivity {
    //private static final String ARG_ORDER_NUMBER = "item_number";

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_myorders);

        Toolbar toolbar = (Toolbar) findViewById(R.id.myorders_toolbar);
        setSupportActionBar(toolbar);

        setUpUI(toolbar);

        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.myorders_container);
        assert mViewPager != null;
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.myorders_tabs);
        assert tabLayout != null;
        tabLayout.setupWithViewPager(mViewPager);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            // This ID represents the Home or Up button. In the case of this
            // activity, the Up button is shown. Use NavUtils to allow users
            // to navigate up one level in the application structure. For
            // more details, see the Navigation pattern on Android Design:
            //
            // http://developer.android.com/design/patterns/navigation.html#up-vs-back
            //
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * A reservation fragment containing a simple view.
     */
    public static class ReservationFragment extends Fragment implements RequestStatusListener {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final int GET_RESERVATIONS = 456;
        private static final String ARG_SECTION_NUMBER = "section_number";

        private List<Reservation> mReservationList;
        private RecyclerView mRecyclerView;
        private ReservationRecyclerViewAdapter mAdapter;

        public ReservationFragment() {
        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static ReservationFragment newInstance(int sectionNumber) {
            ReservationFragment fragment = new ReservationFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.myorders_reservation_fragment, container, false);
            mReservationList = new ArrayList<>();
            mAdapter = new ReservationRecyclerViewAdapter(mReservationList);
            mRecyclerView = (RecyclerView) rootView.findViewById(R.id.myorders_reservation_list);
            assert mRecyclerView != null;
            mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            mRecyclerView.setAdapter(mAdapter);

            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user != null) {
                SCM.getReservationList(user.getUid(), ReservationFragment.this, GET_RESERVATIONS);
            } else {
                Snackbar.make(getActivity().findViewById(R.id.app_bar), "You have not confirmed your data, we " +
                        "cannot save your reservations", Snackbar.LENGTH_LONG).show();
            }
            return rootView;
        }

        @Override
        public void onRequestComplete(int requestCode, Object response) {
            switch (requestCode) {
                case GET_RESERVATIONS:
                    mReservationList = (List<Reservation>) response;

                    if (mReservationList.size() == 0) {
                        Snackbar.make(getActivity().findViewById(R.id.app_bar), "No reservations were found",
                                Snackbar.LENGTH_LONG).show();
                    } else {
                        mAdapter = new ReservationRecyclerViewAdapter(mReservationList);
                        mRecyclerView.swapAdapter(mAdapter, false);
                    }
                    break;
            }
        }

        @Override
        public void onRequestFail(int requestCode, Exception exception) {

        }


        public class ReservationRecyclerViewAdapter extends RecyclerView.Adapter<ReservationRecyclerViewAdapter.ViewHolder> {

            private final List<Reservation> mValues;

            public ReservationRecyclerViewAdapter(List<Reservation> items) {
                mValues = items;
            }

            @Override
            public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.myorders_reservation_item, parent, false);
                return new ViewHolder(view);
            }

            @Override
            public void onBindViewHolder(final ViewHolder holder, int position) {
                holder.mItem = mValues.get(position);
                holder.mTimeScheduleView.setText(String.format("%s  %s - %s", mValues.get(position).getDate(),
                        mValues.get(position).getStartTime(), mValues.get(position).getEndTime()));
                holder.mSeatsView.setText(String.format("%s Seat", mValues.get(position).getSeats()));
                holder.mRestaurantView.setText(String.format("%s", mValues.get(position).getRestaurantName()));

                holder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Context context = v.getContext();
                        Intent intent = new Intent(context, RecapActivity.class);
                        Bundle b = new Bundle();
                        b.putParcelable(RecapActivity.PARAM_RESERVATION, holder.mItem);
                        intent.putExtras(b);
                        context.startActivity(intent);
                    }
                });
            }

            @Override
            public int getItemCount() {
                return mValues.size();
            }

            public class ViewHolder extends RecyclerView.ViewHolder {
                public final View mView;
                public final TextView mRestaurantView;
                public final TextView mSeatsView;
                public final TextView mTimeScheduleView;
                public Reservation mItem;

                public ViewHolder(View view) {
                    super(view);
                    mView = view;
                    mTimeScheduleView = (TextView) view.findViewById(R.id.reserved_timeschedule);
                    mSeatsView = (TextView) view.findViewById(R.id.reserved_seats);
                    mRestaurantView = (TextView) view.findViewById(R.id.reserved_restaurant);
                }
            }


        }
    }


    /**
     * A takeaway fragment containing a simple view.
     */
    public static class TakeAwayFragment extends Fragment implements RequestStatusListener {

        private static final int GET_TAKEAWAYS = 654;
        private static final String ARG_SECTION_NUMBER = "section_number";

        private List<TakeAway> mTakeAwayList;
        private RecyclerView mRecyclerView;
        private TakeAwayRecyclerViewAdapter mAdapter;

        public TakeAwayFragment() {
        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static TakeAwayFragment newInstance(int sectionNumber) {
            TakeAwayFragment fragment = new TakeAwayFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.myorders_takeaway_fragment, container, false);
            mTakeAwayList = new ArrayList<>();
            mAdapter = new TakeAwayRecyclerViewAdapter(mTakeAwayList);
            mRecyclerView = (RecyclerView) rootView.findViewById(R.id.myorders_takeaway_list);
            assert mRecyclerView != null;
            mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            mRecyclerView.setAdapter(mAdapter);

            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user != null) {
                SCM.getTakeAwayList(user.getUid(), TakeAwayFragment.this, GET_TAKEAWAYS);
            } else {
                Snackbar.make(getActivity().findViewById(R.id.app_bar), "You have not confirmed your data, we " +
                        "cannot save your reservations", Snackbar.LENGTH_LONG).show();
            }
            return rootView;
        }

        @Override
        public void onRequestComplete(int requestCode, Object response) {
            switch (requestCode) {
                case GET_TAKEAWAYS:
                    mTakeAwayList = (List<TakeAway>) response;

                    if (mTakeAwayList.size() == 0) {
                        Snackbar.make(getActivity().findViewById(R.id.app_bar), "No takeaway was found",
                                Snackbar.LENGTH_LONG).show();
                    } else {
                        mAdapter = new TakeAwayRecyclerViewAdapter(mTakeAwayList);
                        mRecyclerView.swapAdapter(mAdapter, false);
                    }
                    break;
            }
        }

        @Override
        public void onRequestFail(int requestCode, Exception exception) {

        }

        public class TakeAwayRecyclerViewAdapter extends RecyclerView.Adapter<TakeAwayRecyclerViewAdapter.ViewHolder> {

            private final List<TakeAway> mValues;

            public TakeAwayRecyclerViewAdapter(List<TakeAway> items) {
                mValues = items;
            }

            @Override
            public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.myorders_takeaway_item, parent, false);
                return new ViewHolder(view);
            }

            @Override
            public void onBindViewHolder(final ViewHolder holder, int position) {
                holder.mItem = mValues.get(position);
                Calendar calendar = GregorianCalendar.getInstance(); // creates a new calendar instance
                calendar.setTime(holder.mItem.getDate());   // assigns calendar to given date
                calendar.get(Calendar.HOUR_OF_DAY); // gets hour in 24h format
                calendar.get(Calendar.HOUR);        // gets hour in 12h format
                calendar.get(Calendar.YEAR);
                holder.mTimeScheduleView.setText(String.format("%d/%d/%d  %d : %d",
                        calendar.get(Calendar.DAY_OF_MONTH), calendar.get(Calendar.MONTH), calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE)));
                holder.mRestaurantView.setText(String.format("%s",
                        mValues.get(position).getRestaurantName()));

                double totCost = 0.0;

                for (Dish dish : holder.mItem.getOrder()) {
                    totCost += dish.getPrice() * dish.getQuantity();
                }

                holder.mPriceView.setText(String.format("%s €", totCost));
                holder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Context context = v.getContext();
                        Intent intent = new Intent(context, RecapActivity.class);
                        Bundle b = new Bundle();
                        b.putParcelable(RecapActivity.PARAM_TAKEAWAY, holder.mItem);
                        b.putBoolean(RecapActivity.PARAM_CONFIRMED, true);
                        intent.putExtras(b);
                        context.startActivity(intent);
                    }
                });
            }

            @Override
            public int getItemCount() {
                return mValues.size();
            }

            public class ViewHolder extends RecyclerView.ViewHolder {
                public final View mView;
                public final TextView mRestaurantView;
                public final TextView mTimeScheduleView;
                public final TextView mPriceView;
                public TakeAway mItem;

                public ViewHolder(View view) {
                    super(view);
                    mView = view;
                    mTimeScheduleView = (TextView) view.findViewById(R.id.takeawayed_timeschedule);
                    mRestaurantView = (TextView) view.findViewById(R.id.takeawayed_restaurant);
                    mPriceView = (TextView) view.findViewById(R.id.takeawayed_price);
                }
            }
        }
    }


    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a ReservationFragment (defined as a static inner class below).
            switch (position) {
                case 0:
                    return ReservationFragment.newInstance(position + 1);
                case 1:
                    return TakeAwayFragment.newInstance(position + 1);
            }
            return null;
        }

        @Override
        public int getCount() {
            // Show 2 total pages.
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Reservation";
                case 1:
                    return "Takeaway";
            }
            return null;
        }
    }
}
