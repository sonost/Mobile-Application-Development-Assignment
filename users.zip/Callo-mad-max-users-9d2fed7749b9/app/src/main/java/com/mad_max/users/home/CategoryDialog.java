package com.mad_max.users.home;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import com.mad_max.users.R;
import java.util.ArrayList;

public class CategoryDialog extends DialogFragment {



    String selections;

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        final String[] items = getResources().getStringArray(R.array.category_list);

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Choose Category").setMultiChoiceItems(R.array.category_list, HomeActivity.isSelectedCat, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {

                if (isChecked) {
                    HomeActivity.list.add(items[which]);
                    HomeActivity.isSelectedCat[which] = true;

                } else if (HomeActivity.list.contains(items[which])) {
                    HomeActivity.list.remove(items[which]);
                    HomeActivity.isSelectedCat[which] = false;
                }
            }
        });
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                selections = "";
                for (String ms : HomeActivity.list) {
                    selections = selections + ms + ", ";
                }

                if (!selections.isEmpty() && selections.length() > 1) {
                    selections = selections.substring(0, selections.length() - 2);
                }
                EditDialogListener activity = (EditDialogListener) getActivity();
                activity.updateResult(selections);
                dismiss();
            }
        });


        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectNeg = "";
                for (String ms : HomeActivity.list) {
                    selectNeg = selectNeg + ms;
                }
                dismiss();
            }
        });


        return builder.create();
    }


    public interface EditDialogListener {
        void updateResult(String inputText);
    }

}
