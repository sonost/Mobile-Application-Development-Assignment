package com.mad_max.users.restaurant;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import com.mad_max.users.R;
import com.mad_max.users.model.Restaurant;
import com.mad_max.users.model.Review;
import com.mad_max.users.review.RecyclerItemClickListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class ReviewFragment extends Fragment {

    private RecyclerView mRecyclerView;

    public ReviewFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Restaurant restaurant = ((RestaurantActivity) getActivity()).getRestaurant();
        List<Review> reviewList = new ArrayList<>();

        View rootView = inflater.inflate(R.layout.restaurant_review_fragment, container, false);

        RatingBar ratingView = (RatingBar) rootView.findViewById(R.id.restaurant_rating);
        assert ratingView != null;
        ratingView.setRating(restaurant.getRating());

        StringBuffer costString = new StringBuffer();
        for (int i = 0; i < restaurant.getCost(); i++) {
            costString.append("$");
        }

        TextView costView = (TextView) rootView.findViewById(R.id.restaurant_cost);
        assert costView != null;
        costView.setText(costString);

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.review_list);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        mRecyclerView.setAdapter(new ReviewListRecyclerViewAdapter(reviewList));
        mRecyclerView.addOnItemTouchListener(new RecyclerItemClickListener(this.getContext(), new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                TextView textView = (TextView) view.findViewById(R.id.textView9);

                if (textView.getVisibility() == View.VISIBLE) {
                    textView.setVisibility(View.GONE);
                } else {
                    textView.setVisibility(View.VISIBLE);
                }

            }
        }));

        return rootView;
    }

    public void setReviewList(List<Review> reviewList) {
        mRecyclerView.swapAdapter(new ReviewListRecyclerViewAdapter(reviewList), false);
    }


    public class ReviewListRecyclerViewAdapter extends RecyclerView.Adapter<ReviewListRecyclerViewAdapter.ViewHolder> {

        private final SimpleDateFormat mTimeFormat = new SimpleDateFormat("HH:mm");
        private List<Review> mValues;

        ReviewListRecyclerViewAdapter(List<Review> values) {
            this.mValues = values;
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.review_item, viewGroup, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(ViewHolder viewHolder, int i) {
            Review r = mValues.get(i);

            viewHolder.name.setText(r.getRestaurantId());
            viewHolder.general.setRating(r.getGeneralRating());
            viewHolder.service.setRating(r.getServiceRating());
            viewHolder.price.setRating(r.getCostRating());
            viewHolder.time.setText(mTimeFormat.format(r.getInsertionDate()));
            viewHolder.comment.setText(r.getComment());
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }


        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView name;
            TextView time;
            TextView comment;
            RatingBar general;
            RatingBar price;
            RatingBar service;

            ViewHolder(View itemView) {
                super(itemView);
                name = (TextView) itemView.findViewById(R.id.textViewName);
                general = (RatingBar) itemView.findViewById(R.id.ratingBar4);
                price = (RatingBar) itemView.findViewById(R.id.ratingBar6);
                service = (RatingBar) itemView.findViewById(R.id.ratingBar5);
                time = (TextView) itemView.findViewById(R.id.timeView);
                comment = (TextView) itemView.findViewById(R.id.textView9);
            }
        }

    }
}