package com.mad_max.users.restaurant;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mad_max.users.R;
import com.mad_max.users.communication.DownloadImageTask;
import com.mad_max.users.model.Promotion;
import com.mad_max.users.model.Restaurant;
import com.mad_max.users.promotion.PromotionActivity;
import com.mad_max.users.review.RecyclerItemClickListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class PromotionFragment extends Fragment {

    private RecyclerView mRecyclerView;

    public PromotionFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final Restaurant r = ((RestaurantActivity) getActivity()).getRestaurant();
        final List<Promotion> promotionList = new ArrayList<>();

        View rootView = inflater.inflate(R.layout.restaurant_promotion_fragment, container, false);

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.promotion_list);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        mRecyclerView.setAdapter(new PromotionRecyclerAdapter(promotionList));
        mRecyclerView.addOnItemTouchListener(new RecyclerItemClickListener(this.getContext(), new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent i = new Intent(PromotionFragment.this.getContext(), PromotionActivity.class);
                i.putExtra(RestaurantActivity.PARAM_RESTAURANT, r);
                i.putExtra(PromotionActivity.PARAM_PROMOTION, promotionList.get(position));

                startActivity(i);
            }
        }));


        return rootView;
    }

    public void setPromotionList(List<Promotion> promotionList) {
        mRecyclerView.swapAdapter(new PromotionRecyclerAdapter(promotionList), false);
    }

    public class PromotionRecyclerAdapter extends RecyclerView.Adapter<PromotionRecyclerAdapter.ViewHolder> {

        private final SimpleDateFormat mTimeFormat = new SimpleDateFormat("HH:mm");
        private List<Promotion> mValues;

        PromotionRecyclerAdapter(List<Promotion> values) {
            mValues = values;
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.restaurant_promotion_item, viewGroup, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int i) {
            Promotion p = mValues.get(i);

            new DownloadImageTask(holder.image).execute(p.getImage());
            holder.name.setText(p.getName());
            holder.price.setText(String.format("%.2f€", p.getPrice()));
            holder.availableSeats.setText(String.format("%d /", p.getOccupiedSeats()));
            holder.totalSeats.setText(String.valueOf(p.getTotalSeats()));
            holder.date.setText(mTimeFormat.format(p.getDate()));
            holder.description.setText(p.getDescription());
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView image;
            TextView name;
            TextView price;
            TextView availableSeats;
            TextView totalSeats;
            TextView date;
            TextView description;

            ViewHolder(View itemView) {
                super(itemView);

                image = (ImageView) itemView.findViewById(R.id.picOff);
                name = (TextView) itemView.findViewById(R.id.nameOff);
                price = (TextView) itemView.findViewById(R.id.priceOff);
                availableSeats = (TextView) itemView.findViewById(R.id.avaiOff);
                totalSeats = (TextView) itemView.findViewById(R.id.totOff);
                date = (TextView) itemView.findViewById(R.id.dateOff);
                description = (TextView) itemView.findViewById(R.id.desOff);
            }
        }

    }
}