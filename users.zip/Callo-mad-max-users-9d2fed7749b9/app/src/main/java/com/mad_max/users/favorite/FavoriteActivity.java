package com.mad_max.users.favorite;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mad_max.users.R;
import com.mad_max.users.communication.DownloadImageTask;
import com.mad_max.users.communication.RequestStatusListener;
import com.mad_max.users.communication.SCM;
import com.mad_max.users.model.Restaurant;
import com.mad_max.users.model.WorkingHour;
import com.mad_max.users.navigation.AbstractNavigatorActivity;
import com.mad_max.users.restaurant.RestaurantActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class FavoriteActivity extends AbstractNavigatorActivity implements RequestStatusListener {
    private static final int GET_FAVORITES = 125;
    public int day, hour, minute;
    private List<Restaurant> mFavoriteList;
    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_favorite);

        Toolbar toolbar = (Toolbar) findViewById(R.id.favorite_toolbar);
        setSupportActionBar(toolbar);

        setUpUI(toolbar);

        mFavoriteList = new ArrayList<>();

        mRecyclerView = (RecyclerView) findViewById(R.id.rv);
        assert mRecyclerView != null;
        mRecyclerView.setAdapter(new RVAdapter(mFavoriteList));
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        Calendar calendar = Calendar.getInstance();
        day = calendar.get(Calendar.DAY_OF_WEEK);
        hour = calendar.get(Calendar.HOUR_OF_DAY);
        minute = calendar.get(Calendar.MINUTE);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            SCM.getFavoriteList(user.getUid(), FavoriteActivity.this, GET_FAVORITES);
        } else {
            Snackbar.make(findViewById(R.id.app_bar), "You have not confirmed your data, we " +
                    "cannot save your favourites restaurants", Snackbar.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case GET_FAVORITES:
                mFavoriteList = (List<Restaurant>) response;

                if (mFavoriteList.size() == 0) {
                    Snackbar.make(findViewById(R.id.app_bar), "No favorites has been added",
                            Snackbar.LENGTH_LONG).show();
                } else {
                    mRecyclerView.swapAdapter(new RVAdapter(mFavoriteList), false);
                }
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }

    public class RVAdapter extends RecyclerView.Adapter<RVAdapter.PersonViewHolder> {

        private final SimpleDateFormat mTimeFormat = new SimpleDateFormat("HH:mm");
        private List<Restaurant> mValues;

        public RVAdapter(List<Restaurant> favorites) {
            this.mValues = favorites;
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        @Override
        public PersonViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.favorite_item_layout, viewGroup, false);
            return new PersonViewHolder(v);
        }

        @Override
        public void onBindViewHolder(PersonViewHolder personViewHolder, int position) {

            final Restaurant r = mValues.get(position);

            boolean open = false;

            for (WorkingHour workingHour : r.getWorkingHours()) {
                if (workingHour.getDayOfWeek() == day) {
                    if (Integer.parseInt(workingHour.getOpeningHour().substring(0, 2)) < hour &&
                            Integer.parseInt(workingHour.getClosingHour().substring(0, 2)) > hour) {
                        open = true;
                        break;
                    }
                }
            }

            new DownloadImageTask(personViewHolder.pic).execute(r.getLogo());
            personViewHolder.name.setText(r.getName());
            personViewHolder.address.setText(r.getAddress());
            personViewHolder.telephone.setText(r.getPhone());
            personViewHolder.rateBar.setRating(r.getRating());

            if (open) {
                Spannable WordToSpan = new SpannableString("Open");
                WordToSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#0ec621")), 0, WordToSpan.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                personViewHolder.holiday.setText(WordToSpan);
            } else {
                Spannable WordToSpan = new SpannableString("Close");
                WordToSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#c2262d")), 0, WordToSpan.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                personViewHolder.holiday.setText(WordToSpan);
            }

            personViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent toRest = new Intent(FavoriteActivity.this, RestaurantActivity.class);
                    toRest.putExtra(RestaurantActivity.PARAM_RESTAURANT, r);
                    startActivity(toRest);
                }
            });

        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }


        public class PersonViewHolder extends RecyclerView.ViewHolder {
            CardView cv;
            ImageView pic;
            TextView name;
            TextView address;
            TextView time, timeHol;
            TextView status, holiday;
            TextView telephone;
            RatingBar rateBar;

            PersonViewHolder(View itemView) {
                super(itemView);
                cv = (CardView) itemView.findViewById(R.id.cv);
                pic = (ImageView) itemView.findViewById(R.id.Pic);
                name = (TextView) itemView.findViewById(R.id.textViewName);
                address = (TextView) itemView.findViewById(R.id.textViewAddress);
                status = (TextView) itemView.findViewById(R.id.textViewStatus);
                holiday = (TextView) itemView.findViewById(R.id.textViewHol);
                telephone = (TextView) itemView.findViewById(R.id.textViewTel);
                rateBar = (RatingBar) itemView.findViewById(R.id.rateBarFav);

            }

        }

    }

}
