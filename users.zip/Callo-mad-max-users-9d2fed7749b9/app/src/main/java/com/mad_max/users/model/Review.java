package com.mad_max.users.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

public class Review implements Parcelable {
    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Review> CREATOR = new Parcelable.Creator<Review>() {
        @Override
        public Review createFromParcel(Parcel in) {
            return new Review(in);
        }

        @Override
        public Review[] newArray(int size) {
            return new Review[size];
        }
    };
    private String mId;
    private String mName;
    private String mSurname;
    private String mRestaurantId;
    private String mRestaurantName;
    private float mGeneralRating;
    private float mServiceRating;
    private int mCostRating;
    private String mComment;
    private String mReply;
    private Date mInsertionDate;

    private Review() {
    }

    public Review(String id, String name, String surname, String restaurantId, String restaurantName, float generalRating, float serviceRating, int costRating, String comment, String reply, Date insertionDate) {
        mId = id;
        mName = name;
        mSurname = surname;
        mRestaurantId = restaurantId;
        mRestaurantName = restaurantName;

        mGeneralRating = generalRating;
        mServiceRating = serviceRating;
        mCostRating = costRating;
        mComment = comment;
        mReply = reply;
        mInsertionDate = insertionDate;
    }

    protected Review(Parcel in) {
        mId = in.readString();
        mName = in.readString();
        mSurname = in.readString();
        mRestaurantId = in.readString();
        mRestaurantName = in.readString();
        mGeneralRating = in.readFloat();
        mServiceRating = in.readFloat();
        mCostRating = in.readInt();
        mComment = in.readString();
        mReply = in.readString();
        long tmpMInsertionDate = in.readLong();
        mInsertionDate = tmpMInsertionDate != -1 ? new Date(tmpMInsertionDate) : null;
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getSurname() {
        return mSurname;
    }

    public void setSurname(String surname) {
        mSurname = surname;
    }

    public String getRestaurantId() {
        return mRestaurantId;
    }

    public void setRestaurantId(String restaurantId) {
        mRestaurantId = restaurantId;
    }

    public String getRestaurantName() {
        return mRestaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        mRestaurantName = restaurantName;
    }

    public float getGeneralRating() {
        return mGeneralRating;
    }

    public void setGeneralRating(float generalRating) {
        mGeneralRating = generalRating;
    }

    public float getServiceRating() {
        return mServiceRating;
    }

    public void setServiceRating(float serviceRating) {
        mServiceRating = serviceRating;
    }

    public int getCostRating() {
        return mCostRating;
    }

    public void setCostRating(int costRating) {
        mCostRating = costRating;
    }

    public String getComment() {
        return mComment;
    }

    public void setComment(String comment) {
        mComment = comment;
    }

    public String getReply() {
        return mReply;
    }

    public void setReply(String reply) {
        mReply = reply;
    }

    public Date getInsertionDate() {
        return mInsertionDate;
    }

    public void setInsertionDate(Date insertionDate) {
        mInsertionDate = insertionDate;
    }

    @Override
    public String toString() {
        return "Review{" +
                "mId='" + mId + '\'' +
                ", mName='" + mName + '\'' +
                ", mSurname='" + mSurname + '\'' +
                ", mRestaurant='" + mRestaurantId + '\'' +
                ", mGeneralRating=" + mGeneralRating +
                ", mServiceRating=" + mServiceRating +
                ", mCostRating=" + mCostRating +
                ", mComment='" + mComment + '\'' +
                ", mReply='" + mReply + '\'' +
                ", mInsertionDate=" + mInsertionDate +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mId);
        dest.writeString(mName);
        dest.writeString(mSurname);
        dest.writeString(mRestaurantId);
        dest.writeString(mRestaurantName);
        dest.writeFloat(mGeneralRating);
        dest.writeFloat(mServiceRating);
        dest.writeInt(mCostRating);
        dest.writeString(mComment);
        dest.writeString(mReply);
        dest.writeLong(mInsertionDate != null ? mInsertionDate.getTime() : -1L);
    }
}