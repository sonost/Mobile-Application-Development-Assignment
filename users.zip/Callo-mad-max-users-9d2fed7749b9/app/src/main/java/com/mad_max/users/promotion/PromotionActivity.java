package com.mad_max.users.promotion;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.mad_max.users.R;
import com.mad_max.users.model.Promotion;
import com.mad_max.users.model.Restaurant;
import com.mad_max.users.reservation.ReservationActivity;
import com.mad_max.users.restaurant.RestaurantActivity;
import com.mad_max.users.takeaway.TakeAwayActivity;

import net.i2p.android.ext.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Receive Promotion and present it.
 * FABmenu is used to send the Promotion to TakeAway and Reservation
 */
public class PromotionActivity extends AppCompatActivity {
    public static final String PARAM_PROMOTION = "promotion";

    private Promotion mPromotion;
    private ListView mDishs;
    private Restaurant mRestaurant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.promotion_activity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.promotion_toolbar);
        setSupportActionBar(toolbar);

        // Show the Up button and tabs in the action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        mRestaurant = getIntent().getParcelableExtra(RestaurantActivity.PARAM_RESTAURANT);
        mPromotion = getIntent().getParcelableExtra(PARAM_PROMOTION);
        mDishs = (ListView) findViewById(R.id.promo_dishlist);
        mDishs.setAdapter(new PromotionDishListAdapter(mPromotion.getMenu(), this));

        ((TextView) findViewById(R.id.promo_name)).setText(String.format("Name: %s",mPromotion.getName()));
        ((TextView) findViewById(R.id.promo_price)).setText(String.format("Price: %.2f €", mPromotion.getPrice()));
        ((TextView) findViewById(R.id.promo_seat)).setText(String.format("Occupied: %d / %d ",
                mPromotion.getOccupiedSeats(), mPromotion.getTotalSeats()));
        Calendar calendar = GregorianCalendar.getInstance(); // creates a new calendar instance
        calendar.setTime(mPromotion.getDate());   // assigns calendar to given date
        calendar.get(Calendar.HOUR_OF_DAY); // gets hour in 24h format
        calendar.get(Calendar.HOUR);        // gets hour in 12h format
        calendar.get(Calendar.YEAR);
        ((TextView) findViewById(R.id.promo_date)).setText(String.format("Expire: %d/%d/%d",
                calendar.get(Calendar.DAY_OF_MONTH), calendar.get(Calendar.MONTH), calendar.get(Calendar.YEAR)));

        ((TextView) findViewById(R.id.promo_des)).setText(String.format("Description: %s",mPromotion.getDescription()));
        ((ImageView) findViewById(R.id.promo_pic)).setImageURI(Uri.parse(mPromotion.getImage()));

        final FloatingActionButton actionReservation = (FloatingActionButton) findViewById(R.id.action_RESERVATION);
        assert actionReservation != null;
        actionReservation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), ReservationActivity.class);
                intent.putExtra(RestaurantActivity.PARAM_RESTAURANT, mRestaurant);
                intent.putExtra(RestaurantActivity.PARAM_MENU, new ArrayList<>(mPromotion.getMenu()));
                intent.putExtra(PromotionActivity.PARAM_PROMOTION, mPromotion);
                startActivity(intent);
            }
        });

        final FloatingActionButton actionTakeaway = (FloatingActionButton) findViewById(R.id.action_TAKEAWAY);
        assert actionTakeaway != null;
        actionTakeaway.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), TakeAwayActivity.class);
                intent.putExtra(RestaurantActivity.PARAM_RESTAURANT, mRestaurant);
                intent.putExtra(RestaurantActivity.PARAM_MENU, new ArrayList<>(mPromotion.getMenu()));
                intent.putExtra(PromotionActivity.PARAM_PROMOTION, mPromotion);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            // This ID represents the Home or Up button. In the case of this
            // activity, the Up button is shown. Use NavUtils to allow users
            // to navigate up one level in the application structure. For
            // more details, see the Navigation pattern on Android Design:
            //
            // http://developer.android.com/design/patterns/navigation.html#up-vs-back
            //
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
