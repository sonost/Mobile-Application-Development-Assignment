package com.mad_max.users.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Dish implements Parcelable {

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Dish> CREATOR = new Parcelable.Creator<Dish>() {
        @Override
        public Dish createFromParcel(Parcel in) {
            return new Dish(in);
        }

        @Override
        public Dish[] newArray(int size) {
            return new Dish[size];
        }
    };
    private String mId;
    private String mRestaurant;
    private String mImage;
    private String mName;
    private String mCategory;
    private double mPrice;
    private int mQuantity;

    private Dish() {
    }

    public Dish(String id, String restaurant, String name, String category, double price) {
        this(id, restaurant, "", name, category, price, 0);
    }

    public Dish(String id, String restaurant, String image, String name, String category, double price) {
        this(id, restaurant, image, name, category, price, 0);
    }

    public Dish(String id, String restaurant, String name, String category, double price, int quantity) {
        this(id, restaurant, "", name, category, price, quantity);
    }

    public Dish(String id, String restaurant, String image, String name, String category, double price, int quantity) {
        mId = id;
        mRestaurant = restaurant;

        mName = name;
        mCategory = category;
        mImage = image;
        mPrice = price;
        mQuantity = quantity;
    }

    protected Dish(Parcel in) {
        mId = in.readString();
        mRestaurant = in.readString();
        mImage = in.readString();
        mName = in.readString();
        mCategory = in.readString();
        mPrice = in.readDouble();
        mQuantity = in.readInt();
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getRestaurant() {
        return mRestaurant;
    }

    public void setRestaurant(String restaurant) {
        mRestaurant = restaurant;
    }

    public String getImage() {
        return mImage;
    }

    public void setImage(String image) {
        mImage = image;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getCategory() {
        return mCategory;
    }

    public void setCategory(String category) {
        mCategory = category;
    }

    public double getPrice() {
        return mPrice;
    }

    public void setPrice(double price) {
        mPrice = price;
    }

    public int getQuantity() {
        return mQuantity;
    }

    public void setQuantity(int quantity) {
        mQuantity = quantity;
    }

    @Override
    public String toString() {
        return "Dish{" +
                "mId=" + mId +
                ", mRestaurant='" + mRestaurant + '\'' +
                ", mImage='" + mImage + '\'' +
                ", mName='" + mName + '\'' +
                ",mCategory=" + mCategory + '\'' +
                ", mPrice=" + mPrice +
                ", mQuantity=" + mQuantity +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mId);
        dest.writeString(mRestaurant);
        dest.writeString(mImage);
        dest.writeString(mName);
        dest.writeString(mCategory);
        dest.writeDouble(mPrice);
        dest.writeInt(mQuantity);
    }
}