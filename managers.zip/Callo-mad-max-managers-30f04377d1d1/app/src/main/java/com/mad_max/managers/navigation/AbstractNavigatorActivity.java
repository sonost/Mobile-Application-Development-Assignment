package com.mad_max.managers.navigation;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mad_max.managers.R;
import com.mad_max.managers.home.HomeActivity;
import com.mad_max.managers.login.UserResponse;
import com.mad_max.managers.menu.MenuActivity;
import com.mad_max.managers.miscellaneous.MadMaxApplication;
import com.mad_max.managers.promotion.PromotionActivity;
import com.mad_max.managers.reservation.ReservationTimeSlotActivity;
import com.mad_max.managers.review.ReviewActivity;
import com.mad_max.managers.settings.SettingsActivity;
import com.mad_max.managers.takeaway.TakeAwayListActivity;

public abstract class AbstractNavigatorActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    public RequestQueue mQueue;
    public String mEmail;
    public String mPassword;
    public Context mContext;
    public TextView mTextView1;
    public TextView mTextView2;
    public ImageView mImageView;
    private String mToken;
    private UserResponse mUserResponse;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth = FirebaseAuth.getInstance();

        mContext = this;
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in

                } else {
                    // User is signed out
                    Intent intent = new Intent(mContext, HomeActivity.class);
                    startActivity(intent);
                    finish();
                }
                // ...
            }
        };
//        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.sharedpreferences), Context.MODE_PRIVATE);
//        mEmail = sharedPreferences.getString(getString(R.string.user_email), "");
//        mPassword = sharedPreferences.getString(getString(R.string.user_password), "");
        // userInformationGetter(mEmail, mPassword);


        //set username and password
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer == null) super.onBackPressed();
        else if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        setUpDrawerMenu();
        return true;
    }

    private void setUpDrawerMenu() {
        mTextView1 = (TextView) findViewById(R.id.nav_user_name);
        mTextView2 = (TextView) findViewById(R.id.nav_user_email);
        mImageView = (ImageView) findViewById(R.id.imageView);
        Update();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent i = new Intent(mContext, SettingsActivity.class);

            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        if(((MadMaxApplication) getApplication()).getRestaurant() != null) {
// Handle navigation view item clicks he1re.
            int id = item.getItemId();

            if (id == R.id.nav_home && this.getClass() != HomeActivity.class) {
                Intent i = new Intent(mContext, HomeActivity.class);
                startActivity(i);
                finish();
            } else if (id == R.id.nav_reservation && this.getClass() != ReservationTimeSlotActivity.class) {
                Intent i = new Intent(mContext, ReservationTimeSlotActivity.class);
                startActivity(i);
                finish();
            } else if (id == R.id.nav_takeaway && this.getClass() != TakeAwayListActivity.class) {
                Intent i = new Intent(mContext, TakeAwayListActivity.class);
                startActivity(i);
                finish();
            } else if (id == R.id.nav_promotions && this.getClass() != PromotionActivity.class) {
                Intent i = new Intent(mContext, PromotionActivity.class);
                startActivity(i);
                finish();
            } else if (id == R.id.nav_menu && this.getClass() != MenuActivity.class) {
                Intent i = new Intent(mContext, MenuActivity.class);
                startActivity(i);
                finish();
            } else if (id == R.id.nav_statistics && this.getClass() != ReservationTimeSlotActivity.class) {

            } else if (id == R.id.nav_reviews && this.getClass() != ReviewActivity.class) {
                Intent i = new Intent(mContext, ReviewActivity.class);
                startActivity(i);
                finish();
            } else if (id == R.id.nav_settings) {
                Intent i = new Intent(mContext, SettingsActivity.class);
                startActivity(i);
            } else if (id == R.id.nav_logout && this.getClass() != ReservationTimeSlotActivity.class) {
                FirebaseAuth.getInstance().signOut();


            }

            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            assert drawer != null;
            drawer.closeDrawer(GravityCompat.START);
        } else {
            Toast.makeText(getApplicationContext(), "It's not possible to navigate to other sections:" +
                    " insert your restaurant info to proceed", Toast.LENGTH_SHORT).show();
        }

        return true;
    }


    public void userInformationGetter(String mEmail, String mPassword) {


       /* String postUrl = "url login";
        LoginRequest pojoRequest = new LoginRequest();
        pojoRequest.setPassword(mPassword);
        pojoRequest.setEmail(mEmail);
        Gson gson = new Gson();
        String jsonRequest = gson.toJson(pojoRequest);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, postUrl,
                jsonRequest, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Gson gson = new Gson();
                LoginResponse loginResponse = gson.fromJson(response.toString(), LoginResponse.class);
                if (loginResponse.getToken() == null) {
                    Intent loginIntent = new Intent(mContext, LoginActivity.class);
                    startActivity(loginIntent);
                }
                mToken = loginResponse.getToken();


                String getUrl = "url user information";
                JsonObjectRequest jsonRequest = new JsonObjectRequest(Request.Method.GET, getUrl, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        if (response == null) {
                            Intent loginIntent = new Intent(mContext, LoginActivity.class);
                            startActivity(loginIntent);
                        }
                        Gson gson = new Gson();

                        UserResponse userResponse = gson.fromJson(response.toString(), UserResponse.class);
                        if (!userResponse.isFlag()) {
                            Intent loginIntent = new Intent(mContext, LoginActivity.class);
                            startActivity(loginIntent);
                        }
                        mUserResponse = userResponse;
                        Update();
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("Authorization", "Bearer " + mToken);
                        return params;
                    }


                };
                mQueue.add(jsonRequest);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

// Add the request to the RequestQueue.
        mQueue.add(jsonObjectRequest);

        */


    }


    private FirebaseAuth.AuthStateListener mAuthListener;


    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    public void Update() {
        mUserResponse = null;
        if (mUserResponse == null) {
            final SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.PREF_FILE), MODE_PRIVATE);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mTextView1 != null) {
                        mTextView1.setText("Pallo");
                    }
                    if (mTextView2 != null) {
                        mTextView2.setText(sharedPreferences.getString("email", "paolo.caleffi@studenti.polito.it"));
                    }
                }
            });

            return;
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TextView textView1 = (TextView) findViewById(R.id.nav_user_name);
                TextView textView2 = (TextView) findViewById(R.id.nav_user_email);
                textView1.setText(mUserResponse.getData().getName());
                textView2.setText(mUserResponse.getData().getEmail());

            }


        });
    }

    public void setUpUI(Toolbar toolbar) {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        mTextView1 = (TextView) findViewById(R.id.nav_user_name);
        mTextView2 = (TextView) findViewById(R.id.nav_user_email);

        Update();

    }

}