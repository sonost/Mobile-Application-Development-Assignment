package com.mad_max.managers.reservation;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.NavUtils;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.RequestStatusListener;
import com.mad_max.managers.communication.SCM;
import com.mad_max.managers.miscellaneous.SimpleDividerItemDecoration;
import com.mad_max.managers.model.Reservation;
import com.mad_max.managers.model.Restaurant;
import com.mad_max.managers.model.TimeSlot;

import java.util.ArrayList;
import java.util.List;

import biz.kasual.materialnumberpicker.MaterialNumberPicker;

/**
 * An activity representing a single TimeSlot detail screen. This
 * activity is only used narrow width devices. On tablet-size devices,
 * item details are presented side-by-side with a list of items
 * in a {@link ReservationTimeSlotActivity}.
 */
public class ReservationListActivity extends AppCompatActivity implements View.OnClickListener, RequestStatusListener {
    public static final String ARG_RESTAURANT = "restaurant";
    public static final String ARG_TIMESLOT = "timeslot";

    private final static int GET_RESERVATIONS = 300;
    private final static int UPDATE_TIMESLOT = 400;

    private Restaurant mRestaurant;
    private TimeSlot mTimeSlot;
    private List<Reservation> mReservationList;

    private FloatingActionButton mBlockReservation;
    private Button mAvailableSeats;
    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_list_activity);

        mRestaurant = getIntent().getParcelableExtra(ARG_RESTAURANT);
        mTimeSlot = getIntent().getParcelableExtra(ARG_TIMESLOT);

        mReservationList = new ArrayList<>();

        Toolbar toolbar = (Toolbar) findViewById(R.id.timeslot_detail_toolbar);
        setSupportActionBar(toolbar);

        mBlockReservation = (FloatingActionButton) findViewById(R.id.block_reservation);
        if (mBlockReservation != null) {
            mBlockReservation.setOnClickListener(this);

            if (mTimeSlot.getAvailableSeats() <= mTimeSlot.getOccupiedSeats()) {
                mBlockReservation.setEnabled(false);
                mBlockReservation.setBackgroundTintList(ColorStateList.valueOf(Color.GRAY));
            }
        }

        // Show the Up button in the action bar.
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);

        mRecyclerView = (RecyclerView) findViewById(R.id.reservation_list);
        assert mRecyclerView != null;
        setupRecyclerView();

        CollapsingToolbarLayout appBarLayout = (CollapsingToolbarLayout) findViewById(
                R.id.timeslot_detail_collapsing_toolbar);
        assert appBarLayout != null;
        appBarLayout.setTitle(mTimeSlot.getStartTime() + " - " + mTimeSlot.getEndTime());

        ((TextView) findViewById(R.id.timeslot_detail_occupied_seats)).setText(
                String.format("%d /", mTimeSlot.getOccupiedSeats()));
        mAvailableSeats = (Button) findViewById(R.id.timeslot_detail_available_seats);
        assert mAvailableSeats != null;
        mAvailableSeats.setOnClickListener(this);
        mAvailableSeats.setText(String.format("%d", mTimeSlot.getAvailableSeats()));

        SCM.getReservationList(mRestaurant.getName(), mTimeSlot.getStartTime(),
                mTimeSlot.getEndTime(), ReservationListActivity.this, GET_RESERVATIONS);
    }

    private void setupRecyclerView() {
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(new ReservationListRecyclerViewAdapter(mReservationList));
        mRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(this));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            // This ID represents the Home or Up button. In the case of this
            // activity, the Up button is shown. Use NavUtils to allow users
            // to navigate up one level in the application structure. For
            // more details, see the Navigation pattern on Android Design:
            //
            // http://developer.android.com/design/patterns/navigation.html#up-vs-back
            //
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v.equals(mBlockReservation)) {
            mTimeSlot.setAvailableSeats(mTimeSlot.getOccupiedSeats());
            mBlockReservation.setEnabled(false);
            mBlockReservation.setBackgroundTintList(ColorStateList.valueOf(Color.GRAY));
            mAvailableSeats.setText(String.format("%d", mTimeSlot.getAvailableSeats()));

            SCM.updateTimeSlot(mTimeSlot, mRestaurant.getId(),
                    ReservationListActivity.this, UPDATE_TIMESLOT);
        } else if (v.equals(mAvailableSeats)) {
            final MaterialNumberPicker numberPicker = new MaterialNumberPicker.Builder(this)
                    .minValue(mTimeSlot.getOccupiedSeats())
                    .maxValue(getSharedPreferences(getString(R.string.PREF_FILE), MODE_PRIVATE).getInt(getString(R.string.TEXT_CAP), 20))
                    .defaultValue(mTimeSlot.getAvailableSeats())
                    .separatorColor(Color.GRAY)
                    .build();

            new AlertDialog.Builder(this)
                    .setTitle(R.string.reservation_available_seats_chooser)
                    .setView(numberPicker)
                    .setPositiveButton(getString(android.R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            mTimeSlot.setAvailableSeats(numberPicker.getValue());
                            mAvailableSeats.setText(String.format("%d", mTimeSlot.getAvailableSeats()));
                            if (mTimeSlot.getAvailableSeats() > mTimeSlot.getOccupiedSeats()) {
                                mBlockReservation.setEnabled(true);
                                mBlockReservation.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(getBaseContext(), R.color.colorAccent)));
                            } else {
                                mBlockReservation.setEnabled(false);
                                mBlockReservation.setBackgroundTintList(ColorStateList.valueOf(Color.GRAY));
                            }

                            SCM.updateTimeSlot(mTimeSlot, mRestaurant.getId(),
                                    ReservationListActivity.this, UPDATE_TIMESLOT);
                        }
                    })
                    .show();
        }
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case GET_RESERVATIONS:
                mReservationList = (List<Reservation>) response;

                if(mReservationList.size() == 0) {
                    Snackbar.make(findViewById(R.id.app_bar), "No reservations has been added for this time slot",
                            Snackbar.LENGTH_LONG).show();
                } else {
                    mRecyclerView.swapAdapter(new ReservationListRecyclerViewAdapter(mReservationList), false);
                }
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }

    public class ReservationListRecyclerViewAdapter extends RecyclerView.Adapter<ReservationListRecyclerViewAdapter.ViewHolder> {

        private final List<Reservation> mValues;

        public ReservationListRecyclerViewAdapter(List<Reservation> items) {
            mValues = items;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.reservation_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, int position) {
            final Reservation r = mValues.get(position);
            holder.mNameView.setText(String.format("%s %s", r.getName(), r.getSurname()));
            holder.mCellphoneView.setText(r.getCellphone());
            holder.mSeatsView.setText(String.format("%d seats", r.getSeats()));
            holder.mOrderView.setVisibility((r.getOrder().isEmpty()) ? View.GONE : View.VISIBLE);

            holder.mView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Context context = v.getContext();
                    Intent intent = new Intent(context, ReservationDetailActivity.class);
                    intent.putExtra(ReservationDetailActivity.ARG_RESERVATION, r);

                    context.startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public final View mView;
            public final TextView mNameView;
            public final TextView mCellphoneView;
            public final TextView mSeatsView;
            public final ImageView mOrderView;

            public ViewHolder(View view) {
                super(view);
                mView = view;
                mNameView = (TextView) view.findViewById(R.id.reservation_name);
                mCellphoneView = (TextView) view.findViewById(R.id.reservation_cellphone);
                mSeatsView = (TextView) view.findViewById(R.id.reservation_seats);
                mOrderView = (ImageView) view.findViewById(R.id.reservation_has_order);
            }

            @Override
            public String toString() {
                return super.toString() + " Name: " + mNameView.getText() + " Cellphone: " + mCellphoneView.getText() + " N° of seats: " + mSeatsView.getText();
            }
        }
    }
}
