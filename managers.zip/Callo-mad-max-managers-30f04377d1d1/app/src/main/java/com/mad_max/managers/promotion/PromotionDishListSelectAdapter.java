package com.mad_max.managers.promotion;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.mad_max.managers.R;
import com.mad_max.managers.model.Dish;

import java.util.HashMap;
import java.util.List;


public class PromotionDishListSelectAdapter extends BaseAdapter {
    private List<Dish> mDish;
    private static HashMap<Integer,Boolean> isSelected;
    private Context context;
    private LayoutInflater inflater = null;
    class ViewHolder {
        TextView dishName,dishPrice;
        CheckBox dishCheck;
    }

    public PromotionDishListSelectAdapter(List<Dish> list, Context context) {
        this.context = context;
        this.mDish = list;
        inflater = LayoutInflater.from(context);
        isSelected = new HashMap<Integer, Boolean>();
        initDate();
    }

    private void initDate(){
        for(int i=0; i<mDish.size();i++) {
            getIsSelected().put(i,false);
        }
    }

    @Override
    public int getCount() {
        return mDish.size();
    }

    @Override
    public Object getItem(int position) {
        return mDish.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        Dish d=mDish.get(position);
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.promotion_select_dish_item, null);
            holder.dishName = (TextView) convertView.findViewById(R.id.item_dishname);
            holder.dishPrice=(TextView)convertView.findViewById(R.id.item_dishprice);
            holder.dishCheck = (CheckBox) convertView.findViewById(R.id.item_dishCheck);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }


        holder.dishName.setText(d.getName());
        holder.dishPrice.setText(String.format("%.1f Euro",d.getPrice()));
        holder.dishCheck.setChecked(getIsSelected().get(position));
        return convertView;
    }

    public static HashMap<Integer,Boolean> getIsSelected() {
        return isSelected;
    }

    public static void setIsSelected(HashMap<Integer,Boolean> isSelected) {
        PromotionDishListSelectAdapter.isSelected = isSelected;
    }

}