package com.mad_max.managers.takeaway;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.RequestStatusListener;
import com.mad_max.managers.communication.SCM;
import com.mad_max.managers.miscellaneous.MadMaxApplication;
import com.mad_max.managers.miscellaneous.SimpleDividerItemDecoration;
import com.mad_max.managers.model.Restaurant;
import com.mad_max.managers.model.TakeAway;
import com.mad_max.managers.navigation.AbstractNavigatorActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class TakeAwayListActivity extends AbstractNavigatorActivity implements RequestStatusListener {
    private final static int GET_TAKEAWAYS = 200;

    private Restaurant mRestaurant;
    private List<TakeAway> mTakeAwayList;

    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_takeaway);

        mRestaurant = ((MadMaxApplication) getApplication()).getRestaurant();

        mTakeAwayList = new ArrayList<>();

        Toolbar toolbar = (Toolbar) findViewById(R.id.takeaway_list_toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setTitle(getString(R.string.title_takeaway));

        setUpUI(toolbar);

        mRecyclerView = (RecyclerView) findViewById(R.id.takeaway_list);
        assert mRecyclerView != null;
        setupRecyclerView();

        SCM.getTakeAwayList(mRestaurant.getId(), TakeAwayListActivity.this, GET_TAKEAWAYS);
    }

    private void setupRecyclerView() {
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(new TakeAwayListRecyclerViewAdapter(mTakeAwayList));
        mRecyclerView.addItemDecoration(new SimpleDividerItemDecoration(this));
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case GET_TAKEAWAYS:
                mTakeAwayList = (List<TakeAway>) response;

                if(mTakeAwayList.size() == 0) {
                    Snackbar.make(findViewById(R.id.app_bar), "No takeaway has been added for this restaurant",
                            Snackbar.LENGTH_LONG).show();
                } else {
                    mRecyclerView.swapAdapter(new TakeAwayListRecyclerViewAdapter(mTakeAwayList), false);
                }
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }

    public class TakeAwayListRecyclerViewAdapter extends RecyclerView.Adapter<TakeAwayListRecyclerViewAdapter.ViewHolder> {

        private final List<TakeAway> mValues;
        private final SimpleDateFormat mDateFormat = new SimpleDateFormat("HH:mm");

        public TakeAwayListRecyclerViewAdapter(List<TakeAway> items) {
            mValues = items;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.takeaway_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, int position) {
            final TakeAway t = mValues.get(position);
            holder.mNameView.setText(t.getName() + " " + t.getSurname());
            holder.mCellphoneView.setText(t.getCellphone());
            holder.mTimeView.setText(mDateFormat.format(t.getDate()));

            holder.mView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Context context = v.getContext();
                    Intent intent = new Intent(context, TakeAwayDetailActivity.class);
                    intent.putExtra(TakeAwayDetailActivity.ARG_TAKEAWAY, t);

                    context.startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public final View mView;
            public final TextView mNameView;
            public final TextView mCellphoneView;
            public final TextView mTimeView;

            public ViewHolder(View view) {
                super(view);
                mView = view;
                mNameView = (TextView) view.findViewById(R.id.takeaway_list_name);
                mCellphoneView = (TextView) view.findViewById(R.id.takeaway_list_cellphone);
                mTimeView = (TextView) view.findViewById(R.id.takeaway_list_time);
            }

            @Override
            public String toString() {
                return super.toString() + " Name: " + mNameView.getText() + " Cellphone: " + mCellphoneView.getText() + " Time: " + mTimeView.getText();
            }
        }
    }
}
