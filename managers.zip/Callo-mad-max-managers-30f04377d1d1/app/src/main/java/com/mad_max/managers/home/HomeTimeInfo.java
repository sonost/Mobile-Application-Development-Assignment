package com.mad_max.managers.home;

import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TimePicker;

import com.mad_max.managers.R;

import java.util.Calendar;


public class HomeTimeInfo extends AppCompatActivity implements View.OnClickListener {

    private final static String MON_START_KEY = "MonOpen";
    private final static String MON_END_KEY = "MonClose";
    private final static String TUE_START_KEY = "TueOpen";
    private final static String TUE_END_KEY = "TueClose";
    private final static String WED_START_KEY = "WedOpen";
    private final static String WED_END_KEY = "WedClose";
    private final static String THU_START_KEY = "ThuOpen";
    private final static String THU_END_KEY = "ThuClose";
    private final static String FRI_START_KEY = "FriOpen";
    private final static String FRI_END_KEY = "FriClose";
    private final static String SAT_START_KEY = "SatOpen";
    private final static String SAT_END_KEY = "SatClose";
    private final static String SUN_START_KEY = "SunOpen";
    private final static String SUN_END_KEY = "SunClose";
    private final static String SAVED_KEY = "saved";
    public int dayOfweek = 0;
    public boolean isChecked11 = false;
    Calendar calendar = Calendar.getInstance();
    private Button setSt, setEnd, setSt2, setEnd2, setSt3, setEnd3, setSt4, setEnd4;
    private Button setSt5, setEnd5, setSt6, setEnd6, setSt7, setEnd7;
    TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            switch (dayOfweek) {
                case 11:
                    //dis.setText(hourOfDay+":"+minute);
                    setSt.setText(hourOfDay + ":" + minute);
                    break;
                case 12:
                    //disEnd.setText(hourOfDay + ":" + minute);
                    setEnd.setText(hourOfDay + ":" + minute);
                    break;
                case 21:
                    //dis2.setText(hourOfDay + ":" + minute);
                    setSt2.setText(hourOfDay + ":" + minute);
                    break;
                case 22:
                    //disEnd2.setText(hourOfDay + ":" + minute);
                    setEnd2.setText(hourOfDay + ":" + minute);
                    break;
                case 31:
                    //dis2.setText(hourOfDay + ":" + minute);
                    setSt3.setText(hourOfDay + ":" + minute);
                    break;
                case 32:
                    //disEnd2.setText(hourOfDay + ":" + minute);
                    setEnd3.setText(hourOfDay + ":" + minute);
                    break;
                case 41:
                    //dis2.setText(hourOfDay + ":" + minute);
                    setSt4.setText(hourOfDay + ":" + minute);
                    break;
                case 42:
                    //disEnd2.setText(hourOfDay + ":" + minute);
                    setEnd4.setText(hourOfDay + ":" + minute);
                    break;
                case 51:
                    //dis2.setText(hourOfDay + ":" + minute);
                    setSt5.setText(hourOfDay + ":" + minute);
                    break;
                case 52:
                    //disEnd2.setText(hourOfDay + ":" + minute);
                    setEnd5.setText(hourOfDay + ":" + minute);
                    break;
                case 61:
                    //dis2.setText(hourOfDay + ":" + minute);
                    setSt6.setText(hourOfDay + ":" + minute);
                    break;
                case 62:
                    //disEnd2.setText(hourOfDay + ":" + minute);
                    setEnd6.setText(hourOfDay + ":" + minute);
                    break;
                case 71:
                    //dis2.setText(hourOfDay + ":" + minute);
                    setSt7.setText(hourOfDay + ":" + minute);
                    break;
                case 72:
                    //disEnd2.setText(hourOfDay + ":" + minute);
                    setEnd7.setText(hourOfDay + ":" + minute);
                    break;
            }
        }
    };

    private SharedPreferences mTimePref;
    private SharedPreferences.Editor mTimeEditor;
    private String MonSt, MonEnd, TueSt, TueEnd, WedSt, WedEnd, ThuSt, ThuEnd, FriSt, FriEnd, SatSt, SatEnd, SunSt, SunEnd;
    private boolean isSaved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_time_info_activity);


        mTimePref = getSharedPreferences("mTimePref", MODE_PRIVATE);
        mTimeEditor = mTimePref.edit();


        setSt = (Button) findViewById(R.id.open_time_monday);
        assert setSt != null;
        setSt.setOnClickListener(this);

        setEnd = (Button) findViewById(R.id.close_time_monday);
        assert setEnd != null;
        setEnd.setOnClickListener(this);

        setSt2 = (Button) findViewById(R.id.open_time_tuesday);
        assert setSt2 != null;
        setSt2.setOnClickListener(this);

        setEnd2 = (Button) findViewById(R.id.close_time_tuesday);
        assert setEnd2 != null;
        setEnd2.setOnClickListener(this);

        setSt3 = (Button) findViewById(R.id.open_time_wednesday);
        assert setSt3 != null;
        setSt3.setOnClickListener(this);

        setEnd3 = (Button) findViewById(R.id.close_time_wednesday);
        assert setEnd3 != null;
        setEnd3.setOnClickListener(this);

        setSt4 = (Button) findViewById(R.id.open_time_thursday);
        assert setSt4 != null;
        setSt4.setOnClickListener(this);

        setEnd4 = (Button) findViewById(R.id.close_time_thursday);
        assert setEnd4 != null;
        setEnd4.setOnClickListener(this);

        setSt5 = (Button) findViewById(R.id.open_time_friday);
        assert setSt5 != null;
        setSt5.setOnClickListener(this);

        setEnd5 = (Button) findViewById(R.id.close_time_friday);
        assert setEnd5 != null;
        setEnd5.setOnClickListener(this);

        setSt6 = (Button) findViewById(R.id.open_time_saturnday);
        assert setSt6 != null;
        setSt6.setOnClickListener(this);

        setEnd6 = (Button) findViewById(R.id.close_time_saturnday);
        assert setEnd6 != null;
        setEnd6.setOnClickListener(this);

        setSt7 = (Button) findViewById(R.id.open_time_sunday);
        assert setSt7 != null;
        setSt7.setOnClickListener(this);

        setEnd7 = (Button) findViewById(R.id.close_time_sunday);
        assert setEnd7 != null;
        setEnd7.setOnClickListener(this);

        isSaved = mTimePref.getBoolean(SAVED_KEY, false);

        if (isSaved) {
            fillData();
        }

        FloatingActionButton bDone = (FloatingActionButton) findViewById(R.id.fab);
        assert bDone != null;
        bDone.setOnClickListener(this);
    }

    private void fillData() {

        MonSt = mTimePref.getString(MON_START_KEY, getString(R.string.example_notime));
        MonEnd = mTimePref.getString(MON_END_KEY, getString(R.string.example_notime));
        TueSt = mTimePref.getString(TUE_START_KEY, getString(R.string.example_notime));
        TueEnd = mTimePref.getString(TUE_END_KEY, getString(R.string.example_notime));
        WedSt = mTimePref.getString(WED_START_KEY, getString(R.string.example_notime));
        WedEnd = mTimePref.getString(WED_END_KEY, getString(R.string.example_notime));
        ThuSt = mTimePref.getString(THU_START_KEY, getString(R.string.example_notime));
        ThuEnd = mTimePref.getString(THU_END_KEY, getString(R.string.example_notime));
        FriSt = mTimePref.getString(FRI_START_KEY, getString(R.string.example_notime));
        FriEnd = mTimePref.getString(FRI_END_KEY, getString(R.string.example_notime));
        SatSt = mTimePref.getString(SAT_START_KEY, getString(R.string.example_notime));
        SatEnd = mTimePref.getString(SAT_END_KEY, getString(R.string.example_notime));
        SunSt = mTimePref.getString(SUN_START_KEY, getString(R.string.example_notime));
        SunEnd = mTimePref.getString(SUN_END_KEY, getString(R.string.example_notime));

        setSt.setText(MonSt);
        setEnd.setText(MonEnd);
        setSt2.setText(TueSt);
        setEnd2.setText(TueEnd);
        setSt3.setText(WedSt);
        setEnd3.setText(WedEnd);
        setSt4.setText(ThuSt);
        setEnd4.setText(ThuEnd);
        setSt5.setText(FriSt);
        setEnd5.setText(FriEnd);
        setSt6.setText(SatSt);
        setEnd6.setText(SatEnd);
        setSt7.setText(SunSt);
        setEnd7.setText(SunEnd);
    }

    private void saveData(String MonSt, String MonEnd, String TueSt, String TueEnd, String WedSt, String WedEnd, String ThuSt, String ThuEnd, String FriSt, String FriEnd, String SatSt, String SatEnd, String SunSt, String SunEnd) {

        mTimeEditor.putString(MON_START_KEY, MonSt);
        mTimeEditor.putString(MON_END_KEY, MonEnd);
        mTimeEditor.putString(TUE_START_KEY, TueSt);
        mTimeEditor.putString(TUE_END_KEY, TueEnd);
        mTimeEditor.putString(WED_START_KEY, WedSt);
        mTimeEditor.putString(WED_END_KEY, WedEnd);
        mTimeEditor.putString(THU_START_KEY, ThuSt);
        mTimeEditor.putString(THU_END_KEY, ThuEnd);
        mTimeEditor.putString(FRI_START_KEY, FriSt);
        mTimeEditor.putString(FRI_END_KEY, FriEnd);
        mTimeEditor.putString(SAT_START_KEY, SatSt);
        mTimeEditor.putString(SAT_END_KEY, SatEnd);
        mTimeEditor.putString(SUN_START_KEY, SunSt);
        mTimeEditor.putString(SUN_END_KEY, SunEnd);
        mTimeEditor.putBoolean(SAVED_KEY, isSaved);

        mTimeEditor.commit();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.open_time_monday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 11;
                isChecked11 = true;
                break;

            case R.id.close_time_monday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 12;
                break;

            case R.id.open_time_tuesday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 21;
                break;

            case R.id.close_time_tuesday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 22;
                break;

            case R.id.open_time_wednesday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 31;
                break;

            case R.id.close_time_wednesday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 32;
                break;

            case R.id.open_time_thursday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 41;
                break;

            case R.id.close_time_thursday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 42;
                break;

            case R.id.open_time_friday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 51;
                break;

            case R.id.close_time_friday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 52;
                break;

            case R.id.open_time_saturnday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 61;
                break;

            case R.id.close_time_saturnday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 62;
                break;

            case R.id.open_time_sunday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 71;
                break;

            case R.id.close_time_sunday:
                new TimePickerDialog(HomeTimeInfo.this, onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
                dayOfweek = 72;
                break;

        }

        if (v.getId() == R.id.fab) {
            isSaved = true;
            MonSt = setSt.getText().toString();
            MonEnd = setEnd.getText().toString();
            TueSt = setSt2.getText().toString();
            TueEnd = setEnd2.getText().toString();
            WedSt = setSt3.getText().toString();
            WedEnd = setEnd3.getText().toString();
            ThuSt = setSt4.getText().toString();
            ThuEnd = setEnd4.getText().toString();
            FriSt = setSt5.getText().toString();
            FriEnd = setEnd5.getText().toString();
            SatSt = setSt6.getText().toString();
            SatEnd = setEnd6.getText().toString();
            SunSt = setSt7.getText().toString();
            SunEnd = setEnd7.getText().toString();
            saveData(MonSt, MonEnd, TueSt, TueEnd, WedSt, WedEnd, ThuSt, ThuEnd, FriSt, FriEnd, SatSt, SatEnd, SunSt, SunEnd);
            finish();
        }

    }

}
