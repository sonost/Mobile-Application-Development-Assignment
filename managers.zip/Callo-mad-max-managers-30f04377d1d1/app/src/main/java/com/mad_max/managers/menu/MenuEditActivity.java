package com.mad_max.managers.menu;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.DownloadImageTask;
import com.mad_max.managers.communication.RequestStatusListener;
import com.mad_max.managers.communication.SCM;
import com.mad_max.managers.miscellaneous.MadMaxApplication;
import com.mad_max.managers.model.Dish;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MenuEditActivity extends AppCompatActivity implements View.OnClickListener,RequestStatusListener{
    private final static int EDIT_DISH = 103;

    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private Button done,cancel;
    private EditText ename,eprice,ecategory;
    private ImageView epic;
    private ImageButton imageButton;
    private Dish mDish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_edit_activity);

        done=(Button)findViewById(R.id.buttonDone);
        cancel=(Button)findViewById(R.id.buttonCancel);
        imageButton=(ImageButton)findViewById(R.id.imageButtonedit);

        done.setOnClickListener(this);
        cancel.setOnClickListener(this);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mDish = getIntent().getParcelableExtra("dish");

        new DownloadImageTask((ImageView)findViewById(R.id.editpic)).execute(mDish.getImage());
        ((EditText)findViewById(R.id.editname)).setText(mDish.getName());
        ((EditText)findViewById(R.id.editprice)).setText(String.format("%.1f",mDish.getPrice()));
        ((EditText)findViewById(R.id.editcategory)).setText(mDish.getCategory());
    }




    @Override
    public void onClick(View view){
        if(view.getId()==R.id.buttonDone){
            Intent intent=new Intent(this,MenuActivity.class);
            epic=(ImageView)this.findViewById(R.id.editpic);
            ename=(EditText)this.findViewById(R.id.editname);
            eprice=(EditText)this.findViewById(R.id.editprice);
            ecategory=(EditText)this.findViewById(R.id.editcategory);

            if(TextUtils.isEmpty(ename.getText().toString())){
                ename.setError(getString(R.string.error_field_required));
            }else if(TextUtils.isEmpty(ecategory.getText().toString())){
                ecategory.setError(getString(R.string.error_field_required));
            }else if(TextUtils.isEmpty(eprice.getText().toString())){
                eprice.setError(getString(R.string.error_field_required));
            }else{
                mDish.setName(ename.getText().toString());
                mDish.setQuantity(0);
                mDish.setCategory(ecategory.getText().toString());
                mDish.setPrice(Double.valueOf(eprice.getText().toString()));
                SCM.addDish(mDish, ((MadMaxApplication) getApplication()).getRestaurant().getId(), MenuEditActivity.this, EDIT_DISH);

                setResult(RESULT_OK, intent);
                finish();
            }
        }
        else{
            Intent intent=new Intent(this,MenuActivity.class);
            setResult(RESULT_CANCELED, intent);
            finish();
        }
    }



    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library",
                "Cancel" };

        AlertDialog.Builder builder = new AlertDialog.Builder(MenuEditActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("Take Photo")) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_CAMERA);
                } else if (items[item].equals("Choose from Library")) {
                    Intent intent = new Intent(
                            Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(
                            Intent.createChooser(intent, "Select File"),
                            SELECT_FILE);
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        epic.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String[] projection = { MediaStore.MediaColumns.DATA };
        Cursor cursor = managedQuery(selectedImageUri, projection, null, null,
                null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();

        String selectedImagePath = cursor.getString(column_index);

        Bitmap bm;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(selectedImagePath, options);
        final int REQUIRED_SIZE = 200;
        int scale = 1;
        while (options.outWidth / scale / 2 >= REQUIRED_SIZE
                && options.outHeight / scale / 2 >= REQUIRED_SIZE)
            scale *= 2;
        options.inSampleSize = scale;
        options.inJustDecodeBounds = false;
        bm = BitmapFactory.decodeFile(selectedImagePath, options);

        epic.setImageBitmap(bm);
    }


    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case EDIT_DISH:

                Log.d("home", mDish.toString());
                Toast.makeText(this, "Dish info have been updated", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {
        Toast.makeText(this, "Dish info failed to update", Toast.LENGTH_SHORT).show();
    }
}