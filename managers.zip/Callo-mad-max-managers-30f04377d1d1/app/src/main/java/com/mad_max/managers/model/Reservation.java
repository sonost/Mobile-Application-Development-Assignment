package com.mad_max.managers.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

public class Reservation implements Parcelable {

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Reservation> CREATOR = new Parcelable.Creator<Reservation>() {
        @Override
        public Reservation createFromParcel(Parcel in) {
            return new Reservation(in);
        }

        @Override
        public Reservation[] newArray(int size) {
            return new Reservation[size];
        }
    };
    private String mId;
    private String mRestaurantId;
    private String mRestaurantName;
    private String mName;
    private String mSurname;
    private String mCellphone;
    private String mStartTime;
    private String mEndTime;
    private String mDate;
    private int mSeats;
    private String mComment;
    private List<Dish> mOrder;

    public Reservation() {
    }

    public Reservation(String id, String restaurantId, String restaurantName, String cellphone, String startTime, String endTime, String date, int seats, String comment, List<Dish> order) {
        this(id, restaurantId, restaurantName, "", "", cellphone, startTime, endTime, date, seats, comment, order);
    }

    public Reservation(String id, String restaurantId, String restaurantName, String name, String surname, String cellphone, String startTime, String endTime, String date, int seats, List<Dish> order) {
        this(id, restaurantId, restaurantName, name, surname, cellphone, startTime, endTime, date, seats, "", order);
    }

    public Reservation(String id, String restaurantId, String restaurantName, String name, String surname, String cellphone, String startTime, String endTime, String date, int seats, String comment, List<Dish> order) {
        mId = id;
        mRestaurantId = restaurantId;
        mRestaurantName = restaurantName;
        mName = name;
        mSurname = surname;
        mCellphone = cellphone;
        mStartTime = startTime;
        mEndTime = endTime;
        mDate = date;
        mSeats = seats;
        mComment = comment;
        mOrder = order;
    }

    protected Reservation(Parcel in) {
        mId = in.readString();
        mRestaurantId = in.readString();
        mRestaurantName = in.readString();
        mName = in.readString();
        mSurname = in.readString();
        mCellphone = in.readString();
        mStartTime = in.readString();
        mEndTime = in.readString();

        mDate = in.readString();
        mSeats = in.readInt();
        mComment = in.readString();
        if (in.readByte() == 0x01) {
            mOrder = new ArrayList<>();
            in.readList(mOrder, Dish.class.getClassLoader());
        } else {
            mOrder = null;
        }
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getRestaurantId() {
        return mRestaurantId;
    }

    public void setRestaurantId(String restaurantId) {
        this.mRestaurantId = restaurantId;
    }

    public String getRestaurantName() {
        return mRestaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        mRestaurantName = restaurantName;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getSurname() {
        return mSurname;
    }

    public void setSurname(String surname) {
        mSurname = surname;
    }

    public String getCellphone() {
        return mCellphone;
    }

    public void setCellphone(String cellphone) {
        mCellphone = cellphone;
    }

    public String getStartTime() {
        return mStartTime;
    }

    public void setStartTime(String startTime) {
        mStartTime = startTime;
    }

    public String getEndTime() {
        return mEndTime;
    }

    public void setEndTime(String endTime) {
        mEndTime = endTime;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String date) {
        mDate = date;
    }

    public int getSeats() {
        return mSeats;
    }

    public void setSeats(int seats) {
        mSeats = seats;
    }

    public String getComment() {
        return mComment;
    }

    public void setComment(String comment) {
        mComment = comment;
    }

    public List<Dish> getOrder() {
        return mOrder;
    }

    public void setOrder(List<Dish> order) {
        mOrder = order;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "mId='" + mId + '\'' +
                ",mName='" + mName + '\'' +
                ", mSurname='" + mSurname + '\'' +
                ", mCellphone='" + mCellphone + '\'' +
                ", mSeats=" + mSeats +
                ", mComment='" + mComment + '\'' +
                ", mOrder=" + mOrder +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mId);
        dest.writeString(mRestaurantId);
        dest.writeString(mRestaurantName);
        dest.writeString(mName);
        dest.writeString(mSurname);
        dest.writeString(mCellphone);
        dest.writeString(mStartTime);
        dest.writeString(mEndTime);
        dest.writeString(mDate);
        dest.writeInt(mSeats);
        dest.writeString(mComment);
        if (mOrder == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(mOrder);
        }
    }
}