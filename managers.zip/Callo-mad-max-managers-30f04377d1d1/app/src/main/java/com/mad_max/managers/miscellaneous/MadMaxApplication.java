package com.mad_max.managers.miscellaneous;

import android.content.Context;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;

import com.mad_max.managers.model.Restaurant;

public class MadMaxApplication extends MultiDexApplication {

    private String mManagerId = null;
    private Restaurant mRestaurant = null;

    public String getManagerId() {
        return mManagerId;
    }

    public void setManagerId(String managerId) {
        mManagerId = managerId;
    }

    public Restaurant getRestaurant() {
        return mRestaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        mRestaurant = restaurant;
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }
}
