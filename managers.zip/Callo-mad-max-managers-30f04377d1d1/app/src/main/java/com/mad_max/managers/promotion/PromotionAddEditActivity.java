package com.mad_max.managers.promotion;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.DownloadImageTask;
import com.mad_max.managers.communication.RequestStatusListener;
import com.mad_max.managers.communication.SCM;
import com.mad_max.managers.miscellaneous.MadMaxApplication;
import com.mad_max.managers.model.Dish;
import com.mad_max.managers.model.Promotion;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class PromotionAddEditActivity extends AppCompatActivity implements View.OnClickListener,RequestStatusListener{
    public final static int ARG_EDIT = 1111;
    public final static int ARG_ADD = 2222;
    public final static int DISH_SELECT = 3333;

    private final static int PUT_PROMOTION = 101;
    private EditText mName,mPrice,mTotSeat,mDate,mDescription;
    private ListView mDishss;

    private Button save,cancel,selectD;
    private ImageButton selectP;
    private ListView dishss;
    private ArrayList<Dish> mDish;
    private PromotionDishListShowAdapter mAdapter;
    private Promotion mPromotion;
    private final SimpleDateFormat mTimeFormat = new SimpleDateFormat("HH:mm");
    private ImageView pic;
    private int pos=-1;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.promotion_add_edit_activity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Show the Up button in the action bar.
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);


        save=(Button)findViewById(R.id.buttonSave);
        cancel=(Button)findViewById(R.id.buttonCancel);
        selectP=(ImageButton)findViewById(R.id.selectpicOff);
        selectD=(Button)findViewById(R.id.buttonDish);

        save.setOnClickListener(this);
        cancel.setOnClickListener(this);
        selectP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });
        selectD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), PromotionSelectDishActivity.class);
                intent.putExtra("reqCode", 333);
                startActivityForResult(intent, 333);
                //showDialog(view);
            }
        });

        Intent intent = getIntent();
        if (intent.getIntExtra("reqCode", 0) == ARG_EDIT) {//for EDITING
            mPromotion = intent.getParcelableExtra("promotion");

            new DownloadImageTask(((ImageView) findViewById(R.id.picOff))).execute(mPromotion.getImage());
            ((EditText) findViewById(R.id.nameOff)).setText(mPromotion.getName());
            ((EditText) findViewById(R.id.priceOff)).setText(String.format("%.2f€", mPromotion.getPrice()));
            ((EditText) findViewById(R.id.totOff)).setText(String.format("%d", mPromotion.getTotalSeats()));
            ((EditText) findViewById(R.id.dateOff)).setText(mTimeFormat.format(mPromotion.getDate()));
            ((EditText) findViewById(R.id.desOff)).setText(mPromotion.getDescription());
            ((ListView)findViewById(R.id.selectedDish)).setAdapter(new PromotionDishListShowAdapter(mDish, this));
        }
    }


    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.buttonSave){
            Intent intent = new Intent(this, PromotionActivity.class);

            pic=(ImageView)this.findViewById(R.id.picOff);
            mName=(EditText)this.findViewById(R.id.nameOff);
            mPrice=(EditText)this.findViewById(R.id.priceOff);
            mTotSeat=(EditText)this.findViewById(R.id.totOff);
            mDate=(EditText)this.findViewById(R.id.dateOff);
            mDescription=(EditText)this.findViewById(R.id.desOff);
            mDishss=(ListView)this.findViewById(R.id.selectedDish);

            if(TextUtils.isEmpty(mName.getText())){
                mName.setError(getString(R.string.error_field_required));
            }else if(TextUtils.isEmpty(mPrice.getText())){
                mPrice.setError(getString(R.string.error_field_required));
            }else if(TextUtils.isEmpty(mTotSeat.getText())){
                mTotSeat.setError(getString(R.string.error_field_required));
            }else if(TextUtils.isEmpty(mDate.getText())){
                mDate.setError(getString(R.string.error_field_required));
            }else if(TextUtils.isEmpty(mDescription.getText().toString())){
                mDescription.setError(getString(R.string.error_field_required));
            }else if(mDish==null){
               // dishss.setE(getString(R.string.error_field_required));
            }else {
                pic = (ImageView) findViewById(R.id.picOff);
                mPromotion.setName((mName).getText().toString());
                mPromotion.setPrice(Float.valueOf((mPrice).getText().toString()));
                mPromotion.setOccupiedSeats(0);
                mPromotion.setTotalSeats(Integer.valueOf((mTotSeat.getText().toString())));
                mPromotion.setDescription(mDescription.getText().toString());
                try {
                    mPromotion.setDate(mTimeFormat.parse(((EditText) findViewById(R.id.dateOff)).getText().toString()));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                SCM.addPromotion(mPromotion, ((MadMaxApplication) getApplication()).getRestaurant().getId(), PromotionAddEditActivity.this, PUT_PROMOTION);
                setResult(RESULT_OK, intent);
                finish();
            }
        }else{
            Intent intent=new Intent(this,PromotionActivity.class);
            setResult(RESULT_CANCELED, intent);
            finish();
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            // This ID represents the Home or Up button. In the case of this
            // activity, the Up button is shown. Use NavUtils to allow users
            // to navigate up one level in the application structure. For
            // more details, see the Navigation pattern on Android Design:
            //
            // http://developer.android.com/design/patterns/navigation.html#up-vs-back
            //
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==DISH_SELECT){
            if (resultCode == RESULT_OK) {
                Bundle b= data.getExtras();
                mDish=b.getParcelableArrayList("selectedDishName");
                dishss=(ListView)findViewById(R.id.selectedDish);
                mAdapter=new PromotionDishListShowAdapter(mDish,this);
                dishss.setAdapter(mAdapter);
            }
        }
        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }


    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library",
                "Cancel" };

        AlertDialog.Builder builder = new AlertDialog.Builder(PromotionAddEditActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("Take Photo")) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_CAMERA);
                } else if (items[item].equals("Choose from Library")) {
                    Intent intent = new Intent(
                            Intent.ACTION_PICK,
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(
                            Intent.createChooser(intent, "Select File"),
                            SELECT_FILE);
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }


    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        pic.setImageBitmap(thumbnail);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String[] projection = { MediaStore.MediaColumns.DATA };
        Cursor cursor = managedQuery(selectedImageUri, projection, null, null,
                null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();

        String selectedImagePath = cursor.getString(column_index);

        Bitmap bm;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(selectedImagePath, options);
        final int REQUIRED_SIZE = 200;
        int scale = 1;
        while (options.outWidth / scale / 2 >= REQUIRED_SIZE
                && options.outHeight / scale / 2 >= REQUIRED_SIZE)
            scale *= 2;
        options.inSampleSize = scale;
        options.inJustDecodeBounds = false;
        bm = BitmapFactory.decodeFile(selectedImagePath, options);

        pic.setImageBitmap(bm);
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case PUT_PROMOTION:

                Log.d("home", mPromotion.toString());
                Toast.makeText(this, "Promotion info have been updated", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {
        Toast.makeText(this, "Failed to update promotion", Toast.LENGTH_SHORT).show();

    }
}
