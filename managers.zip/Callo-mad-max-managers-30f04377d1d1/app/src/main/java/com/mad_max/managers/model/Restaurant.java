package com.mad_max.managers.model;

import android.location.Location;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

import com.google.firebase.database.Exclude;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Restaurant implements Parcelable {
    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Restaurant> CREATOR = new Parcelable.Creator<Restaurant>() {
        @Override
        public Restaurant createFromParcel(Parcel in) {
            return new Restaurant(in);
        }

        @Override
        public Restaurant[] newArray(int size) {
            return new Restaurant[size];
        }
    };
    private String mId;
    private String mName;
    private String mPhone;
    private String mAddress;
    private int mCapacity;
    private Location mLocation;
    private String mLogo;
    private float mRating;
    private int mCost;
    private Bundle mSettings;
    private List<TimeSlot> mTimeSlots;
    private List<WorkingHour> mWorkingHours;
    private List<String> mGallery;
    private List<String> mTag;

    public Restaurant() {
        mId = "";
        mName = "";
        mPhone = "";
        mAddress = "";

        mCapacity = 0;
        mLocation = new Location("");
        mLogo = "";
        mGallery = new ArrayList<>();
        mRating = 0.0f;
        mCost = 0;
        mSettings = new Bundle();
        mTimeSlots = new ArrayList<>();
        mWorkingHours = new ArrayList<>();
        mTag = new ArrayList<>();
    }

    public Restaurant(String id, String name, String phone, String address, int capacity,
                      Location location, String logo, List<String> gallery, float rating, int cost,
                      Bundle settings, List<TimeSlot> timeSlots, List<WorkingHour> workingHours,
                      List<String> tag) {
        mId = id;
        mName = name;
        mPhone = phone;
        mAddress = address;

        mCapacity = capacity;
        mLocation = location;
        mLogo = logo;
        mGallery = gallery;
        mRating = rating;
        mCost = cost;
        mSettings = settings;
        mTimeSlots = timeSlots;
        mWorkingHours = workingHours;
        mTag = tag;

    }

    protected Restaurant(Parcel in) {
        mId = in.readString();
        mName = in.readString();
        mPhone = in.readString();
        mAddress = in.readString();
        mCapacity = in.readInt();
        mLocation = (Location) in.readValue(Location.class.getClassLoader());
        mLogo = in.readString();
        if (in.readByte() == 0x01) {
            mGallery = new ArrayList<>();
            in.readList(mGallery, String.class.getClassLoader());
        } else {
            mGallery = null;
        }
        mRating = in.readFloat();
        mCost = in.readInt();
        mSettings = in.readBundle();
        if (in.readByte() == 0x01) {
            mTimeSlots = new ArrayList<>();
            in.readList(mTimeSlots, TimeSlot.class.getClassLoader());
        } else {
            mTimeSlots = null;
        }
        if (in.readByte() == 0x01) {
            mWorkingHours = new ArrayList<>();
            in.readList(mWorkingHours, WorkingHour.class.getClassLoader());
        } else {
            mWorkingHours = null;
        }
        if (in.readByte() == 0x01) {
            mTag = new ArrayList<>();
            in.readList(mTag, String.class.getClassLoader());
        } else {
            mTag = null;
        }
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getPhone() {
        return mPhone;
    }

    public void setPhone(String phone) {
        mPhone = phone;
    }

    public String getAddress() {
        return mAddress;
    }

    public void setAddress(String address) {
        mAddress = address;
    }

    public int getCapacity() {
        return mCapacity;
    }

    public void setCapacity(int capacity) {
        mCapacity = capacity;
    }

    public Location getLocation() {
        return mLocation;
    }

    public void setLocation(Location location) {
        mLocation = location;
    }

    public String getLogo() {
        return mLogo;
    }

    public void setLogo(String logo) {
        mLogo = logo;
    }

    public List<String> getGallery() {
        return mGallery;
    }

    public void setGallery(List<String> gallery) {
        mGallery = gallery;
    }

    public float getRating() {
        return mRating;
    }

    public void setRating(float rating) {
        mRating = rating;
    }

    public int getCost() {
        return mCost;
    }

    public void setCost(int cost) {
        mCost = cost;
    }

    public Bundle getSettings() {
        return mSettings;
    }

    public void setSettings(Bundle settings) {
        mSettings = settings;
    }

    public List<TimeSlot> getTimeSlots() {
        return mTimeSlots;
    }

    public void setTimeSlots(List<TimeSlot> timeSlots) {
        mTimeSlots = timeSlots;
    }

    public List<WorkingHour> getWorkingHours() {
        return mWorkingHours;
    }

    public void setWorkingHours(List<WorkingHour> workingHours) {
        mWorkingHours = workingHours;
    }

    public List<String> getTag() {
        return mTag;
    }

    public void setTag(List<String> tag) {
        mTag = tag;
    }

    @Override
    public String toString() {
        return "Restaurant{" +
                "mId=" + mId +
                ", mName='" + mName + '\'' +
                ", mPhone='" + mPhone + '\'' +
                ", mAddress='" + mAddress + '\'' +
                ", mCapacity=" + mCapacity +
                ", mLocation=" + mLocation +
                ", mLogo='" + mLogo + '\'' +
                ", mGallery=" + mGallery +
                ", mRating=" + mRating +
                ", mCost=" + mCost +
                ", mSettings=" + mSettings +
                ", mTimeSlots=" + mTimeSlots +
                ", mWorkingHours=" + mWorkingHours +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mId);
        dest.writeString(mName);
        dest.writeString(mPhone);
        dest.writeString(mAddress);
        dest.writeInt(mCapacity);
        dest.writeValue(mLocation);
        dest.writeString(mLogo);
        if (mGallery == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(mGallery);
        }
        dest.writeFloat(mRating);
        dest.writeInt(mCost);
        dest.writeBundle(mSettings);
        if (mTimeSlots == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(mTimeSlots);
        }
        if (mWorkingHours == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(mWorkingHours);
        }
        if (mTag == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(mTag);
        }
    }

    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("id", mId);
        result.put("name", mName);
        result.put("phone", mPhone);
        result.put("address", mAddress);
        result.put("capacity", mCapacity);
        result.put("location", mLocation);
        result.put("logo", mLogo);
        result.put("gallery", mGallery);
        result.put("settings", mSettings);
        result.put("timeslot", mTimeSlots);
        result.put("workinghours", mWorkingHours);
        result.put("tag", mTag);

        return result;
    }
}
