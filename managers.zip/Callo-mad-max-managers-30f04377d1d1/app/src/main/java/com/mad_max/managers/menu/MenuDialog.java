package com.mad_max.managers.menu;

import android.app.Activity;
import android.app.DialogFragment;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.SCM;
import com.mad_max.managers.miscellaneous.MadMaxApplication;
import com.mad_max.managers.model.Dish;

public class MenuDialog extends DialogFragment implements View.OnClickListener {

    private static final int IMAGE_PICKER_SELECT = 99;
    private ImageView mImage;
    private ImageButton mButton;
    private Button add, cancel;
    private EditText name, price, category;


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.menu_add_dialog, null);
        add = (Button) view.findViewById(R.id.buttonAdd);
        cancel = (Button) view.findViewById(R.id.buttonCancel);
        mImage = (ImageView) view.findViewById(R.id.addpic);
        mButton = (ImageButton) view.findViewById(R.id.buttonSelect);

        name = (EditText) view.findViewById(R.id.addname);
        price = (EditText) view.findViewById(R.id.addprice);
        category = (EditText) view.findViewById(R.id.addcategory);
        add.setOnClickListener(this);
        cancel.setOnClickListener(this);
        mButton.setOnClickListener(this);
        setCancelable(false);

        return view;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.buttonAdd) {
            if (TextUtils.isEmpty(name.getText().toString())) {
                name.setError(getString(R.string.error_field_required));
            } else if (TextUtils.isEmpty(category.getText().toString())) {
                category.setError(getString(R.string.error_field_required));
            } else if (TextUtils.isEmpty(price.getText().toString())) {
                price.setError(getString(R.string.error_field_required));
            } else {

                String dishName = name.getText().toString().toLowerCase().trim();
                String categoryName = category.getText().toString().toLowerCase().trim();


                Dish dish = new Dish(null, "", dishName.substring(0, 1).toUpperCase() + dishName.substring(1),
                        categoryName.substring(0, 1).toUpperCase() + categoryName.substring(1),
                        Double.valueOf(price.getText().toString()), 0);

                SCM.addDish(dish, ((MadMaxApplication) getActivity().getApplication()).getRestaurant().getId(),
                        (MenuActivity) getActivity(), MenuActivity.ADD_DISH);
                dismiss();
            }
        }
        if (view.getId() == R.id.buttonCancel) {
            dismiss();
        }
        if (view.getId() == R.id.buttonSelect) {
            Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, IMAGE_PICKER_SELECT);

        }
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == IMAGE_PICKER_SELECT && resultCode == Activity.RESULT_OK) {
            MenuActivity activity = (MenuActivity) getActivity();
            Bitmap bitmap = getBitmapFromCameraData(data, activity);
            mImage.setImageBitmap(bitmap);
        }
    }

    private void setFullImageFromFilePath(String imagePath) {
        // Get the dimensions of the View
        int targetW = mImage.getWidth();
        int targetH = mImage.getHeight();

        // Get the dimensions of the bitmap
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imagePath, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        // Determine how much to scale down the image
        int scaleFactor = Math.min(photoW / targetW, photoH / targetH);

        // Decode the image file into a Bitmap sized to fill the View
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;
        bmOptions.inPurgeable = true;

        Bitmap bitmap = BitmapFactory.decodeFile(imagePath, bmOptions);
        mImage.setImageBitmap(bitmap);
    }

    public static Bitmap getBitmapFromCameraData(Intent data, Context context) {
        Uri selectedImage = data.getData();
        String[] filePathColumn = {MediaStore.Images.Media.DATA};
        Cursor cursor = context.getContentResolver().query(selectedImage, filePathColumn, null, null, null);
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
        String picturePath = cursor.getString(columnIndex);
        cursor.close();
        return BitmapFactory.decodeFile(picturePath);
    }
}
