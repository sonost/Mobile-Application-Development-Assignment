package com.mad_max.managers.promotion;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.RequestStatusListener;
import com.mad_max.managers.communication.SCM;
import com.mad_max.managers.miscellaneous.MadMaxApplication;
import com.mad_max.managers.model.Promotion;
import com.mad_max.managers.navigation.AbstractNavigatorActivity;

import java.util.ArrayList;
import java.util.List;

public class PromotionActivity extends AbstractNavigatorActivity implements RequestStatusListener {
    private final static int GET_PROMOTIONS = 200;
    private List<Promotion> mPromotionList;
    private RecyclerView mRecyclerView;
    private PromotionRecyclerAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_promotion);

        mPromotionList = new ArrayList<>();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab2 = (FloatingActionButton) findViewById(R.id.fab2);
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), PromotionAddEditActivity.class);
                intent.putExtra("reqCode", PromotionAddEditActivity.ARG_ADD);
                startActivity(intent);
            }
        });

        mAdapter = new PromotionRecyclerAdapter(mPromotionList);

        mRecyclerView = (RecyclerView) findViewById(R.id.my_recycler_view_offer);
        assert mRecyclerView != null;
        mRecyclerView.setHasFixedSize(true);
        setupRecyclerView();

        SCM.getPromotionList(((MadMaxApplication) getApplication()).getRestaurant().getId(),
                PromotionActivity.this, GET_PROMOTIONS);
    }

    private void setupRecyclerView() {
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(mAdapter);}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case GET_PROMOTIONS:
                mPromotionList = new ArrayList<>((List<Promotion>) response);

                if(mPromotionList.size() == 0) {
                    Snackbar.make(findViewById(R.id.app_bar), "No promotions has been added for this restaurant",
                            Snackbar.LENGTH_LONG).show();
                } else {
                    mAdapter = new PromotionRecyclerAdapter(mPromotionList);
                    mRecyclerView.swapAdapter(mAdapter, false);
                }
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }
}
