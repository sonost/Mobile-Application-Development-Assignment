package com.mad_max.managers.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Promotion implements Parcelable {

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Promotion> CREATOR = new Parcelable.Creator<Promotion>() {
        @Override
        public Promotion createFromParcel(Parcel in) {
            return new Promotion(in);
        }

        @Override
        public Promotion[] newArray(int size) {
            return new Promotion[size];
        }
    };
    private String mId;
    private String mImage;
    private String mName;
    private int mOccupiedSeats;
    private int mTotalSeats;
    private double mPrice;
    private String mDescription;
    private Date mDate;
    private List<Dish> mMenu;

    public Promotion() {
    }

    public Promotion(String id, String image, String name, int occupiedSeats, int totalSeat,
                     double price, String description, Date date, List<Dish> dish) {
        mId = id;
        mImage = image;
        mName = name;
        mOccupiedSeats = occupiedSeats;
        mTotalSeats = totalSeat;
        mPrice = price;
        mDescription = description;
        mDate = date;
        mMenu = dish;
    }

    protected Promotion(Parcel in) {
        mId = in.readString();
        mImage = in.readString();
        mName = in.readString();
        mOccupiedSeats = in.readInt();
        mTotalSeats = in.readInt();
        mPrice = in.readDouble();
        mDescription = in.readString();
        long tmpMInsertionDate = in.readLong();
        mDate = tmpMInsertionDate != -1 ? new Date(tmpMInsertionDate) : null;
        if (in.readByte() == 0x01) {
            mMenu = new ArrayList<>();
            in.readList(mMenu, Dish.class.getClassLoader());
        } else {
            mMenu = null;
        }
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getImage() {
        return mImage;
    }

    public void setImage(String image) {
        mImage = image;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public int getOccupiedSeats() {
        return mOccupiedSeats;
    }

    public void setOccupiedSeats(int occupiedSeats) {
        mOccupiedSeats = occupiedSeats;
    }

    public int getTotalSeats() {
        return mTotalSeats;
    }

    public void setTotalSeats(int totalSeats) {
        mTotalSeats = totalSeats;
    }

    public double getPrice() {
        return mPrice;
    }

    public void setPrice(double price) {
        mPrice = price;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        mDescription = description;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        mDate = date;
    }

    public List<Dish> getMenu() {
        return mMenu;
    }

    public void setMenu(List<Dish> menu) {
        mMenu = menu;
    }

    @Override
    public String toString() {
        return "Promotion{" +
                "mId=" + mId +
                ", mImage=" + mImage +
                ", mName='" + mName + '\'' +
                ", mAvailableSeats=" + mOccupiedSeats +
                ", mTotalSeats=" + mTotalSeats +
                ", mPrice=" + mPrice +
                ", mDescription='" + mDescription + '\'' +
                ", mDate='" + mDate + '\'' +
                ", mMenu=" + mMenu +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mId);
        dest.writeString(mImage);
        dest.writeString(mName);
        dest.writeInt(mOccupiedSeats);
        dest.writeInt(mTotalSeats);
        dest.writeDouble(mPrice);
        dest.writeString(mDescription);
        dest.writeLong(mDate != null ? mDate.getTime() : -1L);
        if (mMenu == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(mMenu);
        }
    }
}
