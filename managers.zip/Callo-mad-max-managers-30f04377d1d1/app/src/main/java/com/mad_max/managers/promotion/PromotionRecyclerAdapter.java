package com.mad_max.managers.promotion;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.DownloadImageTask;
import com.mad_max.managers.model.Promotion;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class PromotionRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int NORMAL_ITEM = 0;
    private static final int GROUP_ITEM = 1;
    private List<Promotion> mData;
    private final SimpleDateFormat mTimeFormat = new SimpleDateFormat("HH:mm");


    public PromotionRecyclerAdapter(List<Promotion> mData){
        this.mData=mData;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == NORMAL_ITEM) {
            return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.promotion_list_item, parent, false));
        } else {
            return new MyViewHolderGroup(LayoutInflater.from(parent.getContext()).inflate(R.layout.promotion_list_item_withtitle, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final Promotion p = mData.get(position);
        final MyViewHolder holder1;
        final MyViewHolderGroup holder2;

        if (holder instanceof MyViewHolderGroup) {
            holder2 = (MyViewHolderGroup) holder;
            holder2.name.setText(p.getName());
            holder2.price.setText(String.format("%.1f €", p.getPrice()));
            holder2.seat.setText(String.format("%d / %d ", p.getOccupiedSeats(), p.getTotalSeats()));
            new DownloadImageTask(holder2.pic).execute(p.getImage());
            /////group part
            ((MyViewHolderGroup) holder).promodate.setText(mTimeFormat.format(p.getDate()));

            holder2.itemView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    Context cnx = v.getContext();
                    Intent intent = new Intent(cnx, PromotionAddEditActivity.class);
                    intent.putExtra("reqCode",PromotionAddEditActivity.ARG_EDIT);
                    intent.putExtra("promotion", p);
                    ((Activity) cnx).startActivityForResult(intent, 222);
                }
            });

        } else {
            holder1 = (MyViewHolder) holder;
            holder1.name.setText(p.getName());
            holder1.price.setText(String.format("%.1f €", p.getPrice()));
            holder1.seat.setText(String.format( "%d / %d ", p.getOccupiedSeats(),p.getTotalSeats()));

            holder1.itemView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    Context cnx = v.getContext();
                    Intent intent = new Intent(cnx, PromotionAddEditActivity.class);
                    intent.putExtra("reqCode", PromotionAddEditActivity.ARG_EDIT);
                    intent.putExtra("promotion", p);
                    ((Activity) cnx).startActivityForResult(intent, 222);
                }
            });
        }

    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0)
            return GROUP_ITEM;

        Date currentDate = mData.get(position).getDate();
        int prevIndex = position - 1;
        boolean isDifferent = !mData.get(prevIndex).getDate().equals(currentDate);
        return isDifferent ? GROUP_ITEM : NORMAL_ITEM;
    }

    @Override
    public int getItemCount(){
        return mData.size();
    }




    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView name,price,seat/*,description*/ ;
        public TextView dishs;
        public ImageView pic;

        public MyViewHolder(View itemView){
            super(itemView);
            name=(TextView) itemView.findViewById(R.id.nameOff);
            price=(TextView) itemView.findViewById(R.id.priceOff);
            seat=(TextView)itemView.findViewById(R.id.seatsOff);
          //  description=(TextView)itemView.findViewById(R.id.desOff);
            dishs=(TextView)itemView.findViewById(R.id.dishOff);
            pic=(ImageView)itemView.findViewById(R.id.picOff);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

        }
    }

    public static class MyViewHolderGroup extends MyViewHolder implements View.OnClickListener{
        public TextView promodate;

        public MyViewHolderGroup(View itemView){
            super(itemView);
            promodate=(TextView) itemView.findViewById(R.id.promo_date);
        }

        @Override
        public void onClick(View v) {

        }
    }


}