package com.mad_max.managers.reservation;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.RequestStatusListener;
import com.mad_max.managers.communication.SCM;
import com.mad_max.managers.miscellaneous.MadMaxApplication;
import com.mad_max.managers.miscellaneous.SimpleDividerItemDecoration;
import com.mad_max.managers.model.Restaurant;
import com.mad_max.managers.model.TimeSlot;
import com.mad_max.managers.navigation.AbstractNavigatorActivity;

import java.util.List;

/**
 * An activity representing a list of TimeSlots. This activity
 * has different presentations for handset and tablet-size devices. On
 * handsets, the activity presents a list of items, which when touched,
 * lead to a {@link ReservationListActivity} representing
 * item details. On tablets, the activity presents the list of items and
 * item details side-by-side using two vertical panes.
 */
public class ReservationTimeSlotActivity extends AbstractNavigatorActivity implements View.OnClickListener, RequestStatusListener {
    private final static int UPDATE_TIMESLOT = 200;

    private Restaurant mRestaurant;

    private TimeSlotListRecyclerViewAdapter mAdapter;

    private FloatingActionButton mBlockOrResetAllReservation;
    private boolean mReservationsLocked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_reservation);

        mReservationsLocked = true;

        mRestaurant = ((MadMaxApplication) getApplication()).getRestaurant();

        mAdapter = new TimeSlotListRecyclerViewAdapter(mRestaurant.getTimeSlots());

        Toolbar toolbar = (Toolbar) findViewById(R.id.reservation_timeslot_toolbar);
        assert toolbar != null;
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setTitle(getString(R.string.title_reservation));

        setUpUI(toolbar);

        mBlockOrResetAllReservation = (FloatingActionButton) findViewById(R.id.block_all_reservation);
        assert mBlockOrResetAllReservation != null;
        mBlockOrResetAllReservation.setOnClickListener(this);
        mBlockOrResetAllReservation.setVisibility(View.GONE);

        for (TimeSlot ts : mRestaurant.getTimeSlots()) {
            if (ts.getAvailableSeats() > ts.getOccupiedSeats()) {
                mBlockOrResetAllReservation.setImageDrawable(
                        ContextCompat.getDrawable(this, android.R.drawable.ic_lock_idle_lock));
                mReservationsLocked = false;
                break;
            }
        }

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.timeslot_list);
        assert recyclerView != null;
        setupRecyclerView(recyclerView);

        if(mRestaurant.getTimeSlots().size() == 0) {
            Snackbar.make(findViewById(R.id.app_bar), "No timeslot has been defined for this restaurant",
                    Snackbar.LENGTH_LONG).show();
        }
    }

    private void setupRecyclerView(RecyclerView recyclerView) {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(mAdapter);
        recyclerView.addItemDecoration(new SimpleDividerItemDecoration(this));
    }

    @Override
    public void onClick(View v) {
        if (v.equals(mBlockOrResetAllReservation)) {
            // Reset all availability to the default value
            if (mReservationsLocked) {
                int defaultAvailability = getSharedPreferences("settings", MODE_PRIVATE).getInt("defaultAvailability", 20);

                for (TimeSlot ts : mRestaurant.getTimeSlots()) {
                    // If default availability is less or equal to available seats
                    // (which in this case are equal to occupied seats), it's useless to update it;
                    // we risk to set the available seats less than the already occupied ones
                    if (defaultAvailability > ts.getAvailableSeats()) {
                        ts.setAvailableSeats(defaultAvailability);

                        if (ts.getAvailableSeats() > ts.getOccupiedSeats()) {
                            mReservationsLocked = false;
                        }
                    }
                }

                //if it's false, at last one time slot has some available seats
                if (!mReservationsLocked) {
                    mBlockOrResetAllReservation.setImageDrawable(ContextCompat.getDrawable(this, android.R.drawable.ic_lock_idle_lock));
                }
            }
            // Block all reservations
            else {
                for (TimeSlot ts : mRestaurant.getTimeSlots()) {
                    ts.setAvailableSeats(ts.getOccupiedSeats());
                }

                mReservationsLocked = true;
                mBlockOrResetAllReservation.setImageDrawable(ContextCompat.getDrawable(this, android.R.drawable.ic_menu_rotate));
            }

            mAdapter.notifyItemRangeChanged(0, mAdapter.getItemCount());

            SCM.updateTimeSlot(mRestaurant.getTimeSlots(), mRestaurant.getId(),
                    ReservationTimeSlotActivity.this, UPDATE_TIMESLOT);
        }
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {

    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }

    public class TimeSlotListRecyclerViewAdapter extends RecyclerView.Adapter<TimeSlotListRecyclerViewAdapter.ViewHolder> {

        private final List<TimeSlot> mValues;

        public TimeSlotListRecyclerViewAdapter(List<TimeSlot> items) {
            mValues = items;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.reservation_timeslot_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final TimeSlot t = mValues.get(position);
            holder.mTimeSlotView.setText(String.format("%s - %s", t.getStartTime(), t.getEndTime()));
            holder.mSeatsView.setText(String.format("%s / %s", t.getOccupiedSeats(), t.getAvailableSeats()));

            holder.mView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Context context = v.getContext();
                    Intent intent = new Intent(context, ReservationListActivity.class);
                    intent.putExtra(ReservationListActivity.ARG_TIMESLOT, t);
                    intent.putExtra(ReservationListActivity.ARG_RESTAURANT, mRestaurant);

                    context.startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return mValues.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public final View mView;
            public final TextView mTimeSlotView;
            public final TextView mSeatsView;
            public TimeSlot mItem;

            public ViewHolder(View view) {
                super(view);
                mView = view;
                mTimeSlotView = (TextView) view.findViewById(R.id.timeslot_time);
                mSeatsView = (TextView) view.findViewById(R.id.available_seats);
            }

            @Override
            public String toString() {
                return super.toString() + " Timeslot: " + mTimeSlotView.getText() + " Available seats: " + mSeatsView.getText();
            }
        }
    }
}
