package com.mad_max.managers.model;

import android.os.Parcel;
import android.os.Parcelable;

public class WorkingHour implements Parcelable {
    @SuppressWarnings("unused")
    public static final Parcelable.Creator<WorkingHour> CREATOR = new Parcelable.Creator<WorkingHour>() {
        @Override
        public WorkingHour createFromParcel(Parcel in) {
            return new WorkingHour(in);
        }

        @Override
        public WorkingHour[] newArray(int size) {
            return new WorkingHour[size];
        }
    };
    private String mDay;
    private String mOpeningHour;
    private String mCloseHour;

    private WorkingHour() {
    }

    public WorkingHour(String day, String openingHour, String closeHour) {
        mDay = day;
        mOpeningHour = openingHour;
        mCloseHour = closeHour;
    }

    protected WorkingHour(Parcel in) {
        mDay = in.readString();
        mOpeningHour = in.readString();
        mCloseHour = in.readString();
    }

    public String getDay() {
        return mDay;
    }

    public void setDay(String day) {
        mDay = day;
    }

    public String getOpeningHour() {
        return mOpeningHour;
    }

    public void setOpeningHour(String openingHour) {
        mOpeningHour = openingHour;
    }

    public String getCloseHour() {
        return mCloseHour;
    }

    public void setCloseHour(String closeHour) {
        mCloseHour = closeHour;
    }

    @Override
    public String toString() {
        return "WorkingHour{" +
                "mDay='" + mDay + '\'' +
                ", mOpeningHour='" + mOpeningHour + '\'' +
                ", mCloseHour='" + mCloseHour + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mDay);
        dest.writeString(mOpeningHour);
        dest.writeString(mCloseHour);
    }
}