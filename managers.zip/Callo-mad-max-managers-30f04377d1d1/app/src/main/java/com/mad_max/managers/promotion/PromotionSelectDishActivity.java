package com.mad_max.managers.promotion;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.RequestStatusListener;
import com.mad_max.managers.communication.SCM;
import com.mad_max.managers.miscellaneous.MadMaxApplication;
import com.mad_max.managers.model.Dish;

import java.util.ArrayList;
import java.util.List;

public class PromotionSelectDishActivity extends AppCompatActivity implements View.OnClickListener, RequestStatusListener {
    private final static int GET_DISHES = 200;

    private ListView mListView;
    private PromotionDishListSelectAdapter mAdapter;
    private List<Dish> mDish;
    private ArrayList<Dish> mselectedDish=new ArrayList<>();
    private int checkNum=0;
    private TextView checkShow;
    private Button done;
    private Button cancel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.promotion_select_dish_activity);

        Toolbar toolbar = (Toolbar) findViewById(R.id.dish_selector_toolbar);
        setSupportActionBar(toolbar);

        // Show the Up button in the action bar.
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle(R.string.title_activity_promotion_select_dish);

        mDish = new ArrayList<>();

        mListView=(ListView)findViewById(R.id.my_list_view_dish);
        mAdapter=new PromotionDishListSelectAdapter(mDish,this);
        mListView.setAdapter(mAdapter);
        mListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        checkShow=(TextView)findViewById(R.id.item_CheckNum);
        done=(Button)findViewById(R.id.selectDone);
        cancel=(Button)findViewById(R.id.selectCancel);
        done.setOnClickListener(this);
        cancel.setOnClickListener(this);


        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PromotionDishListSelectAdapter.ViewHolder holder = (PromotionDishListSelectAdapter.ViewHolder) view.getTag();
                holder.dishCheck.toggle();
                PromotionDishListSelectAdapter.getIsSelected().put(position, holder.dishCheck.isChecked());

                if (holder.dishCheck.isChecked()) {
                    checkNum++;
                    mselectedDish.add(mDish.get(position));
                } else {
                    checkNum--;
                    mselectedDish.remove(mDish.get(position));
                }
                checkShow.setText("Selected " + checkNum + " items!");
            }
        });


        Intent intent=getIntent();
        Bundle b=intent.getExtras();
        if(b.getInt("reqCode")==333){
        }

        SCM.getDishList(((MadMaxApplication) getApplication()).getRestaurant().getId(),
                PromotionSelectDishActivity.this, GET_DISHES);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.selectCancel){
            Intent intent=new Intent(this, PromotionAddEditActivity.class);
            setResult(RESULT_CANCELED, intent);
            finish();
        }
        if(v.getId()==R.id.selectDone){
            Intent intent=new Intent(this, PromotionAddEditActivity.class);
            Bundle bundle=new Bundle();
            bundle.putParcelableArrayList("selectedDishName", mselectedDish);
            intent.putExtras(bundle);
            setResult(RESULT_OK, intent);
            finish();
        }
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case GET_DISHES:
                mDish = (List<Dish>) response;

                if(mDish.size() == 0) {
                    Snackbar.make(findViewById(R.id.app_bar), "No dishes has been added for this restaurant",
                            Snackbar.LENGTH_LONG).show();
                } else {
                    mAdapter = new PromotionDishListSelectAdapter(mDish, this);
                    mListView.setAdapter(mAdapter);
                }
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }
}
