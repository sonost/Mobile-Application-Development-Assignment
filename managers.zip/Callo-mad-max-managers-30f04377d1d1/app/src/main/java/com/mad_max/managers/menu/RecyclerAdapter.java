package com.mad_max.managers.menu;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.DownloadImageTask;
import com.mad_max.managers.model.Dish;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int NORMAL_ITEM = 0;
    private static final int GROUP_ITEM = 1;
    private List<Dish> mData;

    public RecyclerAdapter(List<Dish> mData) {
        this.mData = mData;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == NORMAL_ITEM) {
            return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.menu_list_item, parent, false));
        } else {
            return new MyViewHolderGroup(LayoutInflater.from(parent.getContext()).inflate(R.layout.menu_list_item_withtitle, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final Dish m = mData.get(position);
        final MyViewHolder holder1;
        final MyViewHolderGroup holder2;

        if (holder instanceof MyViewHolderGroup) {
            holder2 = (MyViewHolderGroup) holder;
            holder2.name.setText(m.getName());
            new DownloadImageTask(holder2.image).execute(m.getImage());
            holder2.price.setText(Double.toString(m.getPrice()));
            holder2.available.setChecked((m.getQuantity() < 0) ? false : true);
            holder2.menucategory.setText(m.getCategory());
            holder2.itemView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    Context cnx = v.getContext();
                    Intent intent = new Intent(cnx, MenuEditActivity.class);
                    intent.putExtra("dish", m);
                    ((Activity) cnx).startActivityForResult(intent, 999);
                }
            });
        } else {
            holder1 = (MyViewHolder) holder;
            holder1.name.setText(m.getName());
            new DownloadImageTask(holder1.image).execute(m.getImage());
            holder1.price.setText(Double.toString(m.getPrice()));
            holder1.available.setChecked((m.getQuantity() < 0) ? false : true);
            holder.itemView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    Context cnx = v.getContext();
                    Intent intent = new Intent(cnx, MenuEditActivity.class);
                    intent.putExtra("dish", m);
                    ((Activity) cnx).startActivityForResult(intent, 999);
                }
            });

        }


    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0)
            return GROUP_ITEM;

        String currentCate = mData.get(position).getCategory();
        int prevIndex = position - 1;
        boolean isDifferent = !mData.get(prevIndex).getCategory().equals(currentCate);
        return isDifferent ? GROUP_ITEM : NORMAL_ITEM;
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView name, category;
        public ImageView image;
        public TextView price;
        public Switch available;

        public MyViewHolder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.dishname);
            image = (ImageView) itemView.findViewById(R.id.dishpic);
            price = (TextView) itemView.findViewById(R.id.dishprice);
            available = (Switch) itemView.findViewById(R.id.switch1);
            itemView.setOnClickListener(this);

            available.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    //TODO deactive
                }
            });
        }

        @Override
        public void onClick(View v) {
        }
    }

    public static class MyViewHolderGroup extends MyViewHolder implements View.OnClickListener {
        public TextView menucategory;

        public MyViewHolderGroup(View itemView) {
            super(itemView);
            menucategory = (TextView) itemView.findViewById(R.id.menu_category);
        }

        @Override
        public void onClick(View v) {

        }
    }


}

