package com.mad_max.managers.menu;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.RequestStatusListener;
import com.mad_max.managers.communication.SCM;
import com.mad_max.managers.miscellaneous.MadMaxApplication;
import com.mad_max.managers.model.Dish;
import com.mad_max.managers.model.Restaurant;
import com.mad_max.managers.navigation.AbstractNavigatorActivity;

import java.util.ArrayList;
import java.util.List;


public class MenuActivity extends AbstractNavigatorActivity implements RequestStatusListener {

    protected final static int GET_DISHS = 301;
    protected final static int ADD_DISH = 102;
    private final static int DELETE_DISH = 302;

    private ArrayList<Dish> myDataset;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    private Restaurant mRestaurant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_menu);

        myDataset = new ArrayList<>();

        mRestaurant = ((MadMaxApplication) getApplication()).getRestaurant();
        //RECYCLERVIEW
        mRecyclerView=(RecyclerView)findViewById(R.id.my_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new RecyclerAdapter(myDataset);
        mRecyclerView.setAdapter(mAdapter);
        //SWIPE TO DISMISS
        ItemTouchHelper swipeToDismissTouchHelper =new ItemTouchHelper( new ItemTouchHelper.SimpleCallback(ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT,ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT ){
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }
            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                SCM.deleteDish((myDataset.get(viewHolder.getAdapterPosition())), mRestaurant.getId(), MenuActivity.this, DELETE_DISH);
                mAdapter.notifyItemRemoved(viewHolder.getAdapterPosition());
                myDataset.remove(viewHolder.getAdapterPosition());
            }
        }) ;
        swipeToDismissTouchHelper.attachToRecyclerView(mRecyclerView);


        FloatingActionButton fab1 = (FloatingActionButton) findViewById(R.id.fab1);
        assert fab1 != null;
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(view);
            }
        });

        Toolbar toolbar = (Toolbar) findViewById(R.id.menu_toolbar);
        assert toolbar != null;
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setTitle(getString(R.string.title_activity_menu));

        setUpUI(toolbar);

        SCM.getDishList(mRestaurant.getId(), MenuActivity.this, GET_DISHS);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK && requestCode==999){
            mAdapter.notifyDataSetChanged();
        }
        if(resultCode==RESULT_CANCELED && requestCode==999){
            mAdapter.notifyDataSetChanged();
        }
    }


    public void showDialog(View v){
        android.app.FragmentManager manager=getFragmentManager();
        MenuDialog myDialog=new MenuDialog();
        myDialog.show(manager,"MenuDialog");
    }



    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case GET_DISHS:
                myDataset = new ArrayList<>((List<Dish>) response);

                if(myDataset.size() == 0) {
                    Snackbar.make(findViewById(R.id.app_bar), "No dishes has been added for this restaurant",
                            Snackbar.LENGTH_LONG).show();
                } else {
                    mAdapter = new RecyclerAdapter(myDataset);
                    mRecyclerView.swapAdapter(mAdapter, false);
                }
                break;
            case ADD_DISH:
                SCM.getDishList(mRestaurant.getId(), MenuActivity.this, MenuActivity.GET_DISHS);
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {

    }
}



