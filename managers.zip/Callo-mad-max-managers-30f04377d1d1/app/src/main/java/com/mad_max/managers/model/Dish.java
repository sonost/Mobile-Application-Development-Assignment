package com.mad_max.managers.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Dish implements Parcelable {

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Dish> CREATOR = new Parcelable.Creator<Dish>() {
        @Override
        public Dish createFromParcel(Parcel in) {
            return new Dish(in);
        }

        @Override
        public Dish[] newArray(int size) {
            return new Dish[size];
        }
    };
    private String mId;
    private String mImage;
    private String mName;
    private String mCategory;
    private double mPrice;
    private int mQuantity;

    private Dish() {
    }

    public Dish(String id, String name, String category, double price) {
        this(id, "", name, category, price, 0);
    }

    public Dish(String id, String image, String name, String category, double price) {
        this(id, image, name, category, price, 0);
    }

    public Dish(String id, String name, String category, double price, int quantity) {
        this(id, "", name, category, price, quantity);
    }

    public Dish(String id, String image, String name, String category, double price, int quantity) {
        mId = id;
        mName = name;
        mCategory = category;
        mImage = image;
        mPrice = price;
        mQuantity = quantity;
    }

    protected Dish(Parcel in) {
        mId = in.readString();
        mImage = in.readString();
        mName = in.readString();
        mCategory = in.readString();
        mPrice = in.readDouble();
        mQuantity = in.readInt();
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getImage() {
        return mImage;
    }

    public void setImage(String image) {
        mImage = image;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getCategory() {
        return mCategory;
    }

    public void setCategory(String category) {
        mCategory = category;
    }

    public double getPrice() {
        return mPrice;
    }

    public void setPrice(double price) {
        mPrice = price;
    }

    public int getQuantity() {
        return mQuantity;
    }

    public void setQuantity(int quantity) {
        mQuantity = quantity;
    }

    @Override
    public String toString() {
        return "Dish{" +
                "mId=" + mId +
                ", mImage='" + mImage + '\'' +
                ", mName='" + mName + '\'' +
                ",mCategory=" + mCategory + '\'' +
                ", mPrice=" + mPrice +
                ", mQuantity=" + mQuantity +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mId);
        dest.writeString(mImage);
        dest.writeString(mName);
        dest.writeString(mCategory);
        dest.writeDouble(mPrice);
        dest.writeInt(mQuantity);
    }
}