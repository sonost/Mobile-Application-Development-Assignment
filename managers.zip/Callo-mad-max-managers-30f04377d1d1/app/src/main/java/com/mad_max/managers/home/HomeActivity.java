package com.mad_max.managers.home;

import android.Manifest;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mad_max.managers.R;
import com.mad_max.managers.communication.DownloadImageTask;
import com.mad_max.managers.communication.RequestStatusListener;
import com.mad_max.managers.communication.SCM;
import com.mad_max.managers.miscellaneous.MadMaxApplication;
import com.mad_max.managers.model.Restaurant;
import com.mad_max.managers.navigation.AbstractNavigatorActivity;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

public class HomeActivity extends AbstractNavigatorActivity implements View.OnClickListener, RequestStatusListener {

    private final static int CAM_REQUEST = 0;
    private final static int SELECT_FILE = 1;
    private final static int SELECT_LOGO = 2;
    private final static int PUT_RESTAURANT = 101;

    private Restaurant mRestaurant;

    private ImageView mLogoToUpload;
    private Button mSetOpeningTime, mGetLoc;
    private TextView mCoord;
    private FloatingActionButton mChange;
    private TextInputEditText mEditName, mEditCategories, mEditAddress, mEditTelephone, mEditCapacity;
    private GridLayout mGalleryContainer;
    private boolean isLogo = false;
    private boolean isEditMode = false;

    private Location mLocation;

    private LocationManager locationManager;
    private LocationListener locationListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_home);

        Toolbar toolbar = (Toolbar) findViewById(R.id.home_toolbar);
        setSupportActionBar(toolbar);

        setUpUI(toolbar);

        mEditName = (TextInputEditText) findViewById(R.id.etName);
        mEditCategories = (TextInputEditText) findViewById(R.id.etCategory);
        mEditAddress = (TextInputEditText) findViewById(R.id.etAddress);
        mEditTelephone = (TextInputEditText) findViewById(R.id.etTelephone);
        mEditCapacity = (TextInputEditText) findViewById(R.id.etSpaces);
        mCoord = (TextView) findViewById(R.id.tCoordinates);
        mGetLoc = (Button) findViewById(R.id.bGetLoc);

        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                locationManager.removeUpdates(locationListener);
                Log.d("Home", "Got gps position: " + location.getLatitude() + "," + location.getLongitude());
                mCoord.setText(location.getLatitude() + "," + location.getLongitude());
                mLocation = location;
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        };

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.INTERNET
                }, 10);
            }
            return;
        } else {
            configureButton();
        }


        mGalleryContainer = (GridLayout) findViewById(R.id.home_gallery_container);

        mEditName.setEnabled(false);
        mEditCategories.setEnabled(false);
        mEditAddress.setEnabled(false);
        mEditTelephone.setEnabled(false);
        mEditCapacity.setEnabled(false);
        mGetLoc.setEnabled(false);

        mLogoToUpload = (ImageView) findViewById(R.id.LogoPic);
        assert mLogoToUpload != null;
        mLogoToUpload.setOnClickListener(this);

        mChange = (FloatingActionButton) findViewById(R.id.home_edit);
        assert mChange != null;
        mChange.setOnClickListener(this);

        Button bCam = (Button) findViewById(R.id.btCam);
        assert bCam != null;
        bCam.setOnClickListener(this);


        Button bGal = (Button) findViewById(R.id.btGall);
        assert bGal != null;
        bGal.setOnClickListener(this);

        mSetOpeningTime = (Button) findViewById(R.id.btSet);
        assert mSetOpeningTime != null;
        mSetOpeningTime.setOnClickListener(this);
        mSetOpeningTime.setEnabled(false);

        mRestaurant = ((MadMaxApplication) getApplication()).getRestaurant();
        if (mRestaurant == null) {
            mRestaurant = new Restaurant();
            Log.d("Home", "No restaurant associated with this manager yet");
        } else {
            Log.d("Home", "Associated restaurant: " + mRestaurant.toString());
            fillData();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 10:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    configureButton();
                break;
        }
    }

    private void configureButton() {
        mGetLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEditMode) {
                    mLocation = locationManager.getLastKnownLocation("");
                    if (mLocation == null) {
                        locationManager.requestLocationUpdates("gps", 5000, 20, locationListener);
                    } else {
                        Log.d("Home", "Got gps position: " + mLocation.getLatitude() + "," + mLocation.getLongitude());
                        mCoord.setText(mLocation.getLatitude() + "," + mLocation.getLongitude());
                    }
                }
            }
        });
    }


    private void fillData() {
        new DownloadImageTask(mLogoToUpload).execute(mRestaurant.getLogo());
        mEditName.setText(mRestaurant.getName());
        mEditCategories.setText(mRestaurant.getTag().get(0));
        mEditAddress.setText(mRestaurant.getAddress());
        mEditTelephone.setText(mRestaurant.getPhone());
        mEditCapacity.setText(String.format("%d", mRestaurant.getCapacity()));
        mCoord.setText(mRestaurant.getLocation().getLatitude() + ", " + mRestaurant.getLocation().getLongitude());

        for (String imagePath : mRestaurant.getGallery()) {
            ImageView iv = new ImageView(this);
            iv.setImageResource(android.R.drawable.ic_menu_gallery);
            iv.setImageResource(android.R.drawable.ic_menu_gallery);
            iv.setAdjustViewBounds(true);
            iv.setMinimumHeight(200);
            iv.setMaxHeight(200);
            iv.setMinimumWidth(200);
            iv.setMaxWidth(200);
            mGalleryContainer.addView(iv);

            GridLayout.LayoutParams params = (GridLayout.LayoutParams) iv.getLayoutParams();
            params.setMargins(0, 0, 10, 0);

            new DownloadImageTask(iv).execute(imagePath);
        }
    }

    private void fillRestaurant() {
        mRestaurant.setName(mEditName.getText().toString());
        mRestaurant.setPhone(mEditTelephone.getText().toString());
        mRestaurant.setAddress(mEditAddress.getText().toString());
        mRestaurant.setCapacity(Integer.valueOf(mEditCapacity.getText().toString()));
        //TODO really save all the info, also working hours, timeslot, logo, location, gallery etc
        mRestaurant.setTag(Arrays.asList(mEditCategories.getText().toString()));
        mRestaurant.setLocation(mLocation);
    }

    public void addListenerOnButton() {
        Boolean cancel = false;
        String name = mEditName.getText().toString();
        if (TextUtils.isEmpty(name)) {
            mEditName.setError(getString(R.string.error_field_required));
            cancel = true;
        }

        String cat = mEditCategories.getText().toString();
        if (TextUtils.isEmpty(cat)) {
            mEditCategories.setError(getString(R.string.error_field_required));
            cancel = true;
        }

        String add = mEditAddress.getText().toString();
        if (TextUtils.isEmpty(add)) {
            mEditAddress.setError(getString(R.string.error_field_required));
            cancel = true;
        }

        String tel = mEditTelephone.getText().toString();
        if (TextUtils.isEmpty(tel)) {
            mEditTelephone.setError(getString(R.string.error_field_required));
            cancel = true;
        }

        String cap = mEditCapacity.getText().toString();
        if (TextUtils.isEmpty(cap)) {
            mEditCapacity.setError(getString(R.string.error_field_required));
            cancel = true;
        }

        //check if every field is filled,
        if (!cancel) {
            isEditMode = false;
            Drawable drawable = ContextCompat.getDrawable(this, R.drawable.ic_mode_edit_black_24dp);
            mChange.setImageDrawable(drawable);

            mEditName.setEnabled(false);
            mEditCategories.setEnabled(false);
            mEditAddress.setEnabled(false);
            mEditTelephone.setEnabled(false);
            mEditCapacity.setEnabled(false);
            mSetOpeningTime.setEnabled(false);

            findViewById(R.id.mainLay).requestFocus();
        }
    }

    public void addListenerOnEdit() {
        isEditMode = true;
        Drawable drawable = ContextCompat.getDrawable(this, R.drawable.ic_save_black_24dp);
        mChange.setImageDrawable(drawable);

        mEditName.setEnabled(true);
        mEditCategories.setEnabled(true);
        mEditAddress.setEnabled(true);
        mEditTelephone.setEnabled(true);
        mEditCapacity.setEnabled(true);
        mSetOpeningTime.setEnabled(true);
        mGetLoc.setEnabled(true);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.LogoPic:
                if (isEditMode) {
                    Intent logoIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    logoIntent.setType("image/*");
                    startActivityForResult(Intent.createChooser(logoIntent, "Select File"), SELECT_LOGO);
                }
                break;

            case R.id.home_edit:
                if (isEditMode) {
                    fillRestaurant();
                    SCM.addRestaurant(mRestaurant, ((MadMaxApplication) getApplication()).getManagerId(),
                            HomeActivity.this, PUT_RESTAURANT);
                    addListenerOnButton();
                } else {
                    addListenerOnEdit();
                }
                break;

            case R.id.btCam:
                if (isEditMode) {
                    Intent camera_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(camera_intent, CAM_REQUEST);
                }
                break;

            case R.id.btGall:
                if (isEditMode) {
                    Intent galIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    galIntent.setType("image/*");
                    startActivityForResult(Intent.createChooser(galIntent, "Select File"), SELECT_FILE);
                }
                break;

            case R.id.btSet:
                Intent intent = new Intent(this, HomeTimeInfo.class);
                startActivity(intent);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_LOGO) {
                isLogo = true;
                onSelectFromGalleryResult(data);
            } else if (requestCode == SELECT_FILE) {
                onSelectFromGalleryResult(data);

            } else if (requestCode == CAM_REQUEST) {
                onCaptureImageResult(data);
            }
        }
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(), System.currentTimeMillis() + ".jpg");
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ImageView iv = new ImageView(getApplicationContext());
        iv.setImageBitmap(thumbnail);
    }

    private void onSelectFromGalleryResult(Intent data) {
        Uri selectedImageUri = data.getData();
        String[] projection = {MediaStore.MediaColumns.DATA};
        CursorLoader cursorLoader = new CursorLoader(this, selectedImageUri, projection, null, null, null);
        Cursor cursor = cursorLoader.loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();
        String selectedImagePath = cursor.getString(column_index);

        Bitmap bm;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(selectedImagePath, options);
        final int REQUIRED_SIZE = 200;
        int scale = 1;
        while (options.outWidth / scale / 2 >= REQUIRED_SIZE
                && options.outHeight / scale / 2 >= REQUIRED_SIZE)
            scale *= 2;
        options.inSampleSize = scale;
        options.inJustDecodeBounds = false;
        bm = BitmapFactory.decodeFile(selectedImagePath, options);

        if (isLogo) {
            isLogo = false;
            mLogoToUpload.setImageBitmap(bm);
        } else {
            ImageView iv = new ImageView(HomeActivity.this);
            iv.setImageBitmap(bm);
            mGalleryContainer.addView(iv);
        }
    }

    @Override
    public void onRequestComplete(int requestCode, Object response) {
        switch (requestCode) {
            case PUT_RESTAURANT:
                ((MadMaxApplication) getApplication()).setRestaurant(mRestaurant);

                Log.d("home", mRestaurant.toString());
                Toast.makeText(this, "Restaurant info have been saved", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    public void onRequestFail(int requestCode, Exception exception) {
        Toast.makeText(this, "Failed to save restaurant data", Toast.LENGTH_SHORT).show();
    }
}

